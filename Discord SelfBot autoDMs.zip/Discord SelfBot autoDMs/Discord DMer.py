import discum

tokens = input("Input your tokens separated by spaces: ").strip().split(" ")
i = 0
bot = discum.Client(token=tokens[i], log={"console": False, "file": False})

invite = input("Input the server's invitation link: ").strip().split("/")[-1]
print("Joining Server...", end="")
print(bot.joinGuild(invite).json())
guild_id = bot.joinGuild(invite).json()["guild"]["id"]
print("Done.")
channel_id = bot.getGuildChannels(guild_id).json()[0]["id"]


@bot.gateway.command
def log_online_users(resp):
    if resp.event.ready_supplemental:
        print("Fetching Members...")
        bot.gateway.fetchMembers(guild_id, channel_id)

    if bot.gateway.finishedMemberFetching(guild_id):
        bot.gateway.removeCommand(log_online_users)
        bot.gateway.close()


bot.gateway.run(auto_reconnect=True)

print("Fetching Finished.")
dm = input("Input the message you would like to DM everyone: ")
print("Sending DMs...")
for member in bot.gateway.session.guild(guild_id).members:
    if member == bot.gateway.session.user["id"]:
        continue

    try:
        newDM = bot.createDM([member]).json()["id"]
        bot.sendMessage(newDM, dm)
    except KeyError:
        print("Token", tokens[i], "message banned. Rotating and continuing.")
        i += 1
        bot.switchAccount(tokens[i])
        guild_id = bot.joinGuild(invite).json()["guild"]["id"]
        newDM = bot.createDM([member]).json()["id"]
        bot.sendMessage(newDM, dm)
print("Done.")
