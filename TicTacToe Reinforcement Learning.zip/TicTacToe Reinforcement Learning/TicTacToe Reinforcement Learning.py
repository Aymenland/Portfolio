from random import choice, random, shuffle
from copy import deepcopy


X = "X"
O = "O"
Nan = "_"


class Game:
    def __init__(self):
        self.board = {(x, y): Nan for x in range(3) for y in range(3)}
        self.turn = X

    def show(self):
        print("-" * 7)
        for x in range(3):
            for y in range(3):
                print("|" + self.board[(x, y)], end="")
            print("|")
            print("-" * 7)

    def check_win(self):
        # Line checks
        if self.board[(0, 0)] == self.board[(0, 1)] == self.board[(0, 2)] != Nan:
            return self.board[(0, 0)]
        elif self.board[(1, 0)] == self.board[(1, 1)] == self.board[(1, 2)] != Nan:
            return self.board[(1, 0)]
        elif self.board[(2, 0)] == self.board[(2, 1)] == self.board[(2, 2)] != Nan:
            return self.board[(2, 0)]

        # Column checks
        elif self.board[(0, 0)] == self.board[(1, 0)] == self.board[(2, 0)] != Nan:
            return self.board[(0, 0)]
        elif self.board[(0, 1)] == self.board[(1, 1)] == self.board[(2, 1)] != Nan:
            return self.board[(0, 1)]
        elif self.board[(0, 2)] == self.board[(1, 2)] == self.board[(2, 2)] != Nan:
            return self.board[(0, 2)]

        # Diagonal checks
        elif self.board[(0, 0)] == self.board[(1, 1)] == self.board[(2, 2)] != Nan:
            return self.board[(0, 0)]
        elif self.board[(0, 2)] == self.board[(1, 1)] == self.board[(2, 0)] != Nan:
            return self.board[(0, 2)]

        elif not self.empty():
            return True

        return False

    def fill(self, x, y):
        self.board[(x, y)] = self.turn
        self.turn = X if self.turn == O else O

    def empty(self):
        return [(x, y) for x in range(3) for y in range(3) if self.board[(x, y)] == Nan]

    def reset(self):
        self.__init__()

    def random_game(self):
        self.show()
        for _ in range(9):
            print("\n")
            self.fill(*choice(self.empty()))
            self.show()
            winner = self.check_win()
            if winner:
                print("\n\nThe winner is", winner)
                break

    def stringify(self):
        string = ""
        for i in range(3):
            for j in range(3):
                string += self.board[(i, j)]
        return string


class Agent:
    def __init__(self, game1):
        self.game = game1
        self.rounds = 1000000
        self.weights = {"State_0": {(x, y): 0.0 for x in range(3) for y in range(3)}}
        self.state = Nan * 9
        self.state_p = self.state
        self.lr = 0.1
        self.epsilon = 0.1
        self.x_actions = []
        self.o_actions = []

    def learn(self):
        for _ in range(self.rounds):
            self.state = self.game.stringify()
            self.state_p = self.state
            self.x_actions = []
            self.o_actions = []

            while True:
                turn = self.game.turn

                # Current State's Q_Table
                if self.state not in self.weights:
                    self.weights[self.state] = {(x, y): 0.0 for x in range(3) for y in range(3)}
                q_state = self.calculate_q_state(self.state)

                # Choose an Action and add it to the action history
                action = self.select_action(q_state)
                if turn == X:
                    self.x_actions.append((self.state, action))
                else:
                    self.o_actions.append((self.state, action))

                # Perform Action and check for game end
                self.game.fill(*action)
                win = self.game.check_win()

                # New State
                self.state_p = self.game.stringify() if turn == O else \
                    self.game.stringify().replace("X", "U").replace("O", "X").replace("U", "O")

                # Get Reward
                reward = self.get_reward(action, win, turn)

                # New State's Q_Table
                if self.state_p not in self.weights:
                    self.weights[self.state_p] = {(x, y): 0.0 for x in range(3) for y in range(3)}
                q_state_p = self.calculate_q_state(self.state_p)

                # Update Weights and State
                self.update_weights(q_state, q_state_p, reward, turn)
                self.state = self.state_p

                # Show the game and Q_Table progress
                """
                self.game.show()
                self.print_info()
                """

                if win:
                    if "_" not in self.state_p:
                        del self.weights[self.state_p]
                    break

            self.game.reset()
        self.print_info()

    def play(self):
        self.state = self.game.stringify()
        turn = self.game.turn

        # Current State's Q_Table
        if self.state not in self.weights:
            self.weights[self.state] = {(x, y): 0.0 for x in range(3) for y in range(3)}
        q_state = self.calculate_q_state(self.state)

        # Choose an Action and add it to the action history
        action = self.select_action(q_state, learning=False)

        # Perform Action and check for game end
        self.game.fill(*action)

    def select_action(self, q_state, learning=True):
        if random() < self.epsilon and learning:
            return choice(game.empty())

        possible_actions = game.empty()
        shuffle(possible_actions)

        return max(possible_actions, key=lambda x: q_state[x])

    def get_reward(self, action, winner, turn):
        # Made the win play
        if winner == turn:
            return 1000

        # Denying the opponent the win
        self.game.board[action] = X if turn == O else O
        winner = self.game.check_win()
        self.game.board[action] = turn
        if winner == (X if turn == O else O):
            return 500

        return 0

    def update_weights(self, q_state, q_state_p, reward, turn):
        max_q_p = max(q_state_p.values())

        action_history = self.x_actions if turn == X else self.o_actions

        for i, old_action in enumerate(action_history[::-1]):
            self.weights["State_0"][old_action[1]] += \
                self.lr * (reward + 0.15 * max_q_p - q_state[old_action[1]]) / (3 ** i)

            self.weights[old_action[0]][old_action[1]] += \
                self.lr * (reward + 0.15 * max_q_p - q_state[old_action[1]]) / (3 ** i)

    def calculate_q_state(self, state):
        q = deepcopy(self.weights["State_0"])
        for key in q:
            q[key] += self.weights[state][key]
        return q

    def print_info(self):
        print()
        for state in self.weights:
            print(state if state != Nan * 9 else "Empty", end="\n\t\t")
            for action in self.weights[state]:
                print(action, ":", round(self.weights[state][action], 3), "\t", end="")
            print()
        print()

    def store_weights(self):
        file = open("weights.sav", "w")
        file.write(str(self.weights))
        file.close()

    def load_weights(self, filename="weights.sav"):
        file = open(filename, "r")
        exec("self.weights = " + file.read().strip())
        file.close()


if __name__ == "__main__":
    game = Game()
    agent = Agent(game)
    """
    agent.learn()
    agent.store_weights()
    """

    agent.load_weights()
    turn = 0
    while not game.check_win():
        game.show()

        if turn % 2 == 1:
            answer = input("x, y: ")
            action = (int(answer.split(",")[0].strip()), int(answer.split(",")[1].strip()))
            game.fill(*action)
        else:
            agent.play()

        turn += 1

    game.show()

