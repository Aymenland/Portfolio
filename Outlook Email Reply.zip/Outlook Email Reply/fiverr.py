from extract_msg import Message
import sys
import win32com.client


def find(args, argument):
    for elem in args:
        equal = elem.find("=")
        if elem[:equal] == argument:
            return elem[equal + 1:]

    return None


def main(args):
    # --> Msg File
    msg_file = find(args, "msg")
    if msg_file:
        if msg_file[0] == msg_file[-1] == "\"":
            msg_file = msg_file[1: -1]
        msg = Message(msg_file)
        subject = msg.subject[msg.subject.find(":") + 2:]

    # --> Check for config
    signature = open("signature.txt", "r").read()

    # --> Body
    body = find(args, "body")
    if not body:
        print("Missing 'body' argument.")
        return

    if body[-4:] == ".txt":
        body = open(body, "r").read()
    if body[0] == body[-1] == "\"":
        body = body[1:-1]

    # --> To
    to = find(args, "to")
    if not to:
        print("Missing 'to' argument.")
        return

    to = to.split(",")

    # --> Subject
    if not msg_file:
        subject = find(args, "subject")
        if not subject:
            print("Missing 'subject' argument.")
            return

        if subject[0] == subject[-1] == "\"":
            subject = subject[1:-1]

    # --> Cc
    cc = find(args, "cc")
    if cc:
        cc = cc.split(",")

    # --> Attachments
    attachments = find(args, "attachments")
    if attachments and attachments[0] == attachments[-1] == "\"":
        attachments = attachments[1:-1]
    if attachments:
        attachments = attachments.split(",")

    # --> Send Email

    outlook = win32com.client.Dispatch('outlook.application')
    outlook1 = win32com.client.Dispatch('outlook.application').GetNamespace("MAPI")
    msg_file = outlook1.OpenSharedItem(msg_file)
    mail = msg_file.ReplyAll()

    mail.To = "; ".join(to)
    mail.Subject = subject
    mail.HTMLBody = "" + body + "" + mail.HTMLBody
    if msg_file:
        conversation_topic = msg_file.PropertyAccessor.GetProperty("http://schemas.microsoft.com/mapi/proptag/"
                                                                   "0x0070001F")
        mail.PropertyAccessor.SetProperty("http://schemas.microsoft.com/mapi/proptag/0x0070001F", conversation_topic)
        mail.PropertyAccessor.SetProperty("http://schemas.microsoft.com/mapi/proptag/0x1042001F", msg.messageId)

    if attachments:
        for attachment in attachments:
            mail.Attachments.Add(attachment)
    if cc:
        mail.CC = cc

    mail.Save()
    mail.Display(True)


if __name__ == "__main__":
    main(sys.argv)
