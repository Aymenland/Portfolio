import string

from numpy import percentile
from gensim.parsing.preprocessing import remove_stopwords
import requests
import json


API_KEY = "AIzaSyAaoHZoQtef5PwTHs2CyeWUxLxUb34AYIU"
WORKBOOK_ID = "1fuX9yTnl91E9EVJJxjquMJE3BUSAnua6Fhga2WSoxks"
SHEET_NAME = "all"

URL = f"https://sheets.googleapis.com/v4/spreadsheets/{WORKBOOK_ID}/values/{SHEET_NAME}?key={API_KEY}"
devices = requests.get(URL).json()["values"][1:]
devices = list(set([elem[2].lower() for elem in devices if elem[2]]))


def similar(to_look_in, to_look_for):
    to_look_in1 = to_look_in.copy()
    words = to_look_for.split(" ")

    summ = 0
    for word in words:
        if word in to_look_in1:
            summ += 1
            to_look_in1.remove(word)
        elif word + "th" in to_look_in1:
            summ += 1
            to_look_in1.remove(word + "th")
        elif word.removesuffix("th") in to_look_in1:
            summ += 1
            to_look_in1.remove(word.removesuffix("th"))

    return summ


def match(text):
    text = remove_stopwords(text.lower()).translate(str.maketrans("", "", string.punctuation)).split(" ")
    potential = [device for device in devices
                 if device.split(" ")[0] in text or
                 (len(device.split(" ")) > 1 and not device.split(" ")[1].isnumeric() and
                  device.split(" ")[1] in text)]

    max_len = max(min(int(percentile([len(device.split(" ")) for device in potential], 85)), len(text) // 3), 3)
    jump_len = 1
    result = []
    additional_devices = ()

    i = 0
    while i <= max(len(text) - jump_len, 0):
        sequence = text[i: i + max_len]

        for device in potential:
            ratio = similar(sequence, device)

            if not additional_devices:
                additional_devices = (device, ratio)

            if ratio > additional_devices[1]:
                additional_devices = (device, ratio)
            elif ratio == additional_devices[1]:
                if len(device.split(" ")) < len(additional_devices[0].split(" ")):
                    additional_devices = (device, ratio)
                elif len(device.split(" ")) == len(additional_devices[0].split(" ")):
                    additional_devices = max((device, ratio), additional_devices, key=lambda x: len(x[0]))

        print(sequence, "\t\t:", additional_devices)
        if i % (jump_len * 3) == 1:
            print("here")
            if additional_devices[1] >= 2:
                result.append(additional_devices)
            additional_devices = ()
        i += jump_len

    if additional_devices and additional_devices[1] >= 2:
        result.append(additional_devices)

    return {elem[0] for elem in result}


def lambda_handler(event, context):
    text = event['queryStringParameters']['q']
    return {
        "statusCode": 200,
        "headers": {'Content-Type': 'application/json'},
        "body": json.dumps(list(match(text)))}


print(match("compare iphone 11 pro vs iphone 12 pro"))
