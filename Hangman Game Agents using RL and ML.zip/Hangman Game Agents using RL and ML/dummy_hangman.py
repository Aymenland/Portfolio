from random import choice, shuffle


class Hangman:
    def __init__(self, dictionary_path):
        with open(dictionary_path, 'r') as file:
            self.words = [line.strip() for line in file]
            shuffle(self.words)

        self.index = 0
        self.secret_word = self.words[self.index]     # choice(self.words)
        self.secret_word_letters = {letter: set() for letter in set(self.secret_word)}
        for i, letter in enumerate(self.secret_word):
            self.secret_word_letters[letter].add(i)

        self.display = ['_' for _ in self.secret_word]
        self.incorrect_tries = 0
        self.max_tries = 6

    def reset(self):
        self.index += 1
        self.secret_word = self.words[self.index % len(self.words)]
        self.secret_word_letters = {letter: set() for letter in set(self.secret_word)}
        for i, letter in enumerate(self.secret_word):
            self.secret_word_letters[letter].add(i)

        self.display = ['_' for _ in self.secret_word]
        self.incorrect_tries = 0

    def guess(self, letter, verbose=True):
        # Check for gameover
        if self.incorrect_tries == self.max_tries:
            raise ValueError('Game is over. You lost.')

        # Check for win
        if '_' not in self.display:
            raise ValueError('Game is over. You won.')

        if letter in self.secret_word_letters:
            for i in self.secret_word_letters[letter]:
                self.display[i] = letter

            if verbose and '_' not in self.display:
                print('Correctly guessed ' + letter + '. You win! Guessed word:', ''.join(self.display))

            elif verbose:
                print('Correctly guessed ' + letter + '. Guessed word:', ''.join(self.display) +
                      '. Remaining tries:', self.max_tries - self.incorrect_tries)

            return True, self.display.copy()

        else:
            self.incorrect_tries += 1

            if self.incorrect_tries == 6:
                if verbose:
                    print('Incorrectly guessed ' + letter + '. Lost. Guessed word:', ''.join(self.display),
                          '| Correct word:', self.secret_word)

                return '!lost!', self.display.copy()

            elif verbose:
                print('Incorrectly guessed ' + letter + '. Guessed word:', ''.join(self.display) +
                      '. Remaining tries:', self.max_tries - self.incorrect_tries)

            return False, self.display.copy()


# Example use of the Hangman class
if __name__ == "__main__":
    game = Hangman('words_250000_train.txt')
    game.guess('e')
