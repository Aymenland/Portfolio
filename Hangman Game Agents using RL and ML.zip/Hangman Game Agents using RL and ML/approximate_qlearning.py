from random import random, choice
from collections import defaultdict
from dummy_hangman import Hangman
from matplotlib import pyplot as plt
import numpy as np
from line_profiler import LineProfiler
from collections import Counter
import pickle
from time import time

profiler = LineProfiler()


def profile(func):
    def inner(*args, **kwargs):
        profiler.add_function(func)
        profiler.enable_by_count()
        return func(*args, **kwargs)

    return inner


def print_stats():
    profiler.print_stats()


def count_correct(last_word, current_word):
    count = 0
    for i, letter in enumerate(last_word):
        if letter != current_word[i]:
            count += 1

    return count


def moving_average(data, window_size):
    """Compute the moving average of the given data using a window of the given size."""
    return np.convolve(data, np.ones(window_size) / window_size, mode='valid')


def moving_average_wins(data, window_size):
    """ Returns the moving average of the given list using a sliding window """
    cumulative_sum = np.cumsum(data, dtype=float)
    cumulative_sum[window_size:] = cumulative_sum[window_size:] - cumulative_sum[:-window_size]
    return cumulative_sum[window_size - 1:] / window_size


class ApproxQLearning:
    def __init__(self, epsilon, alpha, gamma, game):
        self.epsilon = epsilon  # Exploration rate
        self.alpha = alpha  # Learning rate
        self.gamma = gamma  # Discount factor

        self.game = game  # Hangman game

        self.actions = {chr(i) for i in range(97, 123)}  # the alphabet
        self.weights = defaultdict(float)  # Weights for features
        self.features = {}  # Place holder for the features calculated every iteration

        self.vowels = {'a', 'e', 'i', 'o', 'u'}
        letter_count = Counter("".join(game.words)).most_common()
        count_sum = sum(count for _, count in letter_count)
        self.letter_frequency = {letter: count / count_sum for letter, count in letter_count}

        self.available_letters = self.actions.copy()  # Track the not yet guessed letters
        self.guessed_wrong_letters = set()  # Track letters that do not exist in the word

    def get_features1(self, state):
        features = {f"no_letter_{letter}": 0.1 for letter in self.guessed_wrong_letters}
        features['f0'] = 0.1

        for i in range(35):
            if i < len(state):
                letter = state[i]
                if letter == "_":
                    features[f"position_{i}"] = 0.1
                elif letter in self.vowels:
                    features[f"{letter}_{i}"] = 0.1
                else:
                    features[f"consonant_{letter}"] = 0.1

        return features

    def get_features(self, state):
        features = {f"no_letter_{letter}": 0.1 for letter in self.guessed_wrong_letters}
        features['f0'] = 0.1
        features['length'] = len(state) / 10

        for i in range(35):
            if i < len(state):
                letter = state[i]
                if letter != "_":
                    features[f"pos_{i}"] = self.letter_frequency[letter]

        return features

    def get_q_value(self, state, action, weights=None):
        self.features = self.get_features(state)
        w = weights if weights else self.weights
        return sum(w[f"{key}_{action}"] * value for key, value in self.features.items())

    def choose_action(self, state, training, weights=None):
        if random() < self.epsilon and training:
            return choice(tuple(self.available_letters))
        else:
            # Return the highest q-value
            q_values = tuple((self.get_q_value(state, action, weights if weights else None), action)
                             for action in self.available_letters)
            highest_qvalue = max(q_values, key=lambda x: x[0])[0]
            ties = list((qvalue, action) for qvalue, action in q_values if qvalue == highest_qvalue)
            ties.sort(key=lambda x: self.letter_frequency[x[1]], reverse=True)

            # Randomly choose one of the actions that have this q-value (in case of ties)
            return ties[0][1]

    def update(self, state, action, next_state, reward):
        current_q = self.get_q_value(state, action)

        if '_' in next_state:
            best_future_q = max(self.get_q_value(next_state, a) for a in self.actions)
            target = reward + self.gamma * best_future_q
        else:
            target = reward

        difference = target - current_q
        for f, value in self.features.items():
            self.weights[f'{f}_{action}'] += self.alpha * difference * value

    def play(self, num_games=1000, training=True, weights=None):
        rewards = []
        win_history = []
        wins = 0
        correct_guesses = 0
        total_guesses = 0

        for game_index in range(num_games):
            self.game.reset()  # Reset the hangman game
            self.available_letters = self.actions.copy()  # Reset the available letters
            self.guessed_wrong_letters = set()  # Reset the wrong guessed letters
            current_state = self.game.display.copy()
            total_reward = 0
            win = 0

            while True:
                action = self.choose_action(current_state, training=training, weights=weights if weights else None)
                result, next_state = self.game.guess(action, verbose=False)

                '''if not result or result == '!lost!':
                    reward = -1
                else:
                    reward = count_correct(current_state, next_state)'''

                if not result:
                    reward = -0.1
                elif result == '!lost!':
                    reward = -1
                else:
                    reward = count_correct(current_state, next_state) / 10 if "_" in next_state else 1

                if training:
                    self.update(current_state, action, next_state, reward)

                if reward < 0:
                    self.guessed_wrong_letters.add(action)
                self.available_letters.remove(action)
                current_state = next_state
                total_reward += reward

                total_guesses += 1
                if reward > 0:
                    correct_guesses += 1

                if "_" not in next_state:
                    win = 1
                    wins += 1

                if result == '!lost!' or "_" not in next_state:
                    break

            win_history.append(win)
            rewards.append(total_reward)

            if (game_index + 1) % (num_games // 100) == 0:
                print(f"Completed {game_index + 1} games")

        if not weights:
            with open('weights.pickle', 'wb') as f:
                pickle.dump(self.weights, f)

        print(f'Win rate: {round(100 * wins / num_games, 2)}%')
        print(f'Accuracy: {round(100 * correct_guesses / total_guesses, 2)}%')
        print(sorted([item for item in self.weights.items()], reverse=True, key=lambda x: x[1]))

        # Calculate the moving average of the rewards
        window_size = (num_games // 100)  # This sets the window size for the moving average
        ma_rewards = moving_average(rewards, window_size)

        plt.scatter(range(len(rewards)), rewards, alpha=0.6, color='blue', s=7)
        plt.ylim(-2, 4)

        # Add the moving average line plot
        plt.plot(range(window_size - 1, len(ma_rewards) + window_size - 1), ma_rewards, color='red',
                 label='Moving Average')

        plt.title(f'Rewards per Game Over {num_games} Games')
        plt.xlabel('Game Number')
        plt.ylabel('Total Reward')
        plt.show()

        # Calculate moving average of the win rate
        window_size = (num_games // 100)  # Adjust the window size based on your preference
        win_rate_ma = moving_average(win_history, window_size)

        # Plot the results
        plt.figure(figsize=(10, 5))
        plt.plot(range(len(win_rate_ma)), win_rate_ma, label='Win Rate Moving Average')
        plt.title(f'Moving Average of Win Rate Over {'Training' if training else 'Testing'}')
        plt.xlabel('Number of Games')
        plt.ylabel('Win Rate')
        plt.legend()
        plt.grid(True)
        plt.ylim(0, 0.3)
        plt.show()


if __name__ == "__main__":
    hangman = Hangman('words_250000_train.txt')
    agent = ApproxQLearning(epsilon=0.2, alpha=0.0035, gamma=0.95, game=hangman)
    n = (len(hangman.words) - 1)

    # t = time()
    with open('weights.pickle', 'rb') as weights:
        weights = pickle.load(weights)

    agent.play(num_games=n, training=True)
    # agent.play(num_games=10000, training=False, weights=weights)
    # print((time() - t) / n)
    # print_stats()

    '''except Exception as e:
        print('Error:', e)
        print(hangman.display)
        print(hangman.secret_word)
        print(hangman.secret_word_letters)'''
