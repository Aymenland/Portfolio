import pandas as pd


# Already captured operators
captured_list = list(pd.read_csv("Already Captured.csv")["already_captured_operators"])

# Import Dataset and clean it
data_df = pd.read_csv("SNF operator locations.csv")
data_df.dropna(inplace=True)
data_df.drop_duplicates(inplace=True)
data_df = data_df[~data_df["state"].isin(["PR", "DC", "AK"])]

# List of capturable operators (3+ facilities)
num_facilities_per_operator_df = data_df[["guid", "operator_hashed"]].groupby("operator_hashed").count()\
    .reset_index(level=0)
num_facilities_per_operator_df = num_facilities_per_operator_df[(num_facilities_per_operator_df["guid"] >= 3)
                                                                & (~num_facilities_per_operator_df["operator_hashed"]
                                                                   .isin(captured_list))]
capturable_operators = list(num_facilities_per_operator_df["operator_hashed"])

# Dictionary of lists of operators per state
states_operators = {state: set(data_df[(data_df["state"] == state)
                                       & (data_df["operator_hashed"]
                                          .isin(capturable_operators + captured_list))]["operator_hashed"])
                    for state in data_df["state"].unique()}

# Dictionary of the number of facilities per state per operator
operators_states = {operator: {state: len(data_df[(data_df["operator_hashed"] == operator)
                                                  & (data_df["state"] == state)])
                               for state in set(data_df[data_df["operator_hashed"] == operator]["state"])}
                    for operator in capturable_operators + captured_list}


# OPTIMIZATION: Greedy top_down algorithm

def top_down(n=None):
    operators = capturable_operators + captured_list

    states_to_recalculate = set(states_operators.keys())
    states_active = {state: False for state in states_operators}

    # Remove all operators that are monopolies in some state

    while states_to_recalculate:
        new_states_to_recalculate = set()

        for state in states_to_recalculate:
            captured_operators_in_state = states_operators[state].intersection(set(operators))
            if len(captured_operators_in_state) < 4:
                continue

            sum_facilities = sum(operators_states[op][state] for op in captured_operators_in_state)

            max_operator_facilities = max(((op, operators_states[op][state]) for op in captured_operators_in_state),
                                          key=lambda x: x[1])

            if max_operator_facilities[1] > (1 / 3) * sum_facilities:
                states_active[state] = False
                monopoly_operator = max_operator_facilities[0]

                if monopoly_operator in operators:
                    operators.remove(monopoly_operator)

                new_states_to_recalculate = new_states_to_recalculate\
                    .union(set(operators_states[monopoly_operator].keys()))

            else:
                states_active[state] = True

        states_to_recalculate = new_states_to_recalculate

    # Remove all operators that are unnecessary

    new_states_active = {state: False for state in states_operators}
    for op in operators.copy():
        operators.remove(op)

        new_states_active = {state: False for state in states_operators}
        for state in states_operators:
            captured_operators_in_state = states_operators[state].intersection(set(operators))
            if len(captured_operators_in_state) < 4:
                continue

            sum_facilities = sum(operators_states[op][state] for op in captured_operators_in_state)

            max_operator_facilities = max(operators_states[op][state] for op in captured_operators_in_state)

            if max_operator_facilities <= (1 / 3) * sum_facilities:
                new_states_active[state] = True

        threshold = n
        if not threshold:
            threshold = sum(states_active.values())

        if sum(new_states_active.values()) < threshold:
            operators.append(op)

    print(new_states_active)
    print(sum(new_states_active.values()), "states active out of", len(new_states_active.values()), "states.")
    print(len(operators), "operators captured.")
    print("operators list:", operators)

    
if __name__ == "__main__":
    top_down(11)
