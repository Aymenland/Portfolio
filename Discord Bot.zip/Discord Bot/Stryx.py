import os
import discord
from dotenv import load_dotenv
from discord.ext import commands, tasks
import youtube_dl
import asyncio
import urllib.parse
import urllib.request
import re
from django.core.validators import URLValidator, ValidationError
import io
import aiohttp
from datetime import datetime
import pytz
from time import time as t
from random import choice
import boto3

load_dotenv()
TOKEN = os.getenv('DISCORD_TOKEN')

intents = discord.Intents.all()
client = commands.Bot(intents=intents, command_prefix=";", help_command=None)

DAYS = {"lundi": 0, "mardi": 1, "mercredi": 2, "jeudi": 3, "vendredi": 4, "samedi": 5, "dimanche": 6}
s3 = boto3.resource(
    service_name='s3',
    region_name='us-east-2',
    aws_access_key_id='AKIAZGKMT4TUNGDSRQIX',
    aws_secret_access_key='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'
)


@tasks.loop(minutes=60)
async def programmed_msgs():
    s3.Bucket('stryx').download_file(Key='scheduled.txt', Filename='scheduled1.txt')
    f = open("scheduled1.txt", "r")
    msgs = []
    line = "msgs.append([" + f.read()[1:] + "])"
    exec(line)
    msgs = msgs[0]
    guild = discord.utils.get(client.guilds, id=464525404976316416)

    for lst in msgs:
        schedules = lst[1:-2]
        msg = lst[-2].replace("{}", "\n").replace("/////1", "\"").replace("/////", "'")
        old_time = lst[0]
        channel = discord.utils.get(guild.text_channels, id=int(lst[-1]))
        if len(schedules) == 0:
            msgs.remove(lst)
        else:
            for time in schedules:
                if t() - old_time > time:
                    await channel.send(msg)
                    lst.remove(time)
                    if len(lst) == 2:
                        msgs.remove(lst)

    f.close()
    f = open("scheduled1.txt", "w")
    rewrite = ""
    for lst in msgs:
        rewrite += "," + str(lst)
    f.write(rewrite)
    f.close()
    s3.Bucket('stryx').upload_file(Key='scheduled.txt', Filename='scheduled1.txt')


@tasks.loop(minutes=60)
async def recurrent_msgs():
    s3.Bucket('stryx').download_file(Key='recurrent.txt', Filename='recurrent1.txt')
    f = open("recurrent1.txt", "r")
    msgs = []
    line = "msgs.append([" + f.read()[1:] + "])"
    exec(line)
    msgs = msgs[0]
    guild = discord.utils.get(client.guilds, id=464525404976316416)
    channel = discord.utils.get(guild.text_channels, id=630760736221560845)

    for lst in msgs:
        day = lst[0] if len(lst) == 4 else -1
        hour = lst[1] if len(lst) == 4 else lst[0]
        title = lst[2] if len(lst) == 4 else lst[1]
        msg = lst[-1].replace("{}", "\n")
        tz = pytz.timezone("Europe/Paris")
        now = datetime.now(tz)
        if now.hour == hour:
            if day == -1:
                await channel.send("**" + title.title() + "**\n\n" + msg)
            elif day == now.weekday():
                await channel.send(msg)
    f.close()


@client.event
async def on_ready():
    programmed_msgs.start()
    recurrent_msgs.start()
    await client.change_presence(status=discord.Status.online,
                                 activity=discord.Activity(type=discord.ActivityType.watching,
                                                           name="you in your sleep."))

    print(str(client.user) + " is connected")


# DONE
@client.event
async def on_member_join(member):
    channel = discord.utils.get(member.guild.text_channels, id=469132922046382080)

    embed = discord.Embed(title="Nouvel Arrivant",
                          url="https://discord.com/",
                          description=member.mention + " vient de **rejoindre** le serveur.",
                          color=0x10FF10)

    # Add author, thumbnail, fields, and footer to the embed
    embed.set_author(name=member.name, url="https://discord.com/",
                     icon_url=member.avatar_url)
    embed.set_thumbnail(url=member.avatar_url)
    embed.add_field(name="UID", value=str(member.id), inline=False)
    embed.add_field(name="Nametag", value=str(member.name) + "#" +
                                          str(member.discriminator), inline=False)
    embed.add_field(name="Crée le", value=str(member.created_at), inline=False)

    await channel.send(embed=embed)


# DONE
@client.event
async def on_member_remove(member):
    channel = discord.utils.get(member.guild.text_channels, id=501396717766311960)

    embed = discord.Embed(title="Nouveau Depart",
                          url="https://discord.com/",
                          description=member.mention + " vient de **quitter** le serveur.",
                          color=0xFF0000)

    # Add author, thumbnail, fields, and footer to the embed
    embed.set_author(name=member.name, url="https://discord.com/",
                     icon_url=member.avatar_url)
    embed.set_thumbnail(url=member.avatar_url)
    embed.add_field(name="UID", value=str(member.id), inline=False)
    embed.add_field(name="Nametag", value=str(member.name) + "#" +
                                          str(member.discriminator), inline=False)
    embed.add_field(name="Crée le", value=str(member.created_at), inline=False)

    await channel.send(embed=embed)


@client.event
async def on_message(message):
    if message.author.id == client.user.id:
        return

    responses = []

    s3.Bucket('stryx').download_file(Key='responses.txt', Filename='responses1.txt')
    f = open("responses1.txt", "r")
    for line in f.readlines():
        sentence, response = line.split(sep="==")
        responses.append((sentence.strip().lower(), response.strip()))
    f.close()

    for response in responses:
        if response[0] in message.content.lower():
            await message.channel.send(response[1])

    if message.channel.id == 767337102156627969:
        if len(message.attachments) == 0:
            okay = False
            for role in message.author.roles:
                if role.id == 572733578241376258:
                    okay = True

            if not okay:
                await message.delete()
                await message.author.send("**Avertissement:** Vous n'êtes pas autorisé de poster des messages sans "
                                          "image attachée dans ce canal.")
                channel = discord.utils.get(message.guild.text_channels, id=784163127625121852)
                embed = discord.Embed(title="Un Message a été supprimé",
                                      url="https://discord.com/",
                                      description="Stryx Bot vient de supprimer le message de "
                                                  + (str(message.author.nick) if str(message.author.nick) != "None"
                                                     else message.author.name)
                                                  + " dans le canal" + str(message.channel.name) + ":\n*" +
                                                  str(message.content) + "*",
                                      color=0x10FF10)

                # Add author, thumbnail, fields, and footer to the embed
                embed.set_author(name=client.user.name, url="https://discord.com/",
                                 icon_url=client.user.avatar_url)
                embed.set_thumbnail(url=message.author.avatar_url)
                embed.add_field(name="UID", value=str(message.author.id), inline=False)
                embed.add_field(name="Nametag", value=str(message.author.name) + "#" +
                                                      str(message.author.discriminator), inline=False)

                await channel.send(embed=embed)

    if ";;p" != message.content[:3]:
        await client.process_commands(message)


# DONE
@client.command()
async def help(ctx, command=""):
    if command == "":
        embed = discord.Embed(title="Help",
                              description="Utilisez ;help <commande> pour plus d'informations sur l'utilisation de chaque"
                                          " commande.",
                              color=0x10FF10)

        # Add author, thumbnail, fields, and footer to the embed
        embed.set_author(name=client.user.name, icon_url=client.user.avatar_url)
        embed.add_field(name="Divers", value="created\nnewskin\nskin\nping\nhelp", inline=True)
        embed.add_field(name="Reponses", value="program\nrecurrent\ncancel\nrules\nnewrules\ncustom", inline=True)
        embed.add_field(name="Music", value="play\nskip\nstop\nclist", inline=True)
        embed.add_field(name="Moderation", value="add_role\nclear\nrename", inline=True)

        await ctx.send(embed=embed)
    else:
        command = command.strip()
        commands1 = client.commands
        if command not in [elem.name for elem in commands1]:
            await ctx.send("La commande " + command + " n'existe pas. Ecrivez ;help pour voir les commandes que le bot "
                                                      "supporte.")
            return

        for elem in commands1:
            if elem.name == command:
                command = elem
                break

        embed = discord.Embed(title="Help / " + command.name,
                              description=command.help, color=0x10FF10)
        embed.set_author(name=client.user.name, icon_url=client.user.avatar_url)

        await ctx.send(embed=embed)


# ----- COMMANDS

# DONE
@client.command(help="';ping' donne la latence actuel du bot. À utiliser si vous pensez qu'un certain lag provient du "
                     "bot même.")
async def ping(ctx):
    await ctx.send("Pong ... " + str(round(client.latency * 1000)) + "ms")


# DONE
@client.command(help="';clear n' avec n étant un entier, supprime les n derniers messages du canal où la commmande est "
                     "éxécuté. La commande supprime le message de commande lui-même ainsi que n autres messages, "
                     "supprime donc n+1 messages ")
@commands.has_role(489164197708693506)
async def clear(ctx, num):
    msgs = await ctx.history(limit=int(num) + 1).flatten()
    for msg in msgs:
        await msg.delete()


# DONE
@client.command(help="';rename old-channel new-channel' renomme le canal dont le nom figure dans le premier paramètre, "
                     "avec le nouveau nom figurant dans le deuxième paramètre.")
@commands.has_role(489164197708693506)
async def rename(ctx, name, *newargs):
    channel = discord.utils.get(ctx.guild.text_channels, name=name)
    print(" ".join(newargs))
    await channel.edit(name=" ".join(newargs))


# DONE
@client.command(help="';created Name#2509' écrit la date de création du compte discord fourni. Le compte "
                     "en question doit être dans le serveur pour que la commande fonctionne. "
                     "';created ID' écrit la date de création du compte discord de l'ID fourni. Le compte "
                     "en question n'a pas besoin d'être dans le serveur pour que la commande fonctionne.")
async def created(ctx, *, args):
    if "#" in args:
        username, userdescrim = args.strip().split("#")
        userid = discord.utils.get(ctx.guild.members, name=username, discriminator=userdescrim).id
        user = client.get_user(userid)
        await ctx.send(user.created_at)
    else:
        user = client.get_user(int(args.strip()))
        await ctx.send(user.created_at)


queue = []
Skip = False


# DONE
@client.command(help="';play https://www.youtube.com/watch?v=oWidxg_YCIU' se connecte au canal vocal de l'utilisateur"
                     " et lit l'audio à partir de l'URL youtube. ';play Dabin - Bloom' se connecte "
                     "au canal vocal de l'utilisateur et lit l'audio à partir du premier résultat de recherche"
                     " sur youtube pour le titre fourni.", aliases=["p"])
async def play(ctx, *, url):
    global queue, Skip

    validate = URLValidator()
    isurl = True
    try:
        validate(url)
    except ValidationError:
        isurl = False

    if isurl:
        if "list" in url:
            await ctx.send(
                "Je n'accepte pas les playlist ! C'est trop long ! Il faut de la place pour tout le monde :D. "
                "Si tu veux tout de même écouter cette musique, essaye de me donner un lien qui n'est pas une "
                "playlist.")
            return
        queue.append(url)
    else:
        query_string = urllib.parse.urlencode({'search_query': url})
        htm_content = urllib.request.urlopen('http://www.youtube.com/results?' + query_string)
        search_results = re.findall(r'/watch\?v=(.{11})', htm_content.read().decode())
        await ctx.send('http://www.youtube.com/watch?v=' + search_results[0])
        url1 = 'http://www.youtube.com/watch?v=' + search_results[0]
        if "list" in url1:
            ctx.send("Je n'accepte pas les playlist ! C'est trop long ! Il faut de la place pour tout le monde :D. "
                     "Si tu veux tout de même écouter cette musique, essaye de me donner un lien qui n'est pas une "
                     "playlist")
            return
        queue.append(url1)

    channel = ctx.author.voice.channel

    vc = ""
    alreadyin = False
    members = channel.members
    for mem in members:
        if mem.id == 790861880809226260:
            alreadyin = True

    if not alreadyin:
        vc = await channel.connect()
    else:
        vc = client.voice_clients[0]

    while True:
        Skip = False
        song_there = os.path.isfile("song.mp3")
        try:
            if song_there:
                os.remove("song.mp3")
        except PermissionError:
            if len(queue) > 5:
                await ctx.send(
                    "La file d'attente est pleine. Il est impossible d'ajouter des musiques supplémentaires. "
                    "Veuillez vider la liste d'attente ou bien patienter que les musiques de la liste soient "
                    "jouées.")
                queue = queue[:-1]
                return
            await ctx.send("Ajoutée a la file (" + str(len(queue)) + "/5)")
            return

        await ctx.send("Chargement de la musique en cours")

        ydl_opts = {
            'format': 'bestaudio/best',
            'postprocessors': [{
                'key': 'FFmpegExtractAudio',
                'preferredcodec': 'mp3',
                'preferredquality': '192',
            }],
        }

        with youtube_dl.YoutubeDL(ydl_opts) as ydl:
            try:
                ydl.download([queue[0]])
            except youtube_dl.utils.DownloadError:
                await vc.disconnect()

        name = ""
        for file in os.listdir("./"):
            if file.endswith(".mp3"):
                name = file
                os.rename(file, "song.mp3")

        vc.play(discord.FFmpegPCMAudio("song.mp3"))
        vc.source = discord.PCMVolumeTransformer(vc.source)
        vc.source.volume = 0.2

        nname = name.rsplit("-", 1)
        await ctx.send(f"Playing: {nname[0]}")

        while vc.is_playing():
            if Skip:
                vc.stop()
                break
            await asyncio.sleep(1)
        queue = queue[1:]
        await ctx.send("Next!")

        if len(queue) == 0:
            await vc.disconnect()
            return


# DONE
@client.command(help="';stop' arrête la lecture de la musique dans le canal vocal et se déconnecte.")
async def stop(ctx):
    global queue
    voices = client.voice_clients
    if len(voices) > 0:
        vc = client.voice_clients[0]
        await ctx.send("Arrêt de la musique et déconnexion du canal.")
        await vc.disconnect()

    queue.clear()


@client.command(help="';skip' ignore la musique en cours de lecture et passe a la suivante de la file.")
async def skip(ctx):
    global Skip
    Skip = True


@client.command(help="';clist' efface la file d'attente.")
async def clist(ctx):
    global queue
    queue.clear()
    await ctx.send("File d'attente vidée.")


# DONE
@client.command(help="';custom This Sentence == This Response' fera répondre le bot par \"This Response\" après "
                     "chaque message contenant \"This Sentence\".")
async def custom(ctx, *, args):
    sentence, response = args.split(sep="==")
    sentence = sentence.strip()
    response = response.strip()

    s3.Bucket('stryx').download_file(Key='responses.txt', Filename='responses1.txt')
    f = open("responses1.txt", "a")
    f.write(sentence + "==" + response + "\n")
    f.close()
    s3.Bucket('stryx').upload_file(Key='responses.txt', Filename='responses1.txt')

    await ctx.send("Réponse personnalisée ajoutée")


@client.command(help="';add_role @Vadar admin' ajoute le role admin a Vadar.")
@commands.has_role(572733578241376258)
async def add_role(ctx, member: discord.Member, role):
    await member.add_roles(discord.utils.get(ctx.guild.roles, name=role))


@client.command(help="';rules_new des règles' enregistre 'des règles'. La commande ;rules fera répondre le bot par "
                     "'des règles'.")
@commands.has_role(572733578241376258)
async def newrules(ctx, *, text):
    try:
        s3.Bucket('stryx').download_file(Key='rules.txt', Filename='rules1.txt')
        f = open("rules1.txt", "w")
        f.write(text + ("\n====" + ctx.message.attachments[0].url if len(ctx.message.attachments) > 0 else ""))
        f.close()
        s3.Bucket('stryx').upload_file(Key='rules.txt', Filename='rules1.txt')

        await ctx.send("Les Règles ont été enregistrées. Utilisez ;rules pour les lire.")
    except UnicodeEncodeError:
        await ctx.send("Vous ne pouvez pas sauvegarder des règles contenants une/plusieurs emojis.")


@client.command(help="';rules' fera répondre le bot par les règles précédemment enrigistrées par la commande "
                     "';rules_new'.")
async def rules(ctx):
    s3.Bucket('stryx').download_file(Key='rules.txt', Filename='rules1.txt')
    f = open("rules1.txt", "r")
    response = f.read()
    f.close()
    text = response.rsplit(maxsplit=1, sep="====")

    async with aiohttp.ClientSession() as session:
        if len(text) > 1:
            async with session.get(text[1]) as resp:
                if resp.status != 200:
                    return await ctx.send('Could not download the image...')
                data = io.BytesIO(await resp.read())
                await ctx.send(file=discord.File(data, "image.png"), content=text[0])
        else:
            await ctx.send(content=text[0])


@client.command(help="';program 1j 1h, 2j 2h = Message' fera en sorte que le bot écrive dans le canal annonces"
                     " l'annonce 'Message' dans 1 jour et 1 heure, ainsi que dans 2 jours et 2 heures. La commande "
                     "peut aussi être utilisé avec plus (ou moins) de temps d'annonces.")
@commands.has_role(572733578241376258)
async def program(ctx, *, txt):
    channel, timetxt, msg = txt.split(sep="=", maxsplit=2)
    # ;program 29583695836 = 1j 1h 1m, 2j 2h 2m = Message
    timeslst = [elem.strip() for elem in timetxt.strip().split(sep=",")]
    timeslsts = [elem.split(sep=" ") for elem in timeslst]
    times = []
    for time in timeslsts:
        add = 0
        for elem in time:
            if elem[-1] == "j":
                add += int(elem[:-1]) * 24 * 3600
            elif elem[-1] == "h":
                add += int(elem[:-1]) * 3600
            else:
                await ctx.send("Le format que vous avez utilisé est incorrecte. Utilisez ;help program pour savoir "
                               "comment utiliser la commande.")
                return

        if add not in times:
            times.append(add)

    s3.Bucket('stryx').download_file(Key='scheduled.txt', Filename='scheduled1.txt')
    f = open("scheduled1.txt", "a")
    f.write(",[" + str(t()) + ", " + str(times)[1:-1] + ", \"" +
            msg.strip().replace("\n", "{}").replace("'", "/////").replace("\"", "/////1") + "\", "
            + str(channel.strip()) + "]")
    f.close()
    s3.Bucket('stryx').upload_file(Key='scheduled.txt', Filename='scheduled1.txt')
    await ctx.send("Votre message a été programmé avec succès.")


@client.command(help="';recurrent mardi 17h = Titre de l'annonce = L'annonce' fera en sorte que le bot écrive dans le "
                     "canal annonces l'annonce 'L'annonce' titré 'Titre de l'annonce' chaque mardi a 17h. Il est aussi"
                     " possible de ne pas spécifier le jour (;recurrent 15h = Titre = Annonce) pour que l'annonce "
                     "soit envoyée chaque jour a l'heure spécifiée.")
@commands.has_role(572733578241376258)
async def recurrent(ctx, *, txt):
    global DAYS
    # ;recurrent day hour = title = message
    date, title, msg = [elem.strip() for elem in txt.split(sep="=", maxsplit=2)]
    if date == "" or title == "" or msg == "":
        await ctx.send("Le format que vous avez utilisé est incorrecte. Utilisez ;help recurrent pour savoir comment"
                       "utiliser la commande.")
        return

    splt = date.split(sep=" ")
    day, hour = [elem.strip() for elem in splt] if len(splt) == 2 else ("", splt[0])

    s3.Bucket('stryx').download_file(Key='recurrent.txt', Filename='recurrent1.txt')
    f = open("recurrent1.txt", "a")
    f.write(",[" + str(DAYS[day]) + ", " + str(hour[:-1]) + ", \"" + title + "\", \"" +
            msg.strip().replace("\n", "{}") + "\"]" if day != "" else ",[" + str(hour[:-1]) + ", \"" + title + "\", \""
                                                                      + msg.strip().replace("\n", "{}") + "\"]")
    f.close()
    s3.Bucket('stryx').upload_file(Key='recurrent.txt', Filename='recurrent1.txt')

    await ctx.send("Votre message recurrent a été programmé avec succès.")


@client.command(help="';cancel titre' annule le message récurrent titré 'titre'.")
@commands.has_role(572733578241376258)
async def cancel(ctx, *, title):
    title = title.strip()
    s3.Bucket('stryx').download_file(Key='recurrent.txt', Filename='recurrent1.txt')
    f = open("recurrent1.txt", "r")
    msgs = []
    line = "msgs.append([" + f.read()[1:] + "])"
    exec(line)
    msgs = msgs[0]

    found = False
    for lst in msgs:
        if title in lst:
            msgs.remove(lst)
            found = True
            break

    if not found:
        await ctx.send("Aucun Message recurrent titré \"" + title + "\" n'a été trouvé.")
        return

    f.close()
    f = open("recurrent1.txt", "w")
    rewrite = ""
    for lst in msgs:
        rewrite += "," + str(lst)
    f.write(rewrite)
    f.close()
    s3.Bucket('stryx').upload_file(Key='recurrent.txt', Filename='recurrent1.txt')

    await ctx.send("Le Message reccurent " + title.title() + " a été annulé.")


@client.command(help="';newskin xelor\ndetails du skin1\ndetails du skin2\ndetails du skin2\n...' sauvegarde le skin "
                     "attaché au texte de la commande avec les details et le nom de la classe. Utilisez ';skin xelor'"
                     "pour avoir un skin aleatoire des skins xelor sauvegardé (par exemple).")
async def newskin(ctx, *, txt):
    classe, rest = txt.split(sep="\n", maxsplit=1)
    classe = classe.strip().lower()
    try:
        url = ctx.message.attachments[0].url
    except:
        await ctx.send("Vous avez oublié d'attachez l'image contenant le skin avec la commande.")
        return

    s3.Bucket('stryx').download_file(Key='skins.txt', Filename='skins1.txt')
    f = open("skins1.txt", "a")
    f.write(classe + "\n" + url + "\n" + rest + "///")
    f.close()
    s3.Bucket('stryx').upload_file(Key='skins.txt', Filename='skins1.txt')

    await ctx.send("Votre skin a été sauvegardé avec succès.")


@client.command(help="';skin xelor' donne un skin aleatoire des skins xelor sauvegardé par la commande ;newskin"
                     " (xelor est un exemple).")
async def skin(ctx, classe):
    classe = classe.strip().lower()
    s3.Bucket('stryx').download_file(Key='skins.txt', Filename='skins1.txt')
    f = open("skins1.txt", "r")
    details = f.read()
    f.close()
    skins = details.split(sep="///")[:-1]
    randomskins = []

    for skin1 in skins:
        classe1, url, rest = skin1.split(sep="\n", maxsplit=2)
        if classe1.strip() == classe:
            randomskins.append([classe, url, rest])

    chosen = choice(randomskins)
    async with aiohttp.ClientSession() as session:
        async with session.get(chosen[1]) as resp:
            if resp.status != 200:
                return await ctx.send('Could not download the image...')
            data = io.BytesIO(await resp.read())
            await ctx.send(file=discord.File(data, "image.png"),
                           content="```" + classe.title() + "\n" + chosen[2] + "```")


# ----- AUDIT LOG

# DONE
@client.event
async def on_member_update(before, after):
    if before.nick != after.nick:
        channel = discord.utils.get(after.guild.text_channels, id=784163127625121852)

        embed = discord.Embed(title="Un Membre a modifié son profil",
                              url="https://discord.com/",
                              description=(str(after.nick) if str(after.nick) != "None" else after.name)
                                          + " vient de **changer son nom dans le serveur**: "
                                          + (str(before.nick) if str(before.nick) != "None" else before.name)
                                          + " -> " + (str(after.nick) if str(after.nick) != "None" else after.name)
                                          + ".",
                              color=0x10FF10)

        # Add author, thumbnail, fields, and footer to the embed
        embed.set_author(name=client.user.name, url="https://discord.com/",
                         icon_url=client.user.avatar_url)
        embed.set_thumbnail(url=after.avatar_url)
        embed.add_field(name="UID", value=str(after.id), inline=False)
        embed.add_field(name="Nametag", value=str(after.name) + "#" +
                                              str(after.discriminator), inline=False)

        await channel.send(embed=embed)

    if before.roles != after.roles:
        for role in after.roles:
            if role not in before.roles:
                channel = discord.utils.get(after.guild.text_channels, id=784163127625121852)

                embed = discord.Embed(title="Un Membre a été modifié",
                                      url="https://discord.com/",
                                      description=("Les roles du membre " + str(after.nick) if str(after.nick) !=
                                                                                               "None" else after.name)
                                                  + " ont été modifié:\nAjout du role **" + str(role.name) + "**",
                                      color=0x10FF10)

                # Add author, thumbnail, fields, and footer to the embed
                embed.set_author(name=client.user.name, url="https://discord.com/",
                                 icon_url=client.user.avatar_url)
                embed.set_thumbnail(url=after.avatar_url)
                embed.add_field(name="UID", value=str(after.id), inline=False)
                embed.add_field(name="Nametag", value=str(after.name) + "#" +
                                                      str(after.discriminator), inline=False)

                await channel.send(embed=embed)

                if role.id == 758045775300264146:
                    await after.send(":envelope_with_arrow: **Hep ! Psssst !** Maintenant que tu es un membre de Stryx,"
                                     " il est de mon devoir de t'informer que tu es désormais soumis à une période "
                                     "d'essai **d'une semaine** avant que tu ne fasses vraiment partie de la famille ! "
                                     ":partying_face:\n\n:owl: **__Il y a plusieurs critères à respecter pour valider "
                                     "ta période d'essai__** : :owl:\n\n:arrow_right: **Nous aimerions te connaitre** un"
                                     " minimum ! Tu es donc invité à faire une présentation dans le canal #presentation"
                                     " du serveur Discord de guilde. Tu es libre d'y mettre ce que tu veux ! Ne mets "
                                     "pas d'informations personnelles concernant ta vie privée, décris-nous ton profil "
                                     "de joueur ! **C'est obligatoire**.\n\n:arrow_right: **Nous aimons la politesse** "
                                     "! Lorsque tu te connectes en jeu, un \"bonjour\", \"salut\", \"yo tout le monde\""
                                     " est indispensable en /g ! Sans ça, le canal ne vit pas et c'est bien dommage. "
                                     "De même, c'est important de **répondre à ceux qui disent bonjour** ! Pareil "
                                     "quand tu te déconnectes, si tu y penses.\n\n:arrow_right: **Dernier critère** "
                                     "très logique : Si tu es absent pendant ta semaine d'essai, il est évident que "
                                     "nous ne pourrons pas te garder. On ne s'attend pas à 12h de jeu par jour de ta "
                                     "part, mais une présence régulière et impliquée.\n\n:warning: **Détail important**"
                                     ", si un de ces critères est peu ou mal respecté, le Staff se réserve le droit de "
                                     "prolonger ta période d'essai **jusqu'à 2 semaines** afin de déterminer si la "
                                     "première semaine a été représentative ou non de ton profil joueur.\n\nPassée(s) "
                                     "cette/ces deux semaine(s), tu feras officiellement partie de la guilde ! Si tu as"
                                     " des questions ou besoin de précisions, n'hésite pas à contacter un membre du "
                                     "Staff.\n\n**Sois le bienvenu et bon jeu à toi !**")

        for role in before.roles:
            if role not in after.roles:
                channel = discord.utils.get(after.guild.text_channels, id=784163127625121852)

                embed = discord.Embed(title="Un Membre a été modifié",
                                      url="https://discord.com/",
                                      description=("Les roles du membre " + str(after.nick) if str(after.nick) !=
                                                                                               "None" else after.name)
                                                  + " ont été modifié:\nSuppression du role **" + str(role.name) + "**",
                                      color=0x10FF10)

                # Add author, thumbnail, fields, and footer to the embed
                embed.set_author(name=client.user.name, url="https://discord.com/",
                                 icon_url=client.user.avatar_url)
                embed.set_thumbnail(url=after.avatar_url)
                embed.add_field(name="UID", value=str(after.id), inline=False)
                embed.add_field(name="Nametag", value=str(after.name) + "#" +
                                                      str(after.discriminator), inline=False)

                await channel.send(embed=embed)
                return


# DONE
@client.event
async def on_guild_channel_update(before, after):
    channel = discord.utils.get(after.guild.text_channels, id=784163127625121852)

    if before.name != after.name:
        lst = await before.guild.audit_logs(limit=1).flatten()
        who = lst[0].user

        embed = discord.Embed(title="Un Canal a été modifié",
                              url="https://discord.com/",
                              description=(str(who.nick) if str(who.nick) != "None" else str(who.name))
                                          + " vient de **changer le nom d'un canal**: "
                                          + "# " + str(before.name) + " -> " + "# " + str(after.name) + ".",
                              color=0x10FF10)

        # Add author, thumbnail, fields, and footer to the embed
        embed.set_author(name=client.user.name, url="https://discord.com/",
                         icon_url=client.user.avatar_url)
        await channel.send(embed=embed)

    elif before.overwrites != after.overwrites:
        for role in after.overwrites.keys():
            if role in before.overwrites.keys():
                change = "**Role**: *" + role.name + "*:\n"
                n = 0
                for couple in before.overwrites[role]:
                    for couple1 in after.overwrites[role]:
                        if couple1[0] == couple[0]:
                            if couple1[1] != couple[1]:
                                change += couple[0] + ": " + str(couple[1]) + " -> " + str(couple1[1]) + "\n"
                                n += 1
                            break
                if n == 0:
                    continue
                lst = await before.guild.audit_logs(limit=1).flatten()
                who = lst[0].user
                embed = discord.Embed(title="Un Canal a été modifié",
                                      url="https://discord.com/",
                                      description=(str(who.nick) if str(who.nick) != "None" else str(who.name))
                                                  + " vient de **changer les permissions du canal** "
                                                  + "#" + str(before.name) + ":\n\n" + change[:-1],
                                      color=0x10FF10)
                # Add author, thumbnail, fields, and footer to the embed
                embed.set_author(name=client.user.name, url="https://discord.com/",
                                 icon_url=client.user.avatar_url)
                await channel.send(embed=embed)

        for role in before.overwrites.keys():
            if role not in after.overwrites.keys():
                lst = await before.guild.audit_logs(limit=1).flatten()
                who = lst[0].user
                embed = discord.Embed(title="Un Canal a été modifié",
                                      url="https://discord.com/",
                                      description=(str(who.nick) if str(who.nick) != "None" else str(who.name))
                                                  + " vient de **supprimer un role des permissions du canal** "
                                                  + "#" + str(before.name) + ":\n" + "**Role**: *" + role.name + "*:\n",
                                      color=0x10FF10)
                # Add author, thumbnail, fields, and footer to the embed
                embed.set_author(name=client.user.name, url="https://discord.com/",
                                 icon_url=client.user.avatar_url)
                await channel.send(embed=embed)


# DONE
@client.event
async def on_guild_channel_create(channel):
    chan = discord.utils.get(channel.guild.text_channels, id=784163127625121852)
    embed = discord.Embed(title="Un Canal a été crée",
                          url="https://discord.com/",
                          description="Le canal #" + str(channel.name) + " vient **d'être crée**. ",
                          color=0x10FF10)

    # Add author, thumbnail, fields, and footer to the embed
    embed.set_author(name=client.user.name, url="https://discord.com/",
                     icon_url=client.user.avatar_url)
    await chan.send(embed=embed)


# DONE
@client.event
async def on_guild_channel_delete(channel):
    chan = discord.utils.get(channel.guild.text_channels, id=784163127625121852)
    embed = discord.Embed(title="Un Canal a été supprimé",
                          url="https://discord.com/",
                          description="Le canal #" + str(channel.name) + " vient **d'être supprimé**. ",
                          color=0x10FF10)

    # Add author, thumbnail, fields, and footer to the embed
    embed.set_author(name=client.user.name, url="https://discord.com/",
                     icon_url=client.user.avatar_url)
    await chan.send(embed=embed)


# DONE
@client.event
async def on_user_update(before, after):
    if before.avatar_url != after.avatar_url:
        guild = discord.utils.get(client.guilds, id=464525404976316416)
        channel = discord.utils.get(guild.text_channels, id=784163127625121852)

        embed = discord.Embed(title="Un Membre a modifié son profil",
                              url="https://discord.com/",
                              description=str(after.name) + " vient de **changer son avatar**",
                              color=0x10FF10)

        # Add author, thumbnail, fields, and footer to the embed
        embed.set_author(name=client.user.name, url="https://discord.com/",
                         icon_url=client.user.avatar_url)
        embed.set_thumbnail(url=after.avatar_url)
        embed.add_field(name="UID", value=str(after.id), inline=False)
        embed.add_field(name="Nametag", value=str(after.name) + "#" +
                                              str(after.discriminator), inline=False)

        await channel.send(embed=embed)


# DONE
@client.event
async def on_guild_role_create(role):
    channel = discord.utils.get(role.guild.text_channels, id=784163127625121852)
    lst = await role.guild.audit_logs(limit=1).flatten()
    who = lst[0].user

    embed = discord.Embed(title="Un Role a été crée",
                          url="https://discord.com/",
                          description=(str(who.nick) if str(who.nick) != "None" else who.name)
                                      + " vient de **créer un nouveau role**: " + role.name + ".",
                          color=0x10FF10)

    # Add author, thumbnail, fields, and footer to the embed
    embed.set_author(name=client.user.name, url="https://discord.com/",
                     icon_url=client.user.avatar_url)

    await channel.send(embed=embed)


# DONE
@client.event
async def on_guild_role_delete(role):
    channel = discord.utils.get(role.guild.text_channels, id=784163127625121852)
    lst = await role.guild.audit_logs(limit=1).flatten()
    who = lst[0].user

    embed = discord.Embed(title="Un Role a été supprimé",
                          url="https://discord.com/",
                          description=(str(who.nick) if str(who.nick) != "None" else who.name)
                                      + " vient de **supprimer un role**: " + role.name + ".",
                          color=0x10FF10)

    # Add author, thumbnail, fields, and footer to the embed
    embed.set_author(name=client.user.name, url="https://discord.com/",
                     icon_url=client.user.avatar_url)

    await channel.send(embed=embed)


# DONE
@client.event
async def on_guild_role_update(before, after):
    channel = discord.utils.get(after.guild.text_channels, id=784163127625121852)
    lst = await after.guild.audit_logs(limit=1).flatten()
    who = lst[0].user

    if before.name != after.name:
        embed = discord.Embed(title="Un Role a été modifié",
                              url="https://discord.com/",
                              description=(str(who.nick) if str(who.nick) != "None" else who.name)
                                          + " vient de **modifier le nom d'un role**: " + before.name + " -> "
                                          + after.name + ".",
                              color=0x10FF10)

        # Add author, thumbnail, fields, and footer to the embed
        embed.set_author(name=client.user.name, url="https://discord.com/",
                         icon_url=client.user.avatar_url)

        await channel.send(embed=embed)

    if before.permissions != after.permissions:
        embed = discord.Embed(title="Un Role a été modifié",
                              url="https://discord.com/",
                              description=(str(who.nick) if str(who.nick) != "None" else who.name)
                                          + " vient de **modifier les permissions d'un role**: " + after.name + ".",
                              color=0x10FF10)

        # Add author, thumbnail, fields, and footer to the embed
        embed.set_author(name=client.user.name, url="https://discord.com/",
                         icon_url=client.user.avatar_url)

        await channel.send(embed=embed)


# DONE
@client.event
async def on_voice_state_update(member, before, after):
    now = datetime.now()
    lst = await member.guild.audit_logs(limit=1).flatten()
    when = lst[0].created_at
    if when.minute != now.minute or when.second != now.second:
        return
    who = lst[0].user

    if before.channel is not None and after.channel is not None:
        if before.channel.name != after.channel.name and who.id != member.id:
            channel = discord.utils.get(member.guild.text_channels, id=784163127625121852)

            embed = discord.Embed(title="Un Membre a été déplacé",
                                  url="https://discord.com/",
                                  description=(str(who.nick) if str(who.nick) != "None" else who.name)
                                              + " vient de **déplacer "
                                              + (str(member.nick) if str(member.nick) != "None" else member.name)
                                              + "**: " + before.channel.name + " -> "
                                              + after.channel.name + ".",
                                  color=0x10FF10)

            # Add author, thumbnail, fields, and footer to the embed
            embed.set_author(name=client.user.name, url="https://discord.com/",
                             icon_url=client.user.avatar_url)

            await channel.send(embed=embed)


@client.event
async def on_member_ban(guild, user):
    channel = discord.utils.get(guild.text_channels, id=784163127625121852)

    embed = discord.Embed(title="Un Utilisateur a été banni",
                          url="https://discord.com/",
                          description=str(user.name) + "#" + str(user.discriminator) + " vient **d'être banni "
                                                                                       "du serveur**.",
                          color=0xFF1010)

    # Add author, thumbnail, fields, and footer to the embed
    embed.set_author(name=client.user.name, url="https://discord.com/",
                     icon_url=client.user.avatar_url)
    embed.set_thumbnail(url=user.avatar_url)
    embed.add_field(name="UID", value=str(user.id), inline=False)
    embed.add_field(name="Nametag", value=str(user.name) + "#" + str(user.discriminator), inline=False)

    await channel.send(embed=embed)


@client.event
async def on_member_unban(guild, user):
    channel = discord.utils.get(guild.text_channels, id=784163127625121852)

    embed = discord.Embed(title="Un Utilisateur a été debanni",
                          url="https://discord.com/",
                          description=str(user.name) + "#" + str(user.discriminator) + " vient **d'être debanni "
                                                                                       "dans le serveur**.",
                          color=0xFF1010)

    # Add author, thumbnail, fields, and footer to the embed
    embed.set_author(name=client.user.name, url="https://discord.com/",
                     icon_url=client.user.avatar_url)
    embed.set_thumbnail(url=user.avatar_url)
    embed.add_field(name="UID", value=str(user.id), inline=False)
    embed.add_field(name="Nametag", value=str(user.name) + "#" + str(user.discriminator), inline=False)

    await channel.send(embed=embed)


@client.event
async def on_guild_update(before, after):
    channel = discord.utils.get(after.text_channels, id=784163127625121852)

    if before.name != after.name:
        lst = await before.audit_logs(limit=1).flatten()
        who = lst[0].user

        embed = discord.Embed(title="Le Serveur a été modifié",
                              url="https://discord.com/",
                              description=(str(who.nick) if str(who.nick) != "None" else str(who.name))
                                          + " vient de **changer le nom du serveur**: "
                                          + str(before.name) + " -> " + str(after.name) + ".",
                              color=0x10FF10)

        # Add author, thumbnail, fields, and footer to the embed
        embed.set_author(name=client.user.name, url="https://discord.com/",
                         icon_url=client.user.avatar_url)
        await channel.send(embed=embed)

    elif before.default_notifications != after.default_notifications:
        lst = await before.audit_logs(limit=1).flatten()
        who = lst[0].user

        embed = discord.Embed(title="Le Serveur a été modifié",
                              url="https://discord.com/",
                              description=(str(who.nick) if str(who.nick) != "None" else str(who.name))
                                          + " vient de **changer les paramètres de notifications du serveur**: "
                                          + str(before.default_notifications)[len("NotificationLevel."):] + " -> " +
                                          str(after.default_notifications)[len("NotificationLevel."):] + ".",
                              color=0x10FF10)

        # Add author, thumbnail, fields, and footer to the embed
        embed.set_author(name=client.user.name, url="https://discord.com/",
                         icon_url=client.user.avatar_url)
        await channel.send(embed=embed)

    elif before.afk_channel != after.afk_channel:
        lst = await before.audit_logs(limit=1).flatten()
        who = lst[0].user

        embed = discord.Embed(title="Le Serveur a été modifié",
                              url="https://discord.com/",
                              description=(str(who.nick) if str(who.nick) != "None" else str(who.name))
                                          + " vient de **changer le canal AFK du serveur**: "
                                          + (str(before.afk_channel.name) if before.afk_channel != None else "None")
                                          + " -> " + (
                                              str(after.afk_channel.name) if after.afk_channel != None else "None")
                                          + ".",
                              color=0x10FF10)

        # Add author, thumbnail, fields, and footer to the embed
        embed.set_author(name=client.user.name, url="https://discord.com/",
                         icon_url=client.user.avatar_url)
        await channel.send(embed=embed)

    elif before.afk_timeout != after.afk_timeout:
        lst = await before.audit_logs(limit=1).flatten()
        who = lst[0].user

        embed = discord.Embed(title="Le Serveur a été modifié",
                              url="https://discord.com/",
                              description=(str(who.nick) if str(who.nick) != "None" else str(who.name))
                                          + " vient de **changer le delai d'AFK du serveur**: "
                                          + str(before.afk_timeout // 60) + " mins -> " +
                                          str(after.afk_timeout // 60) + " mins.",
                              color=0x10FF10)

        # Add author, thumbnail, fields, and footer to the embed
        embed.set_author(name=client.user.name, url="https://discord.com/",
                         icon_url=client.user.avatar_url)
        await channel.send(embed=embed)

    elif before.verification_level != after.verification_level:
        lst = await before.audit_logs(limit=1).flatten()
        who = lst[0].user

        embed = discord.Embed(title="Le Serveur a été modifié",
                              url="https://discord.com/",
                              description=(str(who.nick) if str(who.nick) != "None" else str(who.name))
                                          + " vient de **changer le niveau de verification du serveur**: "
                                          + str(before.verification_level) + " -> " +
                                          str(after.verification_level) + ".",
                              color=0x10FF10)

        # Add author, thumbnail, fields, and footer to the embed
        embed.set_author(name=client.user.name, url="https://discord.com/",
                         icon_url=client.user.avatar_url)
        await channel.send(embed=embed)


client.run(TOKEN)
