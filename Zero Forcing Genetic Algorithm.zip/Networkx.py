import networkx as nx
import random
from time import time
# For Data Gathering Analyzing
import numpy as np
import scipy.linalg
from statistics import stdev, mean, StatisticsError


class GraphMatrix:
    """ Takes in a networkx graph and a list of diagonal entries starting from the top left to the bottom right, and
    creates the matrix corresponding to that graph. """

    def __init__(self, graph: nx.Graph, diagonal_entries: list):
        self.matrix = []

        c = 0
        for i in list(graph.nodes()):
            self.matrix.append([])
            for j in list(graph.nodes()):
                if i == j:
                    self.matrix[-1].append(diagonal_entries[c])
                else:
                    self.matrix[-1].append(1 if j in list(graph.adj[i]) else 0)

            c += 1

    """ Shows the matrix of the graph the object was initialized with. If upper is given to be True, shows the 
    upper-triangular form of that matrix. """

    def show(self, upper=False):
        print("[")
        for line in (self.matrix if not upper else self.upper_triangle()):
            print("[", end="")
            for i in range(len(line)):
                if i == len(line) - 1:
                    print((" %.2f" if line[i] >= 0 else "%.2f") % line[i], end="")
                else:
                    print((" %.2f" if line[i] >= 0 else "%.2f") % line[i] + ", ", end="")
            print("]")
        print("]")

    """ Forms and returns the upper-triangular form of the matrix of the given graph. """

    def upper_triangle(self):
        n = len(self.matrix)

        matrix = []
        for line in self.matrix:
            matrix.append(line.copy())

        for c in range(n - 1):
            i = c
            val = -1
            for j in range(len(matrix[c:])):
                if abs(matrix[c:][j][c]) > val:
                    val = abs(matrix[c:][j][c])
                    i = j + c

            if i != c:
                matrix[c], matrix[i] = matrix[i], matrix[c]

            if matrix[c][c] == 0:
                continue

            for line in matrix[c + 1:]:
                m = line[c] / matrix[c][c]
                for k in range(n):
                    line[k] -= m * matrix[c][k]

        return matrix

    """ Returns the rank of the matrix of the given graph. """

    def rank(self):
        n = len(self.matrix)
        return n - self.upper_triangle().count([0] * n)


def forcing_rule(graph: nx.Graph, node0, b):
    """ Returns True if, given a graph and a set of blue vertices b, nodes0 will be forced blue in the next iteration.
    Returns False otherwise. """

    if graph.nodes[node0]["color"] == "blue":
        return True

    """ For every blue node node1 that is adjancent to node0, if node0 is the only white node adjacent to node1, then
     the forcing rule applies, and node0 will be forced blue in the next iteration, therefore return True. 
     If this doesn't apply for any blue node, then node0 won't be forced blue, therefore return False. """
    for node1 in set(graph.adj[node0]).intersection(b):
        if set(graph.adj[node1]).intersection(set(graph.nodes) - b) == {node0}:
            return True

    return False


def psd_rule(graph: nx.Graph, node0, b):
    """ Returns True if, given a graph and a set of blue vertices b, nodes0 will be forced blue in the next iteration
    using the PSD forcing rule.
    Returns False otherwise. """

    if graph.nodes[node0]["color"] == "blue":
        return True

    """ For every blue node node1 that is adjancent to node0, if node0 is not adjancent to any other white vertex 
    adjacent to node1, then node0 will be forced in the next iteration, therefore return True.
    If this doesn't apply for any blue node, then node0 won't be forced blue, therefore return False. """
    for node1 in set(graph.adj[node0]).intersection(b):
        works = True
        for node2 in set(graph.adj[node1]).intersection(set(graph.nodes) - b - {node0}):
            if node0 in set(graph.adj[node2]):
                works = False
                break

        if works:
            return True

    return False


def forcing_process(graph: nx.Graph, b, rule=forcing_rule, t=1):
    """ Applies the forcing rule given to the given graph with the given initial set of blue vertices b. Once the
    forcing process is done, returns the final set of blue vertices. """

    for node1 in b:
        graph.nodes[node1]["color"] = "blue"

    new_b = []
    for node1 in list(graph.nodes):
        if rule(graph, node1, set(b)):
            new_b.append(node1)

    if len(new_b) == len(list(graph.nodes)):
        return new_b, t

    if b == new_b:
        return new_b, t

    return forcing_process(graph, new_b, rule, t + 1)


def zero_forcing(graph: nx.Graph, rule=forcing_rule):
    """ Applies a Genetic Algorithm to the given graph in order to find its minimal zero-forcing set, and therefore
    zero-forcing number. Returns the zero-forcing number. (With a slight tweak the function can return the zero-forcing
    set aswell if need be)"""

    population_size = 8
    num_of_elite_chrom = 1
    tournament_selection_size = 4
    mutation_rate = 0.25
    target_gen = max(37.708025691857216 * len(graph.nodes) + 0.6188752011422203 * len(graph.edges.data()) -
                     225.01828721571377, 30)

    class Chromosome:
        def __init__(self):
            lst = list(graph.nodes)
            k = random.randrange(1, len(lst) + 1)
            self.genes = random.sample(lst, k)
            self.fitness = self.get_fitness()
            self.t = 0

        def get_genes(self):
            return self.genes

        def get_fitness(self):
            for node1 in graph.nodes:
                graph.nodes[node1]["color"] = "white"

            self.fitness = 0
            res = forcing_process(graph, self.genes, rule)
            self.t = res[1]
            forcing = len(res[0])
            if forcing != len(list(graph.nodes)):
                return -10 ** 20
            result = (10 ** 20) - (len(self.genes) + 2) ** 3 - self.t

            for node1 in graph.nodes:
                graph.nodes[node1]["color"] = "white"

            self.fitness = result
            return result

        def __str__(self):
            return self.genes.__str__()

    class Population:
        def __init__(self, size):
            self._chromosomes = []
            i = 0
            while i < size:
                self._chromosomes.append(Chromosome())
                i += 1

        def get_chromosomes(self): return self._chromosomes

    class GeneticAlgorithm:
        @staticmethod
        def evolve(pop):
            return GeneticAlgorithm._mutate_population(GeneticAlgorithm._crossover_population(pop))

        @staticmethod
        def _crossover_population(pop):
            crossover_pop = Population(0)
            for i in range(num_of_elite_chrom):
                crossover_pop.get_chromosomes().append(pop.get_chromosomes()[i])
            i = num_of_elite_chrom
            while i < population_size:
                chromosome1 = GeneticAlgorithm._select_tournament_population(pop).get_chromosomes()[0]
                chromosome2 = GeneticAlgorithm._select_tournament_population(pop).get_chromosomes()[0]
                crossover_pop.get_chromosomes().append(
                    GeneticAlgorithm._crossover_chromosomes(chromosome1, chromosome2))
                i += 1
            return crossover_pop

        @staticmethod
        def _mutate_population(pop):
            for i in range(num_of_elite_chrom, population_size):
                GeneticAlgorithm._mutate_chromosome(pop.get_chromosomes()[i])
            return pop

        @staticmethod
        def _crossover_chromosomes(chromosome1, chromosome2):
            crossover_chrom = Chromosome()
            k = random.randrange(min(len(chromosome1.genes), len(chromosome2.genes)), 1 + max(len(chromosome1.genes),
                                                                                              len(chromosome2.genes)))
            crossover_chrom.genes = list(set(random.sample(chromosome1.genes + chromosome2.genes, k)))
            crossover_chrom.fitness = crossover_chrom.get_fitness()

            return crossover_chrom

        @staticmethod
        def _mutate_chromosome(chromosome):
            if random.random() < mutation_rate:
                lst = list(graph.nodes) + chromosome.genes
                k = random.randrange(1, len(list(graph.nodes)) + 1)
                chromosome.genes = random.sample(lst, k)
                chromosome.genes = list(set(chromosome.genes))
                chromosome.fitness = chromosome.get_fitness()

        @staticmethod
        def _select_tournament_population(pop):
            tournament_pop = Population(0)
            i = 0
            while i < tournament_selection_size:
                tournament_pop.get_chromosomes().append(pop.get_chromosomes()[random.randrange(0, population_size)])
                i += 1
            tournament_pop.get_chromosomes().sort(key=lambda x: x.fitness, reverse=True)
            return tournament_pop

    def _print_population(pop, gen_number):
        print("\n--------------------------------------------------")
        print("Generation #", gen_number, "| Fittest chromosome fitness:", pop.get_chromosomes()[0].get_fitness())
        print("--------------------------------------------------")
        i = 0
        for x in pop.get_chromosomes():
            print("Chromosome  #", i, " :", x, "| Fitness: ", x.get_fitness())
            i += 1

    population = Population(population_size)
    population.get_chromosomes().sort(key=lambda x: x.get_fitness(), reverse=True)
    # _print_population(population, 0)
    generation_number = 1
    while generation_number <= target_gen:
        old1, old2 = len(population.get_chromosomes()[0].genes), population.get_chromosomes()[0].t
        population = GeneticAlgorithm.evolve(population)
        population.get_chromosomes().sort(key=lambda x: x.get_fitness(), reverse=True)
        # _print_population(population, generation_number)
        generation_number += 1

    population.get_chromosomes().sort(key=lambda x: x.fitness, reverse=True)
    return len(population.get_chromosomes()[0].genes), population.get_chromosomes()[0].t, population.get_chromosomes()[
        0].genes


def throttling_num(graph: nx.Graph, rule=forcing_rule):
    """ Applies a Genetic Algorithm to the given graph in order to find its minimal zero-forcing set, and therefore
    zero-forcing number. Returns the zero-forcing number. (With a slight tweak the function can return the zero-forcing
    set aswell if need be)"""

    population_size = 8
    num_of_elite_chrom = 1
    tournament_selection_size = 4
    mutation_rate = 0.25
    target_gen = max(37.708025691857216 * len(graph.nodes) + 0.6188752011422203 * len(graph.edges.data()) -
                     225.01828721571377, 30)

    class Chromosome:
        def __init__(self):
            lst = list(graph.nodes)
            k = random.randrange(1, len(lst) + 1)
            self.genes = random.sample(lst, k)
            self.fitness = self.get_fitness()
            self.t = 0

        def get_genes(self):
            return self.genes

        def get_fitness(self):
            for node1 in graph.nodes:
                graph.nodes[node1]["color"] = "white"
            self.fitness = 0
            res = forcing_process(graph, self.genes, rule)
            self.t = res[1]
            forcing = len(res[0])
            if forcing != len(list(graph.nodes)):
                return -10 ** 20
            result = (10 ** 20) - len(self.genes) - self.t

            for node1 in graph.nodes:
                graph.nodes[node1]["color"] = "white"

            self.fitness = result
            return result

        def __str__(self):
            return self.genes.__str__()

    class Population:
        def __init__(self, size):
            self._chromosomes = []
            i = 0
            while i < size:
                self._chromosomes.append(Chromosome())
                i += 1

        def get_chromosomes(self): return self._chromosomes

    class GeneticAlgorithm:
        @staticmethod
        def evolve(pop):
            return GeneticAlgorithm._mutate_population(GeneticAlgorithm._crossover_population(pop))

        @staticmethod
        def _crossover_population(pop):
            crossover_pop = Population(0)
            for i in range(num_of_elite_chrom):
                crossover_pop.get_chromosomes().append(pop.get_chromosomes()[i])
            i = num_of_elite_chrom
            while i < population_size:
                chromosome1 = GeneticAlgorithm._select_tournament_population(pop).get_chromosomes()[0]
                chromosome2 = GeneticAlgorithm._select_tournament_population(pop).get_chromosomes()[0]
                crossover_pop.get_chromosomes().append(
                    GeneticAlgorithm._crossover_chromosomes(chromosome1, chromosome2))
                i += 1
            return crossover_pop

        @staticmethod
        def _mutate_population(pop):
            for i in range(num_of_elite_chrom, population_size):
                GeneticAlgorithm._mutate_chromosome(pop.get_chromosomes()[i])
            return pop

        @staticmethod
        def _crossover_chromosomes(chromosome1, chromosome2):
            crossover_chrom = Chromosome()
            k = random.randrange(min(len(chromosome1.genes), len(chromosome2.genes)), 1 + max(len(chromosome1.genes),
                                                                                              len(chromosome2.genes)))
            crossover_chrom.genes = list(set(random.sample(chromosome1.genes + chromosome2.genes, k)))
            crossover_chrom.fitness = crossover_chrom.get_fitness()

            return crossover_chrom

        @staticmethod
        def _mutate_chromosome(chromosome):
            if random.random() < mutation_rate:
                lst = list(graph.nodes) + chromosome.genes
                k = random.randrange(1, len(list(graph.nodes)) + 1)
                chromosome.genes = random.sample(lst, k)
                chromosome.genes = list(set(chromosome.genes))
                chromosome.fitness = chromosome.get_fitness()

        @staticmethod
        def _select_tournament_population(pop):
            tournament_pop = Population(0)
            i = 0
            while i < tournament_selection_size:
                tournament_pop.get_chromosomes().append(pop.get_chromosomes()[random.randrange(0, population_size)])
                i += 1
            tournament_pop.get_chromosomes().sort(key=lambda x: x.fitness, reverse=True)
            return tournament_pop

    def _print_population(pop, gen_number):
        print("\n--------------------------------------------------")
        print("Generation #", gen_number, "| Fittest chromosome fitness:", pop.get_chromosomes()[0].get_fitness())
        print("--------------------------------------------------")
        i = 0
        for x in pop.get_chromosomes():
            print("Chromosome  #", i, " :", x, "| Fitness: ", x.get_fitness())
            i += 1

    population = Population(population_size)
    population.get_chromosomes().sort(key=lambda x: x.get_fitness(), reverse=True)
    # _print_population(population, 0)
    generation_number = 1
    while generation_number <= target_gen:
        old1, old2 = len(population.get_chromosomes()[0].genes), population.get_chromosomes()[0].t
        population = GeneticAlgorithm.evolve(population)
        population.get_chromosomes().sort(key=lambda x: x.get_fitness(), reverse=True)
        # _print_population(population, generation_number)
        generation_number += 1

    population.get_chromosomes().sort(key=lambda x: x.fitness, reverse=True)
    return len(population.get_chromosomes()[0].genes) + population.get_chromosomes()[0].t


# Test

G = nx.Graph()
G.add_edges_from([(1, 7), (1, 5), (2, 7), (2, 6), (3, 6), (0, 5), (0, 6), (5, 7), (6, 7), (4, 7)])
for node in G.nodes:
    G.nodes[node]["color"] = "white"

t = time()
z = zero_forcing(G, psd_rule)
print(time() - t)
t = throttling_num(G, psd_rule)
print("1. Zero Forcing number: " + str(z[0]) + "  |  Propagation number: " + str(z[1]) + "  |  Zero Forcing Set: " +
      str(z[2]))
print("2. Minimal throttling number: " + str(t))


# Data Collection and Analyzing
"""f = open("file.txt", 'w')
for j in range(3, 20):
    for i in range(500):
        randomG = nx.fast_gnp_random_graph(j, random.random())
        f.write(str(randomG.order()) + "\n")
        for k in randomG.edges:
            f.write(str(k[0]) + " " + str(k[1]) + "\n")
        f.write("-1\n")"""

# ENABLE FOR REGRESSION
"""
gen = {}
f = open("output.txt", "r")
data = f.read().split("\n")[:-1]
for piece in data:
    order, edges, target = 0, 0, 0
    try:
        order = int(piece.split(" ")[0])
        edges = int(piece.split(" ")[1])
        target = int(piece.split(" ")[2])
    except:
        print(piece)

    if (order, edges) in gen.keys():
        gen[(order, edges)].append(target)
    else:
        gen[(order, edges)] = [target]"""

"""
gen = {}
for j in range(3, 20):
    for i in range(500):
        randomG = nx.fast_gnp_random_graph(j, random.random())
        for node in randomG.nodes:
            randomG.nodes[node]["color"] = "white"
        z = zero_forcing(randomG)

        if (len(list(randomG.nodes)), len(list(randomG.edges.data()))) in gen.keys():
            gen[(len(list(randomG.nodes)), len(list(randomG.edges.data())))].append(z[3])
        else:
            gen[(len(list(randomG.nodes)), len(list(randomG.edges.data())))] = [z[3]]

    print(str(j) + " done.")"""

# ENABLE FOR REGRESSION
"""
gen1 = dict()
for key in gen.keys():
    try:
        gen1[key] = mean(gen[key]) + 2.5 * abs(stdev(gen[key]))
    except StatisticsError:
        pass

keys = list(gen1.keys())

x = [key[0] for key in keys]
y = [gen1[key] for key in keys]
z = np.polyfit(x, y, 1, full=True)
print(z)"""

"""# some 3-dim points
x = [key[0] for key in keys]
y = [key[1] for key in keys]
z = [gen1[key] for key in keys]
data = np.c_[x, y, z]

# regular grid covering the domain of the data

mn = np.min(data, axis=0)
mx = np.max(data, axis=0)

X, Y = np.meshgrid(np.linspace(mn[0], mx[0], 20), np.linspace(mn[1], mx[1], 20))
XX = X.flatten()
YY = Y.flatten()
Z = 0

order = 1  # 1: linear, 2: quadratic
if order == 1:
    # best-fit linear plane
    A = np.c_[data[:, 0], data[:, 1], np.ones(data.shape[0])]
    C, _, _, _ = scipy.linalg.lstsq(A, data[:, 2])  # coefficients

elif order == 2:
    # best-fit quadratic curve
    A = np.c_[np.ones(data.shape[0]), data[:, :2], np.prod(data[:, :2], axis=1), data[:, :2] ** 2]
    C, _, _, _ = scipy.linalg.lstsq(A, data[:, 2])

print("A = {", end="")
for key in gen1.keys():
    print("(" + str(key[0]) + ", " + str(key[1]) + ", " + str(gen1[key]) + "), ", end="")

print("\n" + str(C[0]) + "*X + " + str(C[1]) + "*Y + " + str(C[2]))"""


"""A = GraphMatrix(G, [1, 1, 1, 1, 1, 1, 1])
A.show(True)
print("\n\nMatrix Rank: " + str(A.rank()))
"""
