#ifndef ZF_GA_H
#define ZF_GA_H
#include "graph.hpp"
#include <random>
#include <set>
#include <stdlib.h>
#include <limits.h>
#include <time.h>

/* Zero-Forcing Closure */
int closure(const Graph* graph,const set<int>* genes);

/* Zero-Forcing Greedy Heuristic */
void greedy(const Graph* graph, set<int>* zf_set);

/* Zero-Forcing Genetic Algorithm */
void zf_ga(const Graph* graph, set<int>* zf_set, int* zf_num);

/* Chromosome Class */
class Chromosome{
public:
	int fitness;
	set<int> genes;
	
	Chromosome(){}
	Chromosome(const Graph* graph){
		vector<int> in(graph->order), out;
		for(unsigned int i=0; i<graph->order; ++i){
			in[i] = i;
		}
		sample(in.cbegin(), in.cend(), back_inserter(out), rand()%graph->order + 1, mt19937{random_device{}()});
		for(unsigned int i=0; i<out.size(); ++i){
			genes.insert(out[i]);
		}
		if(closure(graph,&genes) < graph->order){
			fitness = INT_MAX;
		}
		else{
			fitness = genes.size();
		}
	}
	Chromosome(const Graph* graph, set<int>* genes0){
		genes = *genes0;
		if(closure(graph,&genes) < graph->order){
			fitness = INT_MAX;
		}
		else{
			fitness = genes.size();
		}
	}
	bool operator < (const Chromosome& rhs) const {
		return fitness < rhs.fitness;
	}
};
#endif