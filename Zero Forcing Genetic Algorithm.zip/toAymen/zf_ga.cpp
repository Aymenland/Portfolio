#include "zf_ga.hpp"
#include <algorithm>
#include <iostream>
#include <queue>

/* Zero-Forcing Closure */
int closure(const Graph* graph,const set<int>* genes){
	// initialize set of colored
	set<int> colored = *genes;
	// initialize forcing vectors
	vector<int> *forced1, *forced2;
	// initialize queue of active vertices (vertices that can be forced)
	queue<int> active;
	for(auto i=colored.cbegin(); i!=colored.cend(); ++i){
		forced1 = new vector<int>;
		for(auto j=graph->neighbors.at(*i).cbegin(); j!=graph->neighbors.at(*i).cend(); ++j){
			if(colored.find(*j)==colored.cend()){
				forced1->push_back(*j);						// vertex *j is a non-forced neighbor of *i
			}
		}
		if(forced1->size()==1){
			active.push((*forced1)[0]);						// only one non-forced neighbor of *i; hence, this neighbor is active (can be forced by *i)
		}
		delete forced1;										// free forced1 memory
	}
	// while active is non-empty
	int v;
	while(! active.empty()){
		v = active.front(); active.pop();					// set force vertex v and pop this element off
		if(colored.find(v)==colored.cend()){
			colored.insert(v);								// add vertex v to colored
			// check which neighbors of v can be forced
			forced1 = new vector<int>;
			for(auto i=graph->neighbors.at(v).cbegin(); i!=graph->neighbors.at(v).cend(); ++i){
				if(colored.find(*i)==colored.cend()){
					forced1->push_back(*i);					// vertex *i is a non-forced neighbor of v
				}
				else{
					// vertex *i is a forced neighbor of v, check which neighbors of *i can be forced
					forced2 = new vector<int>;
					for(auto j=graph->neighbors.at(*i).cbegin(); j!=graph->neighbors.at(*i).cend(); ++j){
						if(colored.find(*j)==colored.cend()){
							forced2->push_back(*j);			// vertex *j is a non-forced neighbor of *i
						}
					}
					if(forced2->size()==1){
						active.push((*forced2)[0]);			// only one non-forced neighbor of *i; hence, this neighbor is active (can be forced by *i)
					}
					delete forced2;							// free forced2 memory
				}	
			}
			if(forced1->size()==1){
				active.push((*forced1)[0]);
			}
			delete forced1;									// free forced1 memory	
		}
	}
	// return cardinality of closure
	return colored.size();
}

/* Zero-Forcing Greedy Heuristic */
void greedy(const Graph* graph, set<int>* zf_set){
	// initialize active vector
	// initialize active_vec, node_vec, and sample_vec;
	vector<int> *active_vec, *node_vec, *sample_vec;
	node_vec = new vector<int>(graph->order);
	for(unsigned int i=0; i<graph->order; ++i){
		(*node_vec)[i] = i;
	}
	// initialize temp set, best vertex, and best cardinality of closure
	set<int> *temp;
	int best_u, best_c = 0, u, c;
	// find zero-forcing set
	while(best_c < graph->order){
		active_vec = new vector<int>;								// fill active with vertices not in zf_set
		sample_vec = new vector<int>;								// vertices are stored in a random order from sample
		sample(node_vec->cbegin(), node_vec->cend(), back_inserter(*sample_vec), graph->order, mt19937{random_device{}()});
		for(auto i=sample_vec->cbegin(); i!=sample_vec->cend(); ++i){
			if(zf_set->find(*i)==zf_set->cend()){
				active_vec->push_back(*i);
			}
		}
		delete sample_vec;											// free sample_vec memory
		temp = new set<int>(zf_set->cbegin(),zf_set->cend());		// set temp to zero-forcing set
		best_u = (*active_vec)[0];									// set best_u to first element of active_vec
		temp->insert(best_u);										// insert best_u into temp
		best_c = closure(graph,temp);								// compute closure of temp and store cardinality in best_c
		u = best_u;													// set u to best_u
		// find best_u and best_c
		for(unsigned int i=1; i<active_vec->size(); ++i){
			temp->erase(u);											// remove u from temp
			u = (*active_vec)[i];									// set u to active_vec[i]
			temp->insert(u);										// insert u into temp
			c = closure(graph,temp);								// compute closure of temp and store cardinality in c
			if(c > best_c){											// check if c > best_c, if so, switch best_u with u and best_c with c
				best_u = u;
				best_c = c;
			}
		}
		zf_set->insert(best_u);										// add best_u to zf_set
		delete temp; 												// free temp memory
		delete active_vec;											// free active_vec memory
	}
	delete node_vec;												// free node_vec memory
}

/* tournament selection */
void tourn_sel(const vector<Chromosome>* pop,Chromosome* chrom,const int tourn_sel_size){
	// initialize tournament population
	vector<Chromosome> tourn_pop;
	// random sample of population is placed in tourn_pop
	sample(pop->cbegin(), pop->cend(), back_inserter(tourn_pop), tourn_sel_size, mt19937{random_device{}()});
	// set minimum from tourn_pop equal to chrom
	*chrom = *min_element(tourn_pop.cbegin(), tourn_pop.cend());
}

/* evolve */
void evolve(const Graph* graph,vector<Chromosome>* pop,const int pop_size,const int num_elite_chrom,const int tourn_sel_size,const double mut_rate){
	// initialize genes, sample, chromosome pointers, and max and min card. 
	vector<int> *genes_vec, *sample_vec;
	set<int>* genes_set;
	Chromosome *chromx, *chromy;
	int min_card, max_card;
	// update pop[i] for i=num_elite_chrom ... pop_size
	for(unsigned int i=num_elite_chrom; i<pop_size; ++i){
		chromx = new Chromosome();					 
		chromy = new Chromosome();
		tourn_sel(pop,chromx,tourn_sel_size);										// tournament for chromx
		tourn_sel(pop,chromy,tourn_sel_size);										// tournament for chromy
		genes_vec = new vector<int>(chromx->genes.cbegin(),chromx->genes.cend());
		for(auto j=chromy->genes.cbegin(); j!=chromy->genes.cend(); ++j){
			genes_vec->push_back(*j);												// genes_vec contains genes from chromx and chromy
		}
		sample_vec = new vector<int>;												// sample_vec is a random sample of genes_vec
		min_card = min(chromx->genes.size(),chromy->genes.size());
		max_card = max(chromx->genes.size(),chromy->genes.size());
		sample(genes_vec->cbegin(), genes_vec->cend(), back_inserter(*sample_vec), rand()%(max_card+1-min_card)+min_card, mt19937{random_device{}()});
		genes_set = new set<int>(sample_vec->cbegin(),sample_vec->cend());
		(*pop)[i] = Chromosome(graph,genes_set);									// set pop[i] equal to Chromosome created from sample_vec
		delete chromx; 																// free chromx
		delete chromy;																// free chromy
		delete genes_vec;															// free genes_vec memory
		delete sample_vec;															// free sample_vec memory
		delete genes_set;															// free genes_set memory
		// random mutation
		if(((double)rand()/RAND_MAX) < mut_rate){
			genes_vec = new vector<int>((*pop)[i].genes.cbegin(),(*pop)[i].genes.cend());
			for(unsigned int j=0; j<graph->order; ++j){
				genes_vec->push_back(j);											// genes_vec contains pop[i].genes and graph vertices
			}
			sample_vec = new vector<int>;											// sample_vec is a random sample of genes_vec
			sample(genes_vec->cbegin(), genes_vec->cend(), back_inserter(*sample_vec), rand()%graph->order + 1, mt19937{random_device{}()});
			genes_set = new set<int>(sample_vec->cbegin(),sample_vec->cend());
			(*pop)[i] = Chromosome(graph,genes_set);								// set pop[i] equal to Chromosome created from sample_vec
			delete genes_vec;														// free genes_vec memory
			delete sample_vec;														// free sample_vec memory
			delete genes_set;														// free genes_set memory
		}
	}
	sort(pop->begin(),pop->end());													// sort new population
}

/* Zero-Forcing Genetic Algorithm */
void zf_ga(const Graph* graph, set<int>* zf_set, int* zf_num){
	// genetic algorithm variables
    int pop_size = 2*graph->order;
    int num_elite_chrom = 1;
    int tourn_sel_size = graph->order;
    double mut_rate = 0.30;
    int max_gen = 10*graph->order;
	// initial population
	vector<Chromosome> pop(pop_size);
	set<int> genes;
	greedy(graph,&genes);
	pop[0] = Chromosome(graph,&genes);
	for(unsigned int i=1; i<pop_size; ++i){
		pop[i] = Chromosome(graph);
	}
	sort(pop.begin(),pop.end());
	// update population
	for(unsigned int i=0; i<max_gen; i++){
		evolve(graph,&pop,pop_size,num_elite_chrom,tourn_sel_size,mut_rate);
	}
	// zero-forcing set and number
	for(auto i=pop[0].genes.cbegin(); i!=pop[0].genes.cend(); ++i){
		zf_set->insert(*i);
	}
	*zf_num = pop[0].fitness;
}

/* main function */
/*
int main(int argc,char** argv){
	// zero-forcing set and number storage
	set<int>* zf_set;
	int zf_num;
	// create and print graph
	char str[] = "G?be^S";
	Graph graph = Graph(str, sizeof(str)-1);
	graph.print();
	// random chromosome 
	Chromosome chrom = Chromosome(&graph);
	cout << "random chromosome, fitness " << chrom.fitness << ": " <<  endl;
	for(auto i=chrom.genes.cbegin(); i!=chrom.genes.cend(); ++i){
		cout << "\t " << *i << endl;
	}
	cout << "size of closure for random chromosome = " << closure(&graph, &chrom.genes) << endl;
	// greedy heuristic
	zf_set = new set<int>;
	greedy(&graph,zf_set);
	cout << "greedy zf_set: " << endl;
	for(auto i=zf_set->cbegin(); i!=zf_set->cend(); ++i){
		cout << "\t " << *i << endl;
	}
	cout << "size of closure for greedy zf_set = " << closure(&graph, zf_set) << endl;
	delete zf_set;
	// genetic algorithm
	zf_set = new set<int>;
	zf_ga(&graph, zf_set, &zf_num);
	cout << "GA zf_set: " << endl;
	for(auto i=zf_set->cbegin(); i!=zf_set->cend(); ++i){
		cout << "\t " << *i << endl;
	}
	cout << "GA zf_num: " << zf_num << endl;
	cout << "size of closure for GA zf_set = " << closure(&graph, zf_set) << endl;
	delete zf_set;
	return 0;
}
*/