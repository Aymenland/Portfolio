#include "graph.hpp"
#include <algorithm>

/* complement */
void complement(const Graph* graph, Graph* comp_graph){
	// store order
	comp_graph->order = graph->order;
	// store size
	comp_graph->size = graph->order*(graph->order-1)/2 - graph->size;
	// store edges
	pair<int,int>* temp;
	for(int i=0; i<graph->order; ++i){
		for(int j=i+1; j<graph->order; ++j){
			temp = new pair<int,int>(i,j);
			if(find(graph->edges.cbegin(),graph->edges.cend(),*temp)==graph->edges.cend()){
				comp_graph->edges.push_back(*temp);
			}
			delete temp;
		}
	}
	// store neighbors
	vector<int>* nbhd;
	for(int i=0; i<comp_graph->order; ++i){
		nbhd = new vector<int>;
		for(int j=0; j<comp_graph->size; ++j){
			if(comp_graph->edges[j].first==i){
				nbhd->push_back(comp_graph->edges[j].second);
			}
			else if(comp_graph->edges[j].second==i){
				nbhd->push_back(comp_graph->edges[j].first);
			}
		}
		comp_graph->neighbors.insert(pair<int,vector<int>>(i,*nbhd));
		delete nbhd;
	}
}

/* main function */
/*
int main(int argc,char** argv){
	char str[] = "ITY}F~HS?";
	Graph graph = Graph(str, sizeof(str)-1);
	graph.print();
	
	Graph comp_graph = Graph();
	complement(&graph,&comp_graph);
	comp_graph.print();
	
	return 0;
}
*/