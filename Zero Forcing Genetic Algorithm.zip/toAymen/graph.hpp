#ifndef GRAPH_H
#define GRAPH_H
#include <iostream>
#include <map>
#include <utility>
#include <vector>

using namespace std;

/* Graph class */
class Graph{
public: 
	int order, size;
	vector<pair<int,int>> edges;
	map<int,vector<int>> neighbors;
	
	void print(){
		cout << "order: " << order << endl;
		cout << "size: " << size << endl;
		cout << "edges:" << endl;
		for(unsigned int i=0; i<size; ++i){
			cout << "\t (" << edges[i].first << "," << edges[i].second << ")" << endl;
		}
		cout << "neighbors: " << endl;
		for(unsigned int i=0; i<order; ++i){
			cout << "\t " << i << ": ";
			for(auto j = neighbors[i].cbegin(); j != neighbors[i].cend(); ++j){
				if(j < neighbors[i].cend()-1){
					cout << *j << ", ";	
				}
				else{
					cout << *j << endl;
				}
			}
			if(neighbors[i].empty()){
				cout << endl;
			}
		}
	}
	
	Graph(){}
	Graph(const char* str, size_t length){
		// loop variables
		int i, j, k;
		// data arrays
		int data[length], *edge_data;
		// subtract 63 from each line character and store integer in data
		for(i = 0; i<length; ++i){
			data[i] = str[i] - 63;
		}
		// graph order and edge data
		if(data[0]<=62){
			order = data[0];
			edge_data = &data[1];
			length -= 1;
		}
		else if(data[1]<=62){
			order = (data[1] << 12) + (data[2] << 6) + data[3];
			edge_data = &data[4];
			length -= 4;
		}
		else{
			order = (data[2] << 30) + (data[3] << 24) + (data[4] << 18) + (data[5] << 12) + (data[6] << 6) + data[7];
			edge_data = &data[8];
			length -= 8;
		}
		// graph size and edge bits
		k = 0;
		size = 0;
		bool bits[length*6];
		for(i=0; i<length; ++i){
			for(j=5; j>=0; j--){
				bits[k] = (edge_data[i] >> j) & 1;
				if(bits[k]){
					size += 1;
				}
				k += 1;
			}
		}
		// store edges
		k=0;
		for(j=1; j<order; ++j){
			for(i=0; i<j; ++i){
				if(bits[k]){
					edges.push_back(make_pair(i,j));
				}
				k += 1;
			}
		}
		// store neighbors
		vector<int>* nbhd;
		for(i=0; i<order; ++i){
			nbhd = new vector<int>;
			for(j=0; j<size; ++j){
				if(edges[j].first==i){
					nbhd->push_back(edges[j].second);
				}
				else if(edges[j].second==i){
					nbhd->push_back(edges[j].first);
				}
			}
			neighbors.insert(pair<int,vector<int>>(i,*nbhd));
			delete nbhd;
		}
	}
};

/* complement */
void complement(const Graph* graph, Graph* comp_graph);
#endif