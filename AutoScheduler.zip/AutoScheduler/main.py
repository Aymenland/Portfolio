from math import ceil
from random import sample, randint
from csv import reader
from matplotlib import pyplot as plt


def is_within(time0, interval):
    time0 = time0.split(":")
    interval = (interval[0].split(":"), interval[1].split(":"))

    if int(interval[0][0]) < int(time0[0]) < int(interval[1][0]):
        return True

    elif int(time0[0]) == int(interval[0][0]):
        return int(time0[1]) >= int(interval[0][1])

    elif int(time0[0]) == int(interval[1][0]):
        return int(time0[1]) <= int(interval[1][1])


def create_schedule(day, n_of_centers):
    print(">", day)
    file = open("Staff Qualification and Availability June 2022 - Sheet2-2.csv", "r", newline="", encoding="utf-8")
    lines = list(reader(file))[1:]

    staff_hours = {i + 1: (line[4 + day].split("-")[0].strip(), line[4 + day].split("-")[1].strip())
                   for i, line in enumerate(lines) if line[4 + day] != "-"}
    d_staff = {i + 1 for i in range(len(lines)) if lines[i][3] == "D" if lines[i][4 + day] != "-"}
    senior_staff = {i + 1 for i in range(len(lines)) if lines[i][12].strip().lower() == "y" if lines[i][4 + day] != "-"}
    staff_names = {i + 1: line[0] for i, line in enumerate(lines)}
    staff_rates = {i + 1: int(line[11]) for i, line in enumerate(lines)}

    for _ in range(n_of_centers):
        staff_assignments = schedule(staff_hours, d_staff, staff_names, staff_rates, senior_staff)
        staff_hours = {i: staff_hours[i] for i in staff_hours if i not in staff_assignments}
        d_staff = {i for i in d_staff if i not in staff_assignments}
        senior_staff = {i + 1 for i in range(len(lines)) if lines[i][12].strip().lower() == "y" if
                        lines[i][4 + day] != "-"}


def schedule(staff_hours, d_staff, staff_names, staff_rates, senior_staff):
    required_staff = [2, 2, 2, 3, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 4, 3, 2, 2, 2, 2]

    """
    n0_staff = int(input("Input number of staff: ").strip())
    staff_hours = {i: tuple(input("Enter staff " + str(i) + "'s preferred working hour: ").strip().split(" "))
                   for i in range(1, n0_staff + 1)}

    d_staff = input("\nWhich of the staff have D qualification (numbers from 1 to " + str(n0_staff) + "): ") \
        .strip().split(" ")
    d_staff = {int(i) for i in d_staff}
    """

    times = ["6:30"]
    for _ in range(24):
        t = times[-1].split(":")
        time = (str(int(t[0]) + 1) + ":00") if t[1] == "30" else t[0] + ":30"
        times.append(time)

    # required_staff = input("\nEnter required staff at each point in time: ").strip().split(" ")
    required_staff = dict(zip(times, [int(elem) for elem in required_staff]))

    staff = set()
    print()

    #   ------> TRY TO CREATE A VALID SCHEDULE 50 TIMES
    for k in range(100):
        error = False
        break_minimum_hours = randint(7, 11)

        staff = {i: set() for i in staff_hours}
        shifts = {time: set() for time in times}
        staff_assignments = {i: [] for i in staff_hours}
        chosen_d_staff = set()
        chosen_staff = set()
        out_of_break = 0
        been_on_break = set()
        shift_finished = set()
        break_next = 0

        for i, (time, n_staff) in enumerate(required_staff.items()):
            tired_staff = {j for j in staff if len(staff[j]) == 15}

            if break_next:
                break_staff = break_next
                break_next = 0
            else:
                potential_break_staff = {j for j in staff if is_within(time, staff_hours[j]) and
                                         len(staff[j]) >= break_minimum_hours} - been_on_break

                if potential_break_staff:
                    break_staff = max(potential_break_staff, key=lambda x: staff[x])
                else:
                    break_staff = 0

            available_staff = {j for j in staff if is_within(time, staff_hours[j]) and j != break_staff and
                               j not in shift_finished and j not in tired_staff}
            n_d_staff = ceil(n_staff / 2)
            n_regular_staff = n_staff - n_d_staff

            """
            print("\n----> Iteration", i + 1, "\nNumber of D Staff required:", n_d_staff, "\nTired Staff:", tired_staff,
                  "\nAvailable Staff:", available_staff, "\nStaff on Break:", break_staff if break_staff else "None")
            """

            #   ------> IF FIRST ITERATION, CHOOSE ALL STAFF RANDOMLY
            if i == 0:
                try:
                    chosen_d_staff = set(sample(list(d_staff.intersection(available_staff).intersection(senior_staff)),
                                                k=min(n_d_staff, len(d_staff.intersection(available_staff)
                                                                     .intersection(senior_staff)))))
                    chosen_d_staff = chosen_d_staff.union(
                        set(sample(list(d_staff.intersection(available_staff)),
                                   k=min(0, n_d_staff - len(chosen_d_staff)))))
                except IndexError:
                    print("----> Iteration", k + 1, "D-Staff shortage.")
                    error = True
                    break

                # Try to choose the rest of the required staff from regular staff only if possible
                if len(available_staff - d_staff) >= n_regular_staff:
                    chosen_staff = set(sample(list(available_staff.intersection(senior_staff) - d_staff),
                                              k=min(n_regular_staff, len(available_staff
                                                                         .intersection(senior_staff) - d_staff))))

                    chosen_staff = chosen_staff.union(set(sample(list(available_staff - d_staff),
                                                                 k=min(0, n_regular_staff - len(chosen_staff)))))
                else:
                    try:
                        chosen_staff = set(sample(list(available_staff.intersection(senior_staff) - chosen_d_staff),
                                                  k=min(n_regular_staff, len(available_staff.intersection(senior_staff)
                                                                             - chosen_d_staff))))

                        chosen_staff = chosen_staff.union(set(sample(list(available_staff - chosen_d_staff),
                                                                     k=min(0, n_regular_staff - len(chosen_staff)))))
                    except IndexError:
                        print("----> Iteration", k + 1, "Regular Staff shortage.")
                        error = True
                        break

            else:
                #   ------> CHOSING D STAFF

                # Remove Tired Staff
                chosen_d_staff = chosen_d_staff - tired_staff

                # Remove Staff on Break
                chosen_d_staff -= {break_staff}

                # Add D Staff that just got out of break
                if out_of_break and out_of_break in d_staff:
                    chosen_d_staff.add(out_of_break)

                # If more D Staff is required, add more.
                if n_d_staff > len(chosen_d_staff):
                    try:
                        chosen = set(sample(list(d_staff.intersection(available_staff) - chosen_d_staff),
                                             k=n_d_staff - len(chosen_d_staff)))
                    except IndexError:
                        print("----> Iteration", k + 1, "D-Staff shortage.")
                        error = True
                        break

                    chosen_d_staff = chosen_d_staff.union(chosen)

                # If less D Staff is required, finish shifts of the most tired ones.
                elif n_d_staff < len(chosen_d_staff):
                    # If it's just 1 over the cap with the staff that just came from break, leave him.
                    if list(required_staff.items())[i - 1][1] != n_staff:
                        for _ in range(len(chosen_d_staff) - n_d_staff):
                            chosen = max(chosen_d_staff, key=lambda x: len(staff[x]))
                            chosen_d_staff.remove(chosen)
                            shift_finished.add(chosen)

                #   ------> CHOSING REGULAR STAFF

                # Remove Tired Staff
                chosen_staff = chosen_staff - tired_staff

                # Remove Staff on Break
                chosen_staff -= {break_staff}

                # Add Staff that just got out of break
                if out_of_break and out_of_break not in d_staff:
                    chosen_staff.add(out_of_break)

                # Decide the next person going on break
                if out_of_break:
                    break_next = max(chosen_staff.union(chosen_d_staff) - been_on_break, key=lambda x: len(staff[x])) \
                        if chosen_staff.union(chosen_d_staff) - been_on_break else 0

                # If more Staff is required, add more.
                if n_staff > len(chosen_staff) + len(chosen_d_staff):
                    # Try to choose the rest of the required staff from regular staff only if possible
                    if len(available_staff - d_staff - chosen_staff) >= n_regular_staff - len(chosen_staff):
                        chosen = set(sample(list(available_staff - d_staff - chosen_staff),
                                             k=n_regular_staff - len(chosen_staff)))
                    else:
                        try:
                            chosen = set(sample(list(available_staff - chosen_d_staff - chosen_staff),
                                                 k=n_regular_staff - len(chosen_staff)))
                        except IndexError:
                            print("----> Iteration", k + 1, "Regular Staff shortage.")
                            error = True
                            break

                    chosen_staff = chosen_staff.union(chosen)

                # If less Staff is required, finish shifts of the most tired ones.
                elif n_staff < len(chosen_staff) + len(chosen_d_staff):
                    for _ in range(len(chosen_staff) + len(chosen_d_staff) - n_staff):
                        chosen = max(chosen_staff, key=lambda x: len(staff[x]))
                        chosen_staff.remove(chosen)
                        shift_finished.add(chosen)

            #   ------> FILLING THE STAFF DICT
            for j in chosen_staff.union(chosen_d_staff):
                staff[j].add(time)

            """
            print("Chosen D Staff:", chosen_d_staff, "\nChosen Regular Staff:", chosen_staff, end="\n\n")

            """
            #   ------> FILLING THE SHIFTS DICT
            shifts[time] = chosen_d_staff.union(chosen_staff)

            if break_staff:
                been_on_break.add(break_staff)
            out_of_break = break_staff

        if not error:
            # If one of the shifts is less than 4 hours, redo the schedule
            for shift in shifts:
                for i in shifts[shift]:
                    staff_assignments[i].append(shift)
            staff_assignments = {i: staff_assignments[i] for i in staff_assignments if staff_assignments[i]}
            staff_pay = {i: len(staff_assignments[i]) * staff_rates[i] for i in staff_assignments}

            if len(min(staff_assignments.values(), key=lambda x: len(x))) < 8:
                continue

            # Successful
            print("----> Iteration", k + 1, "successful.")
            print("\nShifts:", shifts)

            fig, gnt = plt.subplots(figsize=(12, 8))

            gnt.set_title('Day wages $' + str(sum(staff_pay.values()) / 2))

            gnt.set_ylim(0, 210)
            gnt.set_xlim(6, 19.5)

            gnt.set_xlabel('Time in Hours')
            gnt.set_ylabel('Staff')

            gnt.set_yticks([15 + 10 * i for i in range(len(staff_hours))])
            gnt.set_yticklabels(["STAFF " + str(i) + ": " + staff_names[i] for i in staff_hours])

            gnt.set_xticks([int(shift.split(":")[0]) + (0.5 if shift.split(":")[1] == "30" else 0)
                            for shift in times + ["19:00"]])
            gnt.set_xticklabels(times + ["19:00"], rotation=60)

            gnt.grid(True)

            for shift in shifts:
                for i in shifts[shift]:
                    height = 0
                    for j, item in enumerate(staff_hours.items()):
                        if item[0] == i:
                            height = 10 * (j + 1)
                            break

                    gnt.broken_barh([(int(shift.split(":")[0]) + (0.5 if shift.split(":")[1] == "30" else 0), 0.5)],
                                    (height, 9), facecolors=("tab:orange" if i in d_staff else "tab:red"))

            plt.show()

            return staff_assignments


create_schedule(1, 2)
"""
schedule(1)
schedule(2)
schedule(3)
schedule(4)
"""
