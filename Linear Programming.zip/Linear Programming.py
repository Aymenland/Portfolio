from scipy.optimize import linprog
from numpy import array


def solve(input_matrix):
    n = len(input_matrix)
    matrix = array([input_matrix[i] + [0 for _ in range(i)] for i in range(n)]) # Filling out the zeros

    solution = array([[0 for __ in range(n)] for _ in range(n)])

    solution[:, 0] = matrix[:, 0]   # The first column is trivial
    solution[:, -1] = matrix[:, -1] # The last column is trivial

    for i in range(1, n - 1):
        obj = [-1 for _ in range(n)]

        lhs_eq = [[0 for _ in range(j)] + [1 for _ in range(i + 1)] + [0 for _ in range(n - j - i - 1)]
                  for j in range(n - i)]    # equality constraint left side

        rhs_eq = matrix[:n - i, i]  # equality constraint right side

        bnd = [(0, float("inf")) for _ in range(n)]  # Bounds of x_i's

        opt = linprog(c=obj, A_ub=None, b_ub=None, A_eq=lhs_eq, b_eq=rhs_eq, bounds=bnd, method="revised simplex")

        solution[:, i] = opt.x

    return solution


if __name__ == "__main__":

    import json
    from time import time

    with open('example.json') as jsonFile:
        A = json.load(jsonFile)

    """A = array([[10, 15, 18, 21, 27],
               [12, 13, 20, 25, 0],
               [14, 17, 21, 0, 0],
               [16, 18, 0, 0, 0],
               [15, 0, 0, 0, 0]])"""

    t = time()
    print(solve(A))
    print(time() - t)
