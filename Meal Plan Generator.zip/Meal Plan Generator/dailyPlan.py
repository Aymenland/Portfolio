import GA


def generate_day_plan(data, objective, dailyCalories, dailyProtein, dailyCarbs, dailyFat, unitType, mealNames,
                      dailyCaloriesDistribution, dietType, p, micros):
    if objective != "Become healthier":
        margin = 2

        max_calories = max(data, key=lambda x: x["calories_kcal"])["calories_kcal"]
        min_calories = min(data, key=lambda x: x["calories_kcal"])["calories_kcal"]

        if objective == "Gain muscle":
            for i in range(len(data)):
                p[i] *= (data[i]["calories_kcal"] - min_calories) / (max_calories - min_calories) * margin + 0.1

        elif objective == "Lose fat":
            for i in range(len(data)):
                p[i] /= (data[i]["calories_kcal"] - min_calories) / (max_calories - min_calories) * margin + 0.1

    p = [per / sum(p) for per in p]
    p = [0.0] + [p[i] + sum(p[:i]) for i in range(len(p))]

    return [GA.generate_meal(data, dailyCalories, dailyProtein, dailyCarbs, dailyFat, unitType, meal,
                             dailyCaloriesDistribution[i], dietType, p, micros)
            for i, meal in enumerate(mealNames)]
