from random import random


def p_choice(data, p):
    chosen = random()
    return data[find(p, chosen, len(p), 0)]


def find(p, chosen, upper_limit, lower_limit):
    if upper_limit - lower_limit <= 1:
        return lower_limit

    middle = int((upper_limit + lower_limit) / 2)

    if p[middle] < chosen:
        return find(p, chosen, upper_limit, middle)

    elif p[middle] > chosen:
        return find(p, chosen, middle, lower_limit)

    else:
        return middle


if __name__ == "__main__":
    n = 10000
    k = 0
    for _ in range(n):
        if p_choice([1, 2, 3, 4, 5, 6], [0, 0.2, 0.55, 0.65, 0.8, 0.9, 1]) == 4:
            k += 1

    print(k / n)

