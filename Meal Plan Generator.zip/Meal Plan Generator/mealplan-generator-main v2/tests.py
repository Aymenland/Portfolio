import main


def tests():
    for recipesScale in range(1, 5):
        for variabilityScale in range(1, 5):
            print('\n\nrecipesScale', recipesScale, ', variabilityScale', variabilityScale)
            main.generateMealPlan(objective="Become healthier", dailyCalories=1500, dailyProtein=72, dailyCarbs=210,
                                  dailyFat=41.4, unitType="", mealNames=["Desayuno", "Almuerzo", "Cena"], allergies=[],
                                  dislikes=[], dailyCaloriesDistribution=[20, 40, 40], gender="M", age=22,
                                  numMealsPerDay=3, mealPlanId=1, source="SF", specialConditions=[],
                                  recipesScale=recipesScale, variabilityScale=variabilityScale,
                                  filename='recipesScale variabilityScale mealplans/recipesScale' +
                                           str(recipesScale) + ' variabilityScale' + str(variabilityScale))


if __name__ == "__main__":
    tests()
