import json
import main
import post


def run(event, context):
    # 1. Set the event data
    data = json.loads(event['body'])

    # 2. Generate meal plan
    mealPlan = main.generateMealPlan(
        objective=data['objective'],
        dailyCalories=data['dailyCalories'],
        dailyProtein=data['dailyProtein'],
        dailyCarbs=data['dailyCarbs'],
        dailyFat=data['dailyFat'],
        unitType=data['unitType'],
        mealNames=data['mealNames'],
        allergies=data['allergies'],
        dislikes=data['dislikes'],
        dailyCaloriesDistribution=data['dailyCaloriesDistribution'],
        gender=data['gender'],
        age=data['age'],
        numMealsPerDay=data['numMealsPerDay'],
        mealPlanId=data['mealPlanId'],
        patientId=data['patientId'],
        source=data['source']
    )

    # 3. Set meal plan job
    if mealPlan is not None:
        post.postMealPlan(data['mealPlanId'], data['source'], mealPlan)

    # 4. Return response
    body = {
        "message": "Done",
        "input": data
    }
    response = {"statusCode": 200, "body": json.dumps(body)}
    return response


if __name__ == "__main__":
    run()
