import json
import re
import weeklyPlan
from matplotlib import pyplot as plt
from numpy import mean, std


def generateMealPlan(objective, dailyCalories, dailyProtein, dailyCarbs, dailyFat, unitType, mealNames, allergies,
                     dislikes, dailyCaloriesDistribution, gender, dietType="no restrictions",
                     age=None, weight=None, height=None, physicalActivityLevel=None, numMealsPerDay=3,
                     specialConditions=None, recipesScale=2, variabilityScale=3, patientId=None, mealPlanId=None,
                     source=None, filename=None):
    # ---- Printing arguments
    '''print("mealPlanId: ", mealPlanId)
    print("patientId: ", patientId)
    print("source: ", source)
    print("objective: ", objective)
    print("dailyCalories: ", dailyCalories)
    print("dailyProtein: ", dailyProtein)
    print("dailyCarbs: ", dailyCarbs)
    print("dailyFat: ", dailyFat)
    print("unitType: ", unitType)
    print("mealNames: ", mealNames)
    print("allergies: ", allergies)
    print("dislikes: ", dislikes)
    print("dailyCaloriesDistribution: ", dailyCaloriesDistribution)
    print("gender: ", gender)
    print("dietType: ", dietType)
    print("age: ", age)
    print("weight: ", weight)
    print("height: ", height)
    print("physicalActivityLevel: ", physicalActivityLevel)
    print("numMealsPerDay: ", numMealsPerDay)'''

    # ---- Checking for errors in arguments
    if mealPlanId is None:
        print("Error: mealPlanId is not defined.")
        return

    if source not in ["SF", "AL_dev", "AL_prod"]:
        print("Error: source is either 'SF' or 'AL_dev' or 'AL_prod.")
        return

    if numMealsPerDay != len(mealNames):
        print("Error: numMealsPerDay not equal to the number of meals in mealNames.")
        return

    if objective not in ["Lose fat", "Gain muscle", "Become healthier"]:
        print("Error: invalid objective parameter. Valid values are: Lose fat, Gain muscle, Become healthier.")
        return

    if height is not None and (height < 140 or height > 210):
        print(
            "Error: invalid height parameter. Valid values range between 140cms and 210cms.")
        return

    if len(dailyCaloriesDistribution) != numMealsPerDay or sum(dailyCaloriesDistribution) != 100:
        print("Error: invalid dailyCaloriesDistribution parameter. Valid values consist of a list with length"
              "numMealsPerDay and values adding up to 100.")
        return

    # ---- Reading in the dataset

    f = open('foodSet.json', encoding="utf-8")
    data = json.load(f)

    # ---- Filtering the dataset from allergies and dislikes

    for i in range(max(len(allergies), len(dislikes))):
        for food in list(data):
            # is the allergie / disliked food in the actual food name?

            food_name = re.sub('[^A-Za-z0-9 ]+', '',
                               food["foodName"].lower()).split()
            if (i < len(allergies) and allergies[i].lower().strip() in food_name) or \
                    (i < len(dislikes) and dislikes[i].lower().strip() in food_name):
                data.remove(food)
                continue

            # is the allergie / disliked food in the ingredients of the food?

            for ingredient in food["ingredients"]:
                food_name = re.sub('[^A-Za-z0-9 ]+', '',
                                   ingredient["foodName"].lower()).split()
                if (i < len(allergies) and allergies[i].lower().strip() in food_name) or \
                        (i < len(dislikes) and dislikes[i].lower().strip() in food_name):
                    data.remove(food)
                    break

    # ---- Lactose / Gluten Intolerance

    if specialConditions:
        lactose = "lactose intolerant" in specialConditions
        gluten = "gluten-free" in specialConditions

        for food in list(data):
            if lactose and "contains_lactose" in food["tags"]:
                data.remove(food)
                continue

            if gluten and "contains_gluten" in food["tags"]:
                data.remove(food)
                continue

    # ---- Filtering the diet types

    if dietType != "no restrictions":
        for food in list(data):
            if dietType + "_dishes" not in food["tags"]:
                data.remove(food)

    # ---- Fixing micronutrients missing in the data

    with open("maleMicro.json", encoding="utf-8") as file:
        male_micro = json.load(file)

    for food in data:
        for micro in male_micro[0][1:]:
            if micro not in food:
                food[micro] = 0

    # ---- Reading in micronutrients

    if gender == "M":
        with open("maleMicro.json", encoding="utf-8") as file:
            micros = json.load(file)
    else:
        with open("femaleMicro.json", encoding="utf-8") as file:
            micros = json.load(file)

    ages = [elem[0] for elem in micros[1:]]
    if age >= ages[-1]:
        micros = (micros[0][1:], micros[-1][1:])
    else:
        for i in range(1, len(ages)):
            if ages[i - 1] <= age < ages[i]:
                micros = (micros[0][1:], micros[i][1:])
                micros = dict(zip(micros[0], micros[1]))
                break

    return weeklyPlan.generate_week_plan(data, objective, dailyCalories, dailyProtein, dailyCarbs, dailyFat, unitType,
                                         mealNames, dailyCaloriesDistribution, micros, recipesScale, variabilityScale,
                                         filename)


if __name__ == "__main__":
    generateMealPlan(objective="Become healthier", dailyCalories=1500, dailyProtein=72, dailyCarbs=210,
                     dailyFat=41.4,
                     unitType="", mealNames=["Desayuno", "Almuerzo", "Cena"], allergies=[], dislikes=[],
                     dailyCaloriesDistribution=[20, 40, 40], gender="M", age=22, numMealsPerDay=3, mealPlanId=1,
                     source="SF", specialConditions=[], recipesScale=2, variabilityScale=1)
    # , dietType="vegan_dishes"
# 10 10 10 8 2 8 6 7 7 11 5 10 4 7 