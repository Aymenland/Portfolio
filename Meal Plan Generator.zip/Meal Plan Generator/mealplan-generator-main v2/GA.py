from random import random, randint, sample, choices, choice
from helper_functions import p_choice
from time import time

IMPORTANT_MICROS = ["vitaminA_mcg", "vitaminD_mcg",
                    "vitaminC_mg", "iron_mg", "magnesium_mg", "calcium_mg"]


def generate_meal(data, dailyCalories, dailyProtein, dailyCarbs, dailyFat, unitType, meal,
                  distribution, p, micros, recipesScale):
    def generate_chromosome():
        genes = []

        main_course = False
        salad = False
        desert = False
        recipe = False
        two_recipes = False

        for _ in range(randint(1, 5)):
            while True:
                chosen = p_choice(data, p=p)

                if meal not in chosen["tags"] or \
                        chosen in genes or \
                        (main_course and "main_course" in chosen["tags"]) or \
                        (salad and "salad" in chosen["tags"]) or \
                        (desert and "desert" in chosen["tags"]) or \
                        (recipesScale >= 3 and recipe and chosen["foodType"] == 4) or \
                        (recipesScale <= 2 and two_recipes and chosen["foodType"] == 4):
                    continue

                chosen["number"] = randint(1, chosen["maxServingsPerMeal"])
                genes.append(chosen)

                main_course = main_course or "main_course" in chosen["tags"]
                salad = salad or "salad" in chosen["tags"]
                desert = desert or "desert" in chosen["tags"]
                two_recipes = two_recipes or (recipe and chosen["foodType"] == 4)
                recipe = recipe or chosen["foodType"] == 4

                break

        if len(genes) == 1 and genes[0]["foodType"] != 4:
            while True:
                chosen = p_choice(data, p=p)

                if meal not in chosen["tags"] or \
                        chosen in genes or \
                        (main_course and "main_course" in chosen["tags"]) or \
                        (salad and "salad" in chosen["tags"]) or \
                        (desert and "desert" in chosen["tags"]) or \
                        (recipesScale >= 3 and recipe and chosen["foodType"] == 4) or \
                        (recipesScale <= 2 and two_recipes and chosen["foodType"] == 4):
                    continue

                chosen["number"] = randint(1, chosen["maxServingsPerMeal"])
                genes.append(chosen)

                break

        return genes

    population_size = 16
    num_of_elite_chrom = 2
    tournament_selection_size = 6
    mutation_rate = 0.4
    max_gen = 1200

    class Chromosome:
        def __init__(self, meal0, distribution0, empty=False):
            self.genes = generate_chromosome() if not empty else []
            self.meal = meal0
            self.distribution = distribution0
            self.fitness = self.get_fitness()
            self.mealplan_proteins = 0
            self.mealplan_carbs = 0
            self.mealplan_fat = 0
            self.mealplan_calories = 0

        def get_genes(self):
            return self.genes

        def get_fitness(self):
            # How well does this chromosome fit the calories and macros

            objective_proteins = dailyProtein * self.distribution / 100
            objective_carbs = dailyCarbs * self.distribution / 100
            objective_fat = dailyFat * self.distribution / 100
            objective_calories = dailyCalories * self.distribution / 100

            self.mealplan_proteins = sum(food["number"] * food["protein_g"] * (food["weights"]["Gm_Wgt0"] / 100)
                                         for food in self.genes)
            self.mealplan_carbs = sum(food["number"] * food["carbs_g"] * (food["weights"]["Gm_Wgt0"] / 100)
                                      for food in self.genes)
            self.mealplan_fat = sum(food["number"] * food["fat_g"] * (food["weights"]["Gm_Wgt0"] / 100)
                                    for food in self.genes)
            self.mealplan_calories = self.mealplan_proteins * 4 + self.mealplan_carbs * 4 + self.mealplan_fat * 9

            self.fitness = abs((objective_calories - self.mealplan_calories) / objective_calories) + \
                           abs((objective_proteins - self.mealplan_proteins) / objective_proteins) * 0.2 + \
                           abs((objective_carbs - self.mealplan_carbs) / objective_carbs) * 0.2 + \
                           abs((objective_fat - self.mealplan_fat) / objective_fat) * 0.2

            # How well does this chromosome fit the micros

            for micro in IMPORTANT_MICROS:
                objective_micro = micros[micro] * self.distribution / 100
                mealplan_micro = sum(food["number"] * food[micro] * (food["weights"]["Gm_Wgt0"] / 100)
                                     for food in self.genes)

                if mealplan_micro > 2 * objective_micro:
                    self.fitness += 50
                else:
                    self.fitness += abs((objective_micro -
                                         mealplan_micro) / objective_micro) * 0.05

            # How well does this chromosome fit the recipesScale

            if recipesScale == 1:
                for food in self.genes:
                    if food['foodType'] != 4:
                        self.fitness += 1 / len(self.genes)

            elif recipesScale == 2:
                for food in self.genes:
                    if food['foodType'] != 4:
                        self.fitness += 0.5 / len(self.genes)

            elif recipesScale == 3:
                for food in self.genes:
                    if food['foodType'] != 0:
                        self.fitness += 0.5 / len(self.genes)

            elif recipesScale == 4:
                for food in self.genes:
                    if food['foodType'] != 0:
                        self.fitness += 1 / len(self.genes)

            return self.fitness

        def satisfactory(self):
            # For recipesScale = 1 (all recipes), check if all foods are recipes
            # For recipesScale = 2 (mostly recipes), check if most foods (66%) are recipes
            # For recipesScale = 3 (mostly basic foods), check if no more than 33% of foods are recipes
            # For recipesScale = 4 (all basic foods), check if all foods are basic foods
            return ((recipesScale == 1 and all(food["foodType"] == 4 for food in self.genes)) or
                    (recipesScale == 2 and count_recipes(self.genes) / len(self.genes) >= 0.5) or
                    (recipesScale == 3 and count_recipes(self.genes) / len(self.genes) <= 0.5) or
                    (recipesScale == 4 and all(food["foodType"] == 0 for food in self.genes))) and \
                abs(self.mealplan_calories - dailyCalories * self.distribution / 100) / \
                (dailyCalories * self.distribution / 100) <= 0.15 and \
                abs(self.mealplan_proteins - dailyProtein * self.distribution / 100) / \
                (dailyProtein * self.distribution / 100) <= 0.2 and \
                abs(self.mealplan_carbs - dailyCarbs * self.distribution / 100) / \
                (dailyCarbs * self.distribution / 100) <= 0.2 and \
                abs(self.mealplan_fat - dailyFat * self.distribution / 100) / \
                (dailyFat * self.distribution / 100) <= 0.2

        def __str__(self):
            return self.genes.__str__()

    class Population:
        def __init__(self, size, meal0, distribution0):
            self.meal = meal0
            self.distribution = distribution0
            self._chromosomes = []
            i = 0
            while i < size:
                self._chromosomes.append(Chromosome(meal, distribution0))
                i += 1

        def get_chromosomes(self): return self._chromosomes

    class GeneticAlgorithm:
        @staticmethod
        def evolve(pop, gen_number):
            return GeneticAlgorithm._mutate_population(GeneticAlgorithm._crossover_population(pop), gen_number)

        @staticmethod
        def _crossover_population(pop):
            crossover_pop = Population(0, pop.meal, pop.distribution)
            for i in range(num_of_elite_chrom):
                crossover_pop.get_chromosomes().append(
                    pop.get_chromosomes()[i])
            i = num_of_elite_chrom
            while i < population_size:
                chromosome1 = GeneticAlgorithm._select_tournament_population(pop)[0]
                chromosome2 = GeneticAlgorithm._select_tournament_population(pop)[0]
                crossover_pop.get_chromosomes().append(
                    GeneticAlgorithm._crossover_chromosomes(chromosome1, chromosome2))
                i += 1
            return crossover_pop

        @staticmethod
        def _mutate_population(pop, gen_number):
            for i in range(num_of_elite_chrom, population_size):
                GeneticAlgorithm._mutate_chromosome(
                    pop.get_chromosomes()[i], gen_number)
            return pop

        @staticmethod
        def _crossover_chromosomes(chromosome1, chromosome2):
            crossover_chrom = Chromosome(chromosome1.meal, chromosome1.distribution, empty=True)

            gene_pool = chromosome1.genes + chromosome2.genes

            # Decide what and how many foods to add (all while following the restrictions)

            main_course = False
            salad = False
            desert = False
            recipe = False
            two_recipes = False

            for _ in range(randint(1, max(len(chromosome1.genes), len(chromosome2.genes)))):
                i = 0
                while True:
                    chosen = choice(gene_pool)

                    if crossover_chrom.meal not in chosen["tags"] or \
                            chosen in crossover_chrom.genes or \
                            (main_course and "main_course" in chosen["tags"]) or \
                            (salad and "salad" in chosen["tags"]) or \
                            (desert and "desert" in chosen["tags"]) or \
                            (recipesScale >= 3 and recipe and chosen["foodType"] == 4) or \
                            (recipesScale <= 2 and two_recipes and chosen["foodType"] == 4):

                        # Failsafe
                        i += 1
                        if i > 20:
                            break

                        continue

                    chosen["number"] = randint(1, chosen["maxServingsPerMeal"])
                    crossover_chrom.genes.append(chosen)

                    main_course = main_course or "main_course" in chosen["tags"]
                    salad = salad or "salad" in chosen["tags"]
                    desert = desert or "desert" in chosen["tags"]
                    two_recipes = two_recipes or (recipe and chosen["foodType"] == 4)
                    recipe = recipe or chosen["foodType"] == 4
                    break

            if len(crossover_chrom.genes) == 1 and crossover_chrom.genes[0]["foodType"] != 4:
                while True:
                    chosen = choice(gene_pool)

                    if crossover_chrom.meal not in chosen["tags"] or \
                            chosen in crossover_chrom.genes or \
                            (main_course and "main_course" in chosen["tags"]) or \
                            (salad and "salad" in chosen["tags"]) or \
                            (desert and "desert" in chosen["tags"]) or \
                            (recipesScale >= 3 and recipe and chosen["foodType"] == 4) or \
                            (recipesScale <= 2 and two_recipes and chosen["foodType"] == 4):
                        continue

                    chosen["number"] = randint(1, chosen["maxServingsPerMeal"])
                    crossover_chrom.genes.append(chosen)

                    break

            crossover_chrom.get_fitness()
            return crossover_chrom

        @staticmethod
        def _mutate_chromosome(chromosome, gen_number):
            # mutation_rate chance to mutate the chromosome
            if random() < mutation_rate:

                # 0.2 chance that the mutation will generate a whole new chromosome. This will occur more often the
                # longuer the algorithm runs.
                if random() < 0.2 + gen_number / (2.5 * max_gen):
                    chromosome.genes = generate_chromosome()

                # 0.7 chance that the mutation will change a random number of foods (at least one) by any number of
                # random foods. This will occur less often the longuer the algorithm runs.
                else:
                    foods_to_change = sample(
                        chromosome.genes, k=randint(1, len(chromosome.genes)))

                    # Remove the foods that will change

                    for food in foods_to_change:
                        chromosome.genes.remove(food)

                    # Decide what and how many foods to add (all while following the restrictions)

                    main_course = False
                    salad = False
                    desert = False
                    recipe = False
                    two_recipes = False

                    for food in chromosome.genes:
                        if "main_course" in food["tags"]:
                            main_course = True
                        if "salad" in food["tags"]:
                            salad = True
                        if "desert" in food["tags"]:
                            desert = True
                        if food["foodType"] == 4:
                            recipe = True
                        if recipe and food["foodType"] == 4:
                            two_recipes = True

                    for _ in range(randint(1, 5 - len(chromosome.genes))):
                        while True:
                            chosen = p_choice(data, p=p)

                            if chromosome.meal not in chosen["tags"] or \
                                    chosen in chromosome.genes or \
                                    (main_course and "main_course" in chosen["tags"]) or \
                                    (salad and "salad" in chosen["tags"]) or \
                                    (desert and "desert" in chosen["tags"]) or \
                                    (recipesScale >= 3 and recipe and chosen["foodType"] == 4) or \
                                    (recipesScale <= 2 and two_recipes and chosen["foodType"] == 4):
                                continue

                            chosen["number"] = randint(
                                1, chosen["maxServingsPerMeal"])
                            chromosome.genes.append(chosen)

                            main_course = main_course or "main_course" in chosen["tags"]
                            salad = salad or "salad" in chosen["tags"]
                            desert = desert or "desert" in chosen["tags"]
                            two_recipes = two_recipes or (recipe and chosen["foodType"] == 4)
                            recipe = recipe or chosen["foodType"] == 4

                            break

                    if len(chromosome.genes) == 1 and chromosome.genes[0]["foodType"] != 4:
                        while True:
                            chosen = p_choice(data, p=p)

                            if chromosome.meal not in chosen["tags"] or \
                                    chosen in chromosome.genes or \
                                    (main_course and "main_course" in chosen["tags"]) or \
                                    (salad and "salad" in chosen["tags"]) or \
                                    (desert and "desert" in chosen["tags"]) or \
                                    (recipesScale >= 3 and recipe and chosen["foodType"] == 4) or \
                                    (recipesScale <= 2 and two_recipes and chosen["foodType"] == 4):
                                continue

                            chosen["number"] = randint(
                                1, chosen["maxServingsPerMeal"])
                            chromosome.genes.append(chosen)

                            break

                chromosome.fitness = chromosome.get_fitness()

        @staticmethod
        def _select_tournament_population(pop):
            tournament_pop = choices(
                pop.get_chromosomes(), k=tournament_selection_size)
            tournament_pop.sort(key=lambda x: x.fitness, reverse=False)

            return tournament_pop

    def _print_population(pop, gen_number):
        print("\n--------------------------------------------------")
        print("Generation #", gen_number, "| Fittest chromosome fitness:",
              pop.get_chromosomes()[0].fitness)
        print("--------------------------------------------------")
        i = 0
        for x in pop.get_chromosomes():
            print("Chromosome  #", i, " : ", end="")
            for food in x.genes:
                print(food["foodName"], ", Type:", food["foodType"], end=" || ")
            print("| Fitness: ", x.fitness, "| Satisfactory: ", x.satisfactory())
            i += 1

    # 1st try
    print()
    print(meal, " meal generation:")
    t = time()
    generation_number = 1
    population = Population(population_size, meal, distribution)
    population.get_chromosomes().sort(key=lambda x: x.fitness, reverse=False)
    # _print_population(population, 0)
    while not population.get_chromosomes()[0].satisfactory() and generation_number <= max_gen:
        population = GeneticAlgorithm.evolve(population, generation_number)
        population.get_chromosomes().sort(key=lambda x: x.fitness, reverse=False)
        # _print_population(population, generation_number)
        generation_number += 1

    population.get_chromosomes().sort(key=lambda x: x.fitness, reverse=False)
    best_meal = population.get_chromosomes()[0]
    best_meal.get_fitness()

    # 2nd try
    if not best_meal.satisfactory():
        print("\tNot satisfactory, trying again...")
        t = time()
        generation_number = 1
        population = Population(population_size, meal, distribution)
        population.get_chromosomes().sort(key=lambda x: x.fitness, reverse=False)
        # _print_population(population, 0)
        while not population.get_chromosomes()[0].satisfactory() and generation_number <= max_gen:
            population = GeneticAlgorithm.evolve(population, generation_number)
            population.get_chromosomes().sort(key=lambda x: x.fitness, reverse=False)
            # _print_population(population, generation_number)
            generation_number += 1

        population.get_chromosomes().sort(key=lambda x: x.fitness, reverse=False)
        best_meal = best_meal if best_meal.fitness < population.get_chromosomes()[0].fitness \
            else population.get_chromosomes()[0]
    best_meal.get_fitness()

    print("\tSatisfactory" if best_meal.satisfactory() else "\tNot satisfactory")

    '''print("Time: ", time() - t, "seconds")
    print("Calories:", dailyCalories * distribution / 100,
          "Proteins:", dailyProtein * distribution / 100,
          "Carbs:", dailyCarbs * distribution / 100,
          "Fat:", dailyFat * distribution / 100)

    print("Calories:", best_meal.mealplan_calories,
          "Proteins:", best_meal.mealplan_proteins,
          "Carbs:", best_meal.mealplan_carbs,
          "Fat:", best_meal.mealplan_fat)'''

    # @dev ubinatus: forzar no generar el output.txt
    # with open("output.txt", "a") as file:
    #     file.write("\n\n\n\nObjective Calories: " + str(dailyCalories * distribution / 100) +
    #                "\nObjective Proteins: " + str(dailyProtein * distribution / 100) +
    #                "\nObjective Carbs: " + str(dailyCarbs * distribution / 100) +
    #                "\nObjective Fat: " + str(dailyFat * distribution / 100))
    #     file.write("\n\nMealPlan Calories: " + str(best_meal.mealplan_calories) +
    #                "\nMealPlan Proteins: " + str(best_meal.mealplan_proteins) +
    #                "\nMealPlan Carbs: " + str(best_meal.mealplan_carbs) +
    #                "\nMealPlan Fat: " + str(best_meal.mealplan_fat))

    result = {"plan": best_meal.genes, "micros": dict(), "macros":
        {"MealPlan Calories": best_meal.mealplan_calories,
         "MealPlan Proteins": best_meal.mealplan_proteins,
         "MealPlan Carbs": best_meal.mealplan_carbs,
         "MealPlan Fat": best_meal.mealplan_fat}}

    for micro1 in IMPORTANT_MICROS:
        objective_micro1 = micros[micro1] * best_meal.distribution / 100
        mealplan_micro1 = sum(food["number"] * food[micro1] * (food["weights"]["Gm_Wgt0"] / 100)
                              for food in best_meal.genes)
        result["micros"][micro1] = (mealplan_micro1, objective_micro1)

    return result


def count_recipes(genes):
    count = 0
    for food in genes:
        if food['foodType'] == 4:
            count += 1
    return count
