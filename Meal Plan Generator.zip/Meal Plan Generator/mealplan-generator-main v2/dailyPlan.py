import GA


def generate_day_plan(data, dailyCalories, dailyProtein, dailyCarbs, dailyFat, unitType, mealNames,
                      dailyCaloriesDistribution, p, micros, recipesScale):

    return [GA.generate_meal(data, dailyCalories, dailyProtein, dailyCarbs, dailyFat, unitType, meal,
                             dailyCaloriesDistribution[i], p, micros, recipesScale) for i, meal in enumerate(mealNames)]
