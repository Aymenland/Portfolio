import main


def tests():
    for _ in range(2):
        main.generateMealPlan(objective="Become healthier", dailyCalories=1500, dailyProtein=72, dailyCarbs=210,
                              dailyFat=41.4, unitType="", mealNames=["Desayuno", "Almuerzo", "Cena"], allergies=[],
                              dislikes=[], dailyCaloriesDistribution=[20, 40, 40], gender="M", age=22,
                              numMealsPerDay=3, mealPlanId=1, source="SF", specialConditions=['lactose intolerant'],
                              filename='diets special conditions mealplans/lactose intolerant mealplan')

    for _ in range(2):
        main.generateMealPlan(objective="Become healthier", dailyCalories=1500, dailyProtein=72, dailyCarbs=210,
                              dailyFat=41.4, unitType="", mealNames=["Desayuno", "Almuerzo", "Cena"], allergies=[],
                              dislikes=[], dailyCaloriesDistribution=[20, 40, 40], gender="M", age=22,
                              numMealsPerDay=3, mealPlanId=1, source="SF", specialConditions=['gluten-free'],
                              filename='diets special conditions mealplans/gluten-free mealplan')

    for _ in range(2):
        main.generateMealPlan(objective="Become healthier", dailyCalories=1500, dailyProtein=72, dailyCarbs=210,
                              dailyFat=41.4, unitType="", mealNames=["Desayuno", "Almuerzo", "Cena"], allergies=[],
                              dislikes=[], dailyCaloriesDistribution=[20, 40, 40], gender="M", age=22,
                              numMealsPerDay=3, mealPlanId=1, source="SF", specialConditions=[], dietType='keto',
                              filename='diets special conditions mealplans/keto mealplan')

    for _ in range(2):
        main.generateMealPlan(objective="Become healthier", dailyCalories=1500, dailyProtein=72, dailyCarbs=210,
                              dailyFat=41.4, unitType="", mealNames=["Desayuno", "Almuerzo", "Cena"], allergies=[],
                              dislikes=[], dailyCaloriesDistribution=[20, 40, 40], gender="M", age=22,
                              numMealsPerDay=3, mealPlanId=1, source="SF", specialConditions=[], dietType='vegan',
                              filename='diets special conditions mealplans/vegan mealplan')

    for _ in range(2):
        main.generateMealPlan(objective="Become healthier", dailyCalories=1500, dailyProtein=72, dailyCarbs=210,
                              dailyFat=41.4, unitType="", mealNames=["Desayuno", "Almuerzo", "Cena"], allergies=[],
                              dislikes=[], dailyCaloriesDistribution=[20, 40, 40], gender="M", age=22,
                              numMealsPerDay=3, mealPlanId=1, source="SF", specialConditions=[], dietType='vegetarian',
                              filename='diets special conditions mealplans/vegetarian mealplan')

    for _ in range(2):
        main.generateMealPlan(objective="Become healthier", dailyCalories=1500, dailyProtein=72, dailyCarbs=210,
                              dailyFat=41.4, unitType="", mealNames=["Desayuno", "Almuerzo", "Cena"], allergies=[],
                              dislikes=[], dailyCaloriesDistribution=[20, 40, 40], gender="M", age=22,
                              numMealsPerDay=3, mealPlanId=1, source="SF", specialConditions=[], dietType='pescetarian',
                              filename='diets special conditions mealplans/pescetarian mealplan')


if __name__ == "__main__":
    tests()
