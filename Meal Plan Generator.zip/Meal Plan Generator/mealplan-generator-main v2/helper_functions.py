from random import random


def p_choice(data, p):
    chosen = random()
    return data[find(p, chosen, len(p), 0)]


def find(p, chosen, upper_limit, lower_limit):
    if upper_limit - lower_limit <= 1:
        return lower_limit

    middle = int((upper_limit + lower_limit) / 2)

    if p[middle] < chosen:
        return find(p, chosen, upper_limit, middle)

    elif p[middle] > chosen:
        return find(p, chosen, middle, lower_limit)

    else:
        return middle


if __name__ == "__main__":
    p = [1 / 100 for _ in range(100)]
    p[: 15] = [2 * 1.5 * pi for pi in p[: 15]]
    p[15:] = [(1 - sum(p[: 15])) / len(p[15:]) for pi in p[15:]]
    p = [0.0] + [p[i] + sum(p[:i]) for i in range(len(p))]

    from matplotlib import pyplot as plt
    plt.plot(p)
    plt.show()
