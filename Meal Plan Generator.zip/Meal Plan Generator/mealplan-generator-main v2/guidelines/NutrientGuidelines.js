// This file contains the guidelines and indications for nutrient and food related stuff.
// Note: const is the way variables are declared in javascript
// If more variables are needed, feel free to add/edit/remove everything you need. The following is only to provide you with a solid understanding of the problem and its rules.


// --------------4.1 General Restrictions--------------
const nutrientErrorRange = 0.2; // Value that represents the up and down margin a day can have, relative to its target. The lower this parameter, the better (it means the algorithm is more precise). If it's 0.2, this means a valid day will have at most over or under 20% its target calories, as well as its macros. So, if a day has 2000 as its target calories, it can have at least 1600, and at most 2400. 
const mealNutrientErrorRange = 0.4; // Value that represents the up and down margin a meal can have, relative to its target. The lower this parameter, the better. If it's 0.4, this means a valid meal will have at most over or under 40% its target calories. So, if a meal has 500 as its target calories, it can have at least 300, and at most 700. 



// --------------4.5 Micronutrients--------------
// For this initial version of the algorithm, they have the same guidelines for everyone (to remain healthy on general conditions, depending if you're a male or female)
// How to read the following variables (adultMaleMicro, adultFemaleMicro). It's an array of n elements. Element 0 is an array of length m, with strings containing the names of the nutrients.
// From i=1 up until the end, element i is an array of number with m elements. Example:
// The first array of numbers would read: from ages 18 to 30, recommendations are: calcium_mg: 1300, chromium_µg: 35, copper_mg: 0.89,...
// Note that both lengths must be equal (they are, just stating it in case of bug detection).

// Interpretation:
// Those number are the daily Recommended Dietary Allowances (RDAs) and Adequate Intakes (AIs) if followed by "// *". An RDA is the average daily dietary intake level sufficient to meet the nutrient requirements.
// This distinction is only for reference, just treat all the same, as the daily target.

// Note: It's also importante to know that its not mandatory to fit the micronutrient every single day. These work ona weekly basis, so what we should aim for is to have a weekly average that is within a decent range of the value. 
// By decent range we mean +- 40%. Obviously the closer to the value the better.

//Males
export const adultMaleMicro = [
  [
    'age',
    'calcium_mg',
    'chromium_µg', // *
    'copper_mg',
    'fluoride_mcg', // *
    'iodine_mcg',
    'iron_mg',
    'magnesium_mg',
    'manganese_mg', // *
    'molybdenum_µg',
    'phosphorus_mg',
    'selenium_mcg',
    'zinc_mg',
    'potassium_mg', // *
    'sodium_mg', // *
    'chloride_g', // *
    'vitaminA_mcg',
    'vitaminC_mg',
    'vitaminD_mcg',
    'vitaminE_mg',
    'vitaminK_mcg', // *
    'thiamin_mg',
    'riboflavin_mg',
    'niacin_mg',
    'vitaminB6_mg',
    'folate_µg',
    'vitaminB12_ug',
    'vitaminB5_mg', // *
    'biotin_mcg', // *
    'choline_mg', // *
  ],
  [18, 1300, 35, 0.89, 3, 150, 11, 410, 2.2, 43, 1250, 55, 11, 3000, 1500, 2.3, 900, 75, 15, 15, 75, 1.2, 1.3, 16, 1.3, 400, 2.4, 5, 25, 550],
  [30, 1000, 35, 0.9, 4, 150, 8, 400, 2.3, 45, 700, 55, 11, 3400, 1500, 2.3, 900, 90, 15, 15, 120, 1.2, 1.3, 16, 1.3, 400, 2.4, 5, 30, 550],
  [50, 1000, 35, 0.9, 4, 150, 8, 420, 2.3, 45, 700, 55, 11, 3400, 1500, 2.3, 900, 90, 15, 15, 120, 1.2, 1.3, 16, 1.3, 400, 2.4, 5, 30, 550],
  [70, 1000, 30, 0.9, 4, 150, 8, 420, 2.3, 45, 700, 55, 11, 3400, 1500, 2.0, 900, 90, 15, 15, 120, 1.2, 1.3, 16, 1.7, 400, 2.4, 5, 30, 550],
  [120, 1200, 30, 0.9, 4, 150, 8, 420, 2.3, 45, 700, 55, 11, 3400, 1500, 1.8, 900, 90, 20, 15, 120, 1.2, 1.3, 16, 1.7, 400, 2.4, 5, 30, 550],
];

export const adultFemaleMicro = [
  [
    'age',
    'calcium_mg',
    'chromium_µg', // *
    'copper_mg',
    'fluoride_mcg', // *
    'iodine_mcg',
    'iron_mg',
    'magnesium_mg',
    'manganese_mg', // *
    'molybdenum_µg',
    'phosphorus_mg',
    'selenium_mcg',
    'zinc_mg',
    'potassium_mg', // *
    'sodium_mg', // *
    'chloride_g', // *
    'vitaminA_mcg',
    'vitaminC_mg',
    'vitaminD_mcg',
    'vitaminE_mg',
    'vitaminK_mcg', // *
    'thiamin_mg',
    'riboflavin_mg',
    'niacin_mg',
    'vitaminB6_mg',
    'folate_µg',
    'vitaminB12_ug',
    'vitaminB5_mg', // *
    'biotin_mcg', // *
    'choline_mg', // *
  ],
  //Females
  [18, 1300, 24, 0.89, 3, 150, 15, 360, 1.6, 43, 1250, 55, 9, 2300, 1500, 2.3, 700, 65, 15, 15, 75, 1.0, 1.0, 14, 1.2, 400, 2.4, 5, 25, 400],
  [30, 1000, 25, 0.9, 3, 150, 18, 310, 1.8, 45, 700, 55, 8, 2600, 1500, 2.3, 700, 75, 15, 15, 90, 1.1, 1.1, 14, 1.3, 400, 2.4, 5, 30, 425],
  [50, 1000, 25, 0.9, 3, 150, 18, 320, 1.8, 45, 700, 55, 8, 2600, 1500, 2.3, 700, 75, 15, 15, 90, 1.1, 1.1, 14, 1.3, 400, 2.4, 5, 30, 425],
  [70, 1200, 20, 0.9, 3, 150, 8, 320, 1.8, 45, 700, 55, 8, 2600, 1500, 2.0, 700, 75, 15, 15, 90, 1.1, 1.1, 14, 1.5, 400, 2.4, 5, 30, 425],
  [120, 1200, 20, 0.9, 3, 150, 8, 320, 1.8, 45, 700, 55, 8, 2600, 1500, 1.8, 700, 75, 20, 15, 90, 1.1, 1.1, 14, 1.5, 400, 2.4, 5, 30, 425],
];



// --------------4.5 Caloric density--------------
  // Caloric density is defined as the amount of calories per 100 grams of food. 
  // For example: 100gr of peanut butter has 588kcal. 100gr of apple has 52kcal. So peanut butter has a higher caloric density than apples.
  // For every objective there are different rules: 
    // Lose fat: prioritize low caloric density foods
    // Gain muscle: prioritize high caloric density foods
    // Become healthier: indifferent about caloric density
    // Note: "prioritize" is a broad term and can be interpreted in different ways. For example, to prioritize how much? This part is open for you to be creative. A good prioritization would be visualized the following way:
      // For a meal plan with 2000kcal and objective Lose fat, we could see more fruits, vegetables (generally foods that have more water, so its weight comes from water and not from protein, carbs or fat)
      // For a meal plan with 2000kcal (same as the above) and objective Gain muslce, we could see more beans, peanut butter, etc. (denser foods)



// --------------4.6 Daily group recommendations, see mealPlanGeneratorRules.js (ctrl + F "4.5")--------------
const dailyFoodGroupRecommendations = [
  {
    name: 'vegetables',
    quantity: 2.5,
    unit: 'cup',
  },
  {
    name: 'fruits',
    quantity: 1.75,
    unit: 'cup',
  },
  {
    name: 'grains',
    quantity: 6.5,
    unit: 'ounce',
  },
  {
    name: 'dairy',
    quantity: 3,
    unit: 'cup',
  },
  {
    name: 'protein_foods',
    quantity: 5.75,
    unit: 'ounce',
  },
  {
    name: 'oils',
    quantity: 6,
    unit: 'teaspoon',
  },

];




// --------------5. Qualitative restrictions - Meal and Food specifics:--------------
  // 1. There will be between 3 and 5 meals per day

  // 2. Meals can have the following names, and must always be in this order (these are the 5 meal names, there might not be every single one of them in a day):
    const MEAL_NAMES = ['Desayuno', 'Media mañana', 'Almuerzo', 'Media tarde', 'Cena']; // For your knowledge, these mean: ['Breakfast', 'Mid morning', 'Lunch', 'Mid afternoon', 'Dinner']
    // A day could be comprised of ['Desayuno', 'Almuerzo', 'Cena'], ['Desayuno', 'Almuerzo', 'Media tarde', 'Cena']
    // This is an input provided by the user (parameter called mealNames - see file mealPlanGeneratorRules)
    // This means valid inputs are the following combinations: 
    const dummyMealsArr_5Meals = ['Desayuno', 'Media mañana', 'Almuerzo', 'Media tarde', 'Cena'];
    const dummyMealsArr_4Meals_MediaMañana = ['Desayuno', 'Media mañana', 'Almuerzo', 'Cena'];
    const dummyMealsArr_4Meals_MediaTarde = ['Desayuno', 'Almuerzo', 'Media tarde', 'Cena'];
    const dummyMealsArr_3Meals = ['Desayuno', 'Almuerzo', 'Cena'];

  // ***********3. About the tags property****************
  // Every food has this array, it includes information about the dish type, etc.
  // All the possible tags below. Then you will find the rules for those tags.
    const tagsObj = {
      dishType: [
        "main_course",
        "appetizers",
        "salad",
        "desert",
        "side",
        "beverage",
      ],
      geography: [
        "arab",
        "indian",
        "mexican",
        "chinese",
        "italian",
        "american",
        "japanese",
        "spanish",
        "argentinian",
        "french",
        "peruvian",
        "german",
        "brasilian",
        "cuban",
        "greek",
        "hungarian",
        "english",
        "thai",
        "russian",
      ],
      exclusions: [
        "no_lactose",
        "no_gluten",
        "no_soy",
      ],
      ingredientType: [
        "meat_dishes",
        "pork_dishes",
        "fish_dishes",
        "seafood_dishes",
        "chicken_dishes",
        "vegetarian_dishes",
        "vegan_dishes",
      ],
      cookingType: [
        "pot_presurized",
        "pot_parboiled",
        "microwave",
        "oven",
        "fried",
        "in_pan",
        "charcoaled",
        "grilled",
        "steamed",
        "blended",
      ],
      taste: [
        "sweet",
        "salty",
        "bitter",
        "acid",
      ],
      mealName: [ // for this version we will only use 5 meals (stated above), but this is the whole dictionary.
        "Al despertarse",
        "Desayuno",
        "Media mañana",
        "Almuerzo",
        "Snack",
        "Media tarde",
        "Cena",
        "Antes de dormir",
        "Pre-entreno",
        "Durante el entreno",
        "Post-entreno"
      ]
    };

  // Tags rules
  // I. About dish type (foods can have more that one dish type)
    // 1. There can't be two main_course in the same meal
    // 2. There can be more than one appetizer in the same meal (attention: if a food has appetizer and side tags, there can be more than one in the same meal)
    // 3. There can't be more than one salad in the same meal
    // 4. There can't be more than one desert in the same meal
    // 5. There can be more than one side in the same meal
    // 6. There can be more than one beverage in the same meal
    // 7. There can be more than one foodType = 0 (simple food) in the same meal
    // 8. A food cannot have the tags main_course and side at the same time
    // 9. Any dishType can be alone in a meal

  // II. About mealName:
    // 1. main_course can only be in Almuerzo (Lunch) and Cena (Dinner)
    // 2. appetizers can only be in Almuerzo and Cena
    // 3. salad can't be in Desayuno (Breakfast)
    // 4. desert can only be in Almuerzo y Cena
    // 5. side can be in any mealName
    // 6. beverage can be in any mealName
    // 7. "simple food" (foodType 4) can be in any mealName
    // 8. If food has tags side and any other, side has priority. It can be in any mealName
    // 9. A food can't be added to a meal if that food does not have that mealName in its tags (ex: can't add Fish to Breakfast, would not be yummy)

  // *********End 3.About tags property*********