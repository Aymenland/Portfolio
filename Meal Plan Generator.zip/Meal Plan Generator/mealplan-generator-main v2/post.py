import json
import redis

r = redis.Redis(
    host='us1-great-grackle-39240.upstash.io',
    port='39240',
    password='fb7528578ddb402684b5b79dd8bd7162',
    ssl=True
)


def postMealPlan(mealPlanId, source, mealPlanData):
    mealPlanJson = json.dumps(mealPlanData)

    result = r.set(f"{source}_{mealPlanId}", mealPlanJson, nx=True, ex=15 * 60)

    print(f"Post to redis status: {result}")
