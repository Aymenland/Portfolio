import dailyPlan
from matplotlib import pyplot as plt
from helper_functions import p_choice
from numpy import std
import json
from pathlib import Path


def generate_week_plan(data, objective, dailyCalories, dailyProtein, dailyCarbs, dailyFat, unitType, mealNames,
                       dailyCaloriesDistribution, micros, recipesScale, variabilityScale, filename=None):

    # ---- Meeting the mealplan objective
    # If Gain Muscle, then increase the probability of the higher caloric density foods in the probability distribution
    # If Lose fat, then increase the probability of the lower caloric density foods in the probability distribution

    p = [1] * len(data)

    if objective != "Become healthier":
        margin = 2

        max_calories = max(data, key=lambda x: x["calories_kcal"])["calories_kcal"]
        min_calories = min(data, key=lambda x: x["calories_kcal"])["calories_kcal"]

        if objective == "Gain muscle":
            for i in range(len(data)):
                p[i] *= (data[i]["calories_kcal"] - min_calories) / (max_calories - min_calories) * margin + 0.1

        elif objective == "Lose fat":
            for i in range(len(data)):
                p[i] /= (data[i]["calories_kcal"] - min_calories) / (max_calories - min_calories) * margin + 0.1

    p = [per / sum(p) for per in p]

    # Plot the probability distribution before the recipesScale
    """plt.plot(p, color='blue', label='p')"""

    # ---- Recipes vs Basic foods Scale
    # For each reciples scale, multiply the favored food type's foods' probabilities by a hardcoded constant
    # RecipeScale 1 increases recipes chosen, RecipeScale 4 increases basic foods chosen

    # These values are entirely design decisions that make sense in terms of the objectives of the scale
    recipes_scale_factor = {1: 8, 2: 0.5, 3: 8, 4: 60}
    for i, food in enumerate(data):
        if recipesScale <= 2:
            if food["foodType"] == 4:
                p[i] *= recipes_scale_factor[recipesScale]
        else:
            if food["foodType"] != 4:
                p[i] *= recipes_scale_factor[recipesScale]

    p = [per / sum(p) for per in p]
    p_cum = [sum(p[:i]) for i in range(len(p) + 1)]

    # How often are recipes randomly chosen given the recipesScale
    """recipes_factor = sum(1 if p_choice(data, p_cum)["foodType"] == 4 else 0 for _ in range(2000)) / 2000
    print("recipes: ", recipes_factor)"""

    # Plot the probability distribution after the recipesScale
    """plt.plot(p, color='red', label='ps')
    plt.ylim([0, 0.05])
    plt.show()"""

    # Plot the probability distribution of recipes, then the probability distribution of basic foods
    """plt.plot([food for i, food in enumerate(p) if data[i]['foodType'] == 4], color='red', label='ps')
    plt.ylim([0, 0.05])
    plt.show()

    plt.plot([food for i, food in enumerate(p) if data[i]['foodType'] != 4], color='red', label='ps')
    plt.ylim([0, 0.05])
    plt.show()"""

    # ---> Week generation + Variability Scale applying
    # Generate the first day unrestricted. Then based on the variability scale factor, change the probabilities of the
    # first day's foods accordingly

    # Plot the original probability distribution
    """plt.plot(p, color='red', label='ps')
    plt.ylim([0, 0.2])
    plt.show()"""

    # These values are entirely design decisions that make sense in terms of the objectives of the scale
    variability_scale_factor = {1: 40, 2: 8, 3: 0.8, 4: 0.2}
    p_cum0 = p_cum.copy()

    week_plan = []
    used_foods = []
    days = ["Lunes", "Martes", "Miércoles",
            "Jueves", "Viernes", "Sábado", "Domingo"]
    for _ in range(7):
        meal_plan = dailyPlan.generate_day_plan(data, dailyCalories, dailyProtein, dailyCarbs, dailyFat, unitType,
                                                mealNames, dailyCaloriesDistribution, p_cum0, micros, recipesScale)
        week_plan.append(meal_plan)

        for day_plan in meal_plan:
            for food in day_plan['plan']:
                found = False
                for used_food in used_foods:
                    if food["_id"] == used_food["_id"]:
                        found = True
                        break

                if not found:
                    used_foods.append(food)

        p0 = p.copy()

        for food in used_foods:
            i = data.index(food)
            p0[i] *= variability_scale_factor[variabilityScale]

        p0 = [per / sum(p0) for per in p0]
        # Plot the probability distribution after each day's variabilityScale is applied
        """plt.plot(p0, color='red', label='ps')
        plt.ylim([0, 0.03])
        plt.show()"""

        p_cum0 = [sum(p0[:i]) for i in range(len(p0) + 1)]

    # Check the number of foods used per week, and how often are the same foods used out of 2000 random choices
    print(len(used_foods))
    exit(0)
    variability_factor = sum(1 if p_choice(data, p_cum0) in used_foods else 0 for _ in range(2000)) / 2000
    print("variability: ", variability_factor)

    meal_plan = []
    stats = []

    for k in range(7):

        meal_plan.append({"dayName": days[k], "dailyCalories": dailyCalories, "dailyProtein": dailyProtein,
                          "dailyCarbs": dailyCarbs, "dailyFat": dailyFat, "meals": []})

        stats.append({"dayName": days[k], "Objective Calories": dailyCalories, "Objective Protein": dailyProtein,
                      "Objective Carbs": dailyCarbs, "Objective Fat": dailyFat, })
        day_stats = {"MealPlan Calories": 0,
                     "MealPlan Proteins": 0,
                     "MealPlan Carbs": 0,
                     "MealPlan Fat": 0}

        for i, meal in enumerate(mealNames):
            foods = week_plan[k][i]["plan"]
            recipes = []

            for food in foods:
                option = {"foodOptions": [
                    {"food": food["_id"],
                     "foodName": food["foodName"],
                     "quantity": food["number"],
                     "unit": food["weights"]["Msre_Desc0"]}
                ]}

                recipes.append(option)

            meal_plan[-1]["meals"].append({"mealName": meal,
                                          "recipes": recipes})

            for key in day_stats:
                day_stats[key] += week_plan[k][i]["macros"][key]

        stats[-1].update(day_stats)

    # @dev ubinatus: fuerza el devolver el mealPlan en lugar de guardar el file.
    # return meal_plan

    meal_plan_name = "mealPlan" if not filename else filename
    i = 0
    while True:
        my_file = Path(meal_plan_name + ' ' + str(i) + ".json")
        if my_file.is_file():
            i += 1
        else:
            with open(my_file, encoding="utf-8", mode="w") as outfile:
                """if None in week_plan:
                    json.dump(["not found"], outfile, ensure_ascii=False, indent=4)
                else:"""
                json.dump(meal_plan, outfile, ensure_ascii=False, indent=4)

            with open(meal_plan_name + " Stats " + str(i) + ".json", encoding="utf-8", mode="w") as outfile:
                json.dump(stats, outfile, ensure_ascii=False, indent=4)
            return
