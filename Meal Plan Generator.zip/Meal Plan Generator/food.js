const mongoose = require('mongoose');

// ***READ FIRST***
// If a property has the signs !! next to it, it means to ignore it, as it is not relevant


const FoodSchema = new mongoose.Schema(
  {
    clonedFrom: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Food',
    }, // !!
    hidden: Boolean, // !!
    temporary: Boolean, // !!
    source: String, // !!
    foodType: Number,
    //  0: "simple" food, (egg, milk, chicken, ... Foods that do not need any preparation and can be found at the supermarket)
    //  4: recipe. Difference between foodTypes 0 and foodTypes 4 is that the later have ingredients and instructions
    createdBy: {
      expert: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Expert',
      }, // !!
      // patient: { // para que puedan crear recetas
      //   type: mongoose.Schema.Types.ObjectId,
      //   ref: "Patient"
      // }, // !!
      displayName: String, // !!
    },
    image: String, // !!
    video: String, // !!
    tags: [], // type CTRL+F "tagsObj" in NutrientGuidelines.js. It categorizes the food according to to different properties, such as dish type, geography, etc.
    portions: Number, // for recipes. This number indicates the number of servings one preparation can have. Not so important.
    maxServingsPerMeal: Number, // Maximum number of servings per meal of this specific food
    food_group_mp_generator: String, // related to "dailyFoodGroupRecommendations". This can be "vegetables", "fruits", etc. Only one
    preparationTime: Number, // for recipes only. Minutes to prepare the recipe
    cookingTime: Number, // for recipes only. Minutes to cook the recipe
    publicRecipe: Boolean, // !!
    difficulty: String, // for recipes only. Difficulty of preparing the recipe. Can be Easy (Fácil), Medium (Medio) or Hard (Difícil)
    instructions: Array, // for recipes only. Array of strings that show how to prepare the recipe.
    ingredients: [ // for recipes only. Array of ingredients
      {
        food: {
          type: mongoose.Schema.Types.ObjectId,
          ref: 'Food',
        }, // the id of the ingredient. An ingredient is also a food object.
        foodName: String, // the name of the ingredient. Ex: Fideos a lo alfredo
        quantity: Number, // the quantity of the ingredient that will be added to the meal. Ex: 1
        unit: String, // the unit of the ingredient to be added to the meal. Ex: cup
      },
    ],
    complements: Array, // !!
    exchanges: { // !!
      unit: String,
      quantity: Number,
      vegetable: Number,
      fruit: Number,
      c_nf: Number,
      c_wf: Number,
      legume: Number,
      a_vlf: Number,
      a_lf: Number,
      a_mf: Number,
      m_skim: Number,
      m_semi: Number,
      m_whole: Number,
      m_sugar: Number,
      f_np: Number,
      f_wp: Number,
      s_nf: Number,
      s_wf: Number,
      f_le: Number,
    },
    //
    foodId: String, // !!
    category: String, // !!
    category_en: String, // !!
    foodName: String, // The name of the food, in spanish. Ex: Naranja
    foodName_en: String, // The name of the food, in english. Ex: Orange
    com_name: String, // !!
    manufac_name: String, // !!
    // ---------NUTRITION--------
    // Every value represent the amount of nutrient per 100 grams of weight of the food. Property names are self expalanatory. The format is "[nutrientName]_[unit]"
    // Macros
    calories_kcal: Number,
    carbs_g: Number, // This is the property that refers to carbohydrates. There's a similar property a few lines below called carbs_avl_g. It refers to something else.
    fat_g: Number,
    protein_g: Number,
    //
    // Nutrientes
    alcohol_g: Number,
    alpha_carotene_ug: Number,
    ash_g: Number,
    beta_carotene_mcg: Number,
    beta_cryptoxanthin_mcg: Number,
    caffeine_mg: Number,
    calcium_mg: Number,
    calories_kJ: Number,
    carbs_avl_g: Number, // This property does not refer to carbohydrates. Use the one on line 85.
    cholesterol_mg: Number,
    choline_mg: Number,
    copper_mg: Number,
    fiber_g: Number,
    fluoride_mcg: Number,
    fructose_g: Number,
    galactose_g: Number,
    glucose_g: Number,
    iron_mg: Number,
    lactose_g: Number,
    lutein_zeaxanthin_mcg: Number,
    lycopene_mcg: Number,
    magnesium_mg: Number,
    maltose_g: Number,
    manganese_mg: Number,
    monounsaturated_fat_g: Number,
    niacin_mg: Number, // Vitamina B3
    phosphorus_mg: Number,
    polyunsaturated_fat_g: Number,
    potassium_mg: Number,
    retinol_mcg: Number,
    riboflavin_mg: Number, // Vitamina B2
    saturated_fat_g: Number,
    selenium_mcg: Number,
    sodium_mg: Number,
    starch_g: Number,
    sucrose_g: Number,
    sugar_g: Number,
    theobromine_mg: Number,
    thiamin_mg: Number, // Vitamina B1
    trans_fat_g: Number,
    vitaminA_mcg: Number,
    vitaminB12_ug: Number,
    vitaminB5_mg: Number, // Pantothenic acid
    vitaminB6_mg: Number,
    vitaminB9_ug: Number, // Folate
    vitaminC_mg: Number,
    vitaminD_mcg: Number,
    vitaminD2_mcg: Number,
    vitaminD3_mcg: Number,
    vitaminE_mg: Number,
    water_g: Number,
    zinc_mg: Number,
    //
    // Nuevos nutrientes agregados el 24-05-2020
    alanine_g: Number,
    arginine_g: Number,
    aspartic_acid_g: Number,
    cysteine_g: Number,
    glutamic_acid_g: Number,
    glycemic_index: Number,
    glycemic_load: Number,
    glycine_g: Number,
    histidine_g: Number,
    iodine_mcg: Number,
    iron_non_heme_g: Number,
    isoleucine_g: Number,
    leucine_g: Number,
    lysine_g: Number,
    methionine_g: Number,
    nonreducing_sugar_g: Number,
    phenylalanine_g: Number,
    proline_g: Number,
    reducing_sugar_g: Number,
    serine_g: Number,
    threonine_g: Number,
    tryptophan_g: Number,
    tyrosine_g: Number,
    valine_g: Number,
    //
    // Nuevos nutrinetes agregados el 23-01-2022
    vitaminB7_ug: Number, // Biotin
    lauric_acid_g: Number,
    myristic_acid_g: Number,
    palmitic_acid_g: Number,
    stearic_acid_g: Number,
    oleic_acid_g: Number,
    linolenic_acid_g: Number, // F18:2
    alpha_linolenic_acid_g: Number, // F18:3
    arachidonic_acid_g: Number, // F20:4 n-6
    eicopentaenoic_acid_g: Number, // F20:5
    docosahexaenoic_acid_g: Number, // F22:6
    //
    weights: { // synonym of unit. A food can be added in up to 16 units (we will use 1 at most, but the model enables to use up to 16)
      Amount0: Number, // should always be 1.
      Msre_Desc0: String, // name of the unit. Ex: cup
      Gm_Wgt0: Number, // weight of the unit in grams. Ex: 120. Imagine the foodName is Avena (which means Oatmeal). If we would have these values, this would read as "1 cup of oatmeals weights 120 grams."
      Amount1: Number, // from here and below its the same pattern as the 3 lines above.
      Msre_Desc1: String,
      Gm_Wgt1: Number,
      Amount2: Number,
      Msre_Desc2: String,
      Gm_Wgt2: Number,
      Amount3: Number,
      Msre_Desc3: String,
      Gm_Wgt3: Number,
      Amount4: Number,
      Msre_Desc4: String,
      Gm_Wgt4: Number,
      Amount5: Number,
      Msre_Desc5: String,
      Gm_Wgt5: Number,
      Amount6: Number,
      Msre_Desc6: String,
      Gm_Wgt6: Number,
      Amount7: Number,
      Msre_Desc7: String,
      Gm_Wgt7: Number,
      Amount8: Number,
      Msre_Desc8: String,
      Gm_Wgt8: Number,
      Amount9: Number,
      Msre_Desc9: String,
      Gm_Wgt9: Number,
      Amount10: Number,
      Msre_Desc10: String,
      Gm_Wgt10: Number,
      Amount11: Number,
      Msre_Desc11: String,
      Gm_Wgt11: Number,
      Amount12: Number,
      Msre_Desc12: String,
      Gm_Wgt12: Number,
      Amount13: Number,
      Msre_Desc13: String,
      Gm_Wgt13: Number,
      Amount14: Number,
      Msre_Desc14: String,
      Gm_Wgt14: Number,
      Amount15: Number,
      Msre_Desc15: String,
      Gm_Wgt15: Number,
      Amount16: Number,
      Msre_Desc16: String,
      Gm_Wgt16: Number,
      Amount17: Number,
      Msre_Desc17: String,
      Gm_Wgt17: Number,
      Amount18: Number,
      Msre_Desc18: String,
      Gm_Wgt18: Number,
    },
  },
  { timestamps: true } // !!
);

// ***********NOT RELEVANT*************
// const Food = mongoose.model('Food', FoodSchema);

// module.exports = Food;
// ***********END OF NOT RELEVANT*************
