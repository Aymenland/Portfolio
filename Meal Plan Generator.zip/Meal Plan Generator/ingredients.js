// This file contains a list of foods that are ingredients, presented in JSON format.
// These foods will not (necessarily) be present in a meal plan.
  // For example. Let's say have a recipe called "Spinach omelette" in the foodSet.js file. To prepare this omelette we need eggs, cheese, butter, and spinach.
  // Those 4 ingredients will be present in this list. However, we could also have Egg as an elegible food in foodSet.js, as foodType=0.

// *To view every food than can be added directly, please check foodSet.js