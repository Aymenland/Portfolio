const { wordIsIncluded } = require('./RegExDiacritics');

exports.foodsNotToInclude = (foodName, allergies, dislikedFoods) => {
  if(!allergies || !dislikedFoods) return;
  const _allergies = Array.isArray(allergies) ? [].concat(allergies).map(x => x.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")) : [];
  const _dislikedFoods = Array.isArray(dislikedFoods) ? [].concat(dislikedFoods).map(x => x.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")) : [];
  for(let i = 0; i < _allergies.length; i++){
    if(wordIsIncluded(_allergies[i], foodName)){
      return ' allergicFood';
    }
  }
  for(let i = 0; i < _dislikedFoods.length; i++){
    if(wordIsIncluded(_dislikedFoods[i], foodName)){
      return ' dislikedFood';
    }
  }

  return '';
}