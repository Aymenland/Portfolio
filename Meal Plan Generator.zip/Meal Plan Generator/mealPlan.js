/* eslint-disable global-require */
const mongoose = require('mongoose');


// ***READ FIRST***
// If a property has the signs !! next to it, it means to ignore it, as it is not relevant


// **********NOT RELEVANT*********

  // const exchangeSchema = new mongoose.Schema({
  //   _id: false, // El group es único, no hay necesidad de _id
  //   group: String,
  //   quantity: Number,
  //   excludedFoods: Array,
  // });
  // 

//  **********END OF NOT RELEVANT*********


const mealPlanSchema = new mongoose.Schema(
  {
    mealPlanName: String, // the name of the meal plan. Not so important. Just use anything you want.
    isFlexible: Boolean, // !!
    isBlank: Boolean, // !!
    isExchange: Boolean, // !!
    isAttached: String, // !!
    fromTemplate: { // !!
      type: mongoose.Schema.Types.ObjectId,
      ref: 'MealPlanTemplate',
    },
    startDate: Date, // the start date of the meal plan. Just use any date
    endDate: Date, // the end date of the meal plan. Just use any date. Remember endDate = startDate + 7 days
    progress: { // !!
      type: Number,
      default: 0,
    },
    objective: String, // comes from the user's input. Could be "Lose fat", "Gain muscle", "Become healthier". These do not have any implications on the optimization side of things. However, they will have an impact on the inputs of the algorithm
    finished: { // !!
      type: Boolean,
      default: false,
    },
    stepCheckpoint: { // !!
      type: Number,
      default: 0,
    },
    indications: [String], // !!
    mealPlanCreateView: String, // !!
    exchangeView: String, // !!
    pendingHours: String, // !!
    days: [ // The main property. A day is an object. A meal plan is an array of 7 of those objects.
      {
        _id: false, // !!
        isFreeDay: Boolean, // Ignore for v1. Might include in the near future. It means a day is a cheat day, so no foods are included.
        dayName: String, // The name of the day. Ex: Lunes
        dailyCalories: Number, // The target amount of calories in a day. Ex: 2000
        dailyProtein: Number, // The target amount of protein in a day, in grams. Ex: 120
        dailyCarbs: Number, // The target amount of carbs in a day, in grams. Ex: 250
        dailyFat: Number, // The target amount of fat in a day, in grams. Ex: 58
        requiredWater: Number, // !!
        meals: [
          {
            mealName: String, // name of the meal. Check file nutrientGuidelines.js for more info.
            mealTime: String, // !!
            mealComment: String, // !!
            blankMealText: String, // !!
            percentageMealTarget: Number, // Percentage of calories of the day. Related to input called dailyCaloriesDistribution. If dailyCaloriesDistribution = [50, 20, 30], that means that if this is the first meal, percentageMealTarget = 50. Remember it's in percentages (it means 50% of the daily calories)
            mealProteinTarget: Number, // The target amount of protein for this meal, in grams. Ex: 25 
            mealCarbsTarget: Number, // The target amount of carbs for this meal, in grams. Ex: 70
            mealFatTarget: Number, // The target amount of fat for this meal, in grams. Ex: 8
            exchanges: { // !!
              type: [exchangeSchema],
              default: undefined,
            },
            recipes: [ // Array with the foods in this meal. Every food is an object. This includes simple foods and recipes. This part has nested objects and arrays, pay attention to this. Check finishedMealPlanExample.js to see a final result.
              {
                optionName: String, // !!
                foodOptions: [ // Array where foods are placed. Length of the foodOptions array must always be 1.
                  {
                    food: { // id of the added food
                      type: mongoose.Schema.Types.ObjectId,
                      ref: 'Food',
                      required: true,
                    },
                    foodName: {  // name of the added food. Ex: Oatmeal
                      type: String,
                      required: true,
                    },
                    quantity: { // quantity of the added food. Ex: 2
                      type: Number,
                      required: true,
                      min: 0,
                    },
                    unit: { // unit of the added food. Ex: cup
                      type: String,
                      required: true,
                    },
                  },
                ],
              },
            ],
          },
        ],
      },
    ],
    oldExpert: { // !!
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Expert',
    },
    foods: [ // List of unique food id's in the meal plan. Ex: ['123', '456', '789']
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Food',
      },
    ],
    expert: { // !!
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Expert',
    },
    patient: { // !!
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Patient',
    },
    appointment: { // !!
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Appointment',
    },
    workout: { // !!
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Workout',
    },
  },
  {
    timestamps: true, // !!
  }
);


// ***********NOT RELEVANT*************
// Siempre definir imports en el .pre para evitar referenciar circulares que botan {}.
// mealPlanSchema.pre('remove', async function (next) {
//   const Patient = require('./patient');
//   const Workout = require('./workout');
//   const Appointment = require('./appointment');
//   const MealPlanTemplate = require('./mealPlanTemplate');
//   const GroceriesList = require('./groceriesList');
//   try {
//     console.log('en remove hook');
//     if (this.patient) {
//       let patient = await Patient.findById(this.patient);
//       if (patient) {
//         patient.mealPlans.remove(this._id);
//         patient.save();
//       }
//     }

//     let appointment = await Appointment.findById(this.appointment);
//     if (appointment) {
//       appointment.mealPlans.remove(this._id);
//       appointment.save();
//     }

//     await Workout.deleteMany({ mealPlan: this._id });

//     await GroceriesList.deleteMany({ mealPlan: this._id });

//     if (this.fromTemplate && this.fromTemplate._id) {
//       let mealPlanTemplates = await MealPlanTemplate.findById(this.fromTemplate._id);
//       if (mealPlanTemplates) {
//         mealPlanTemplates.mealPlans.remove(this._id);
//         mealPlanTemplates.save();
//       }
//     }

//     return next();
//   } catch (err) {
//     return next(err);
//   }
// });

// const MealPlan = mongoose.model('MealPlan', mealPlanSchema);
// module.exports = MealPlan;



// **********END OF NOT RELEVANT************