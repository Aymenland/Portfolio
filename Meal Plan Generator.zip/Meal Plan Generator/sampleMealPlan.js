const SampleMealPlan2000Kcal = [
  {
     "dayName":"Lunes",
     "meals":[
        {
           "_id":"5d2b3236acbba721d650eb00",
           "mealName":"Desayuno",
           "mealTime":"7:30AM",
           "recipes":[
              {
                 "foodOptions":[
                    {
                       "food":"5c9424cac79d3f1163b7e076",
                       "foodName":"Leche fresca de vaca/ descremada",
                       "quantity":200,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424c8c79d3f1163b7dd46",
                       "foodName":"Pan integral supermercados",
                       "quantity":2,
                       "unit":"Unidad mediana"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424c6c79d3f1163b7d77a",
                       "foodName":"Mermelada, endulzadas con jugo de frutas",
                       "quantity":1,
                       "unit":"tablespoon"
                    }
                 ]
              }
           ]
        },
        {
           "_id":"5d2b3811acbba721d650eb01",
           "mealName":"Media mañana",
           "mealTime":"11:00AM",
           "recipes":[
              {
                 "foodOptions":[
                    {
                       "food":"5c9424adc79d3f1163b7c4d3",
                       "foodName":"Plátano",
                       "quantity":1,
                       "unit":"medium (7\" to 7-7/8\" long)"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424b6c79d3f1163b7cb20",
                       "foodName":"Nueces inglesas",
                       "quantity":1,
                       "unit":"cup, in shell, edible yield (7 nuts)"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424a7c79d3f1163b7be16",
                       "foodName":"Yogur descremado",
                       "quantity":200,
                       "unit":"gram"
                    }
                 ]
              }
           ]
        },
        {
           "_id":"5d2b39fcacbba721d650eb02",
           "mealName":"Almuerzo",
           "mealTime":"1:30PM",
           "recipes":[
              {
                 "foodOptions":[
                    {
                       "food":"5c9424c6c79d3f1163b7d7d8",
                       "foodName":"Macarrones (vegetal), enriquecido, seco",
                       "quantity":70,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424a8c79d3f1163b7c0ff",
                       "foodName":"Pechuga de pollo asada (carne)",
                       "quantity":100,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424adc79d3f1163b7c4af",
                       "foodName":"Manzana con piel",
                       "quantity":1,
                       "unit":"medium (3\" dia)"
                    }
                 ]
              }
           ]
        },
        {
           "_id":"5d2b3b4aacbba721d650eb03",
           "mealName":"Media tarde",
           "mealTime":"5:00PM",
           "recipes":[
              {
                 "foodOptions":[
                    {
                       "food":"5c9424b6c79d3f1163b7cdc5",
                       "foodName":"Té verde pasado, regular",
                       "quantity":1,
                       "unit":"cup"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424c9c79d3f1163b7de43",
                       "foodName":"Pan integral",
                       "quantity":50,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424c8c79d3f1163b7dd2c",
                       "foodName":"Queso suizo bajo en grasa",
                       "quantity":50,
                       "unit":"gram"
                    }
                 ]
              }
           ]
        },
        {
           "_id":"5d2b3d5eacbba721d650eb04",
           "mealName":"Cena",
           "mealTime":"7:30PM",
           "recipes":[
              {
                 "foodOptions":[
                    {
                       "food":"5c9424cac79d3f1163b7dfda",
                       "foodName":"Pescado merluza/ fresco",
                       "quantity":2,
                       "unit":"Filete de parte superior"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424cac79d3f1163b7e1ab",
                       "foodName":"Ensalada de verduras",
                       "quantity":200,
                       "unit":"gram"
                    }
                 ]
              }
           ]
        }
     ],
     "dailyCalories":2000,
     "dailyCarbs":285,
     "dailyFat":47.78,
     "dailyProtein":107.5
  },
  {
     "dayName":"Martes",
     "meals":[
        {
           "recipes":[
              {
                 "foodOptions":[
                    {
                       "food":"5c9424cac79d3f1163b7e076",
                       "foodName":"Leche fresca de vaca/ descremada",
                       "quantity":200,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424b6c79d3f1163b7cae8",
                       "foodName":"Almendras",
                       "quantity":10,
                       "unit":"unit"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424c9c79d3f1163b7def3",
                       "foodName":"Fresa",
                       "quantity":10,
                       "unit":"Unidad mediana"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424c6c79d3f1163b7d79f",
                       "foodName":"Avena ",
                       "quantity":50,
                       "unit":"gram"
                    }
                 ]
              }
           ],
           "_id":"5d2b3236acbba721d650eb00",
           "mealName":"Desayuno",
           "mealTime":"7:30AM"
        },
        {
           "recipes":[
              {
                 "foodOptions":[
                    {
                       "food":"5c9424a7c79d3f1163b7be16",
                       "foodName":"Yogur descremado",
                       "quantity":200,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424acc79d3f1163b7c412",
                       "foodName":"Cereal de granola",
                       "quantity":50,
                       "unit":"gram"
                    }
                 ]
              }
           ],
           "_id":"5d2b3811acbba721d650eb01",
           "mealName":"Media mañana",
           "mealTime":"11:00AM"
        },
        {
           "recipes":[
              {
                 "foodOptions":[
                    {
                       "food":"5c9424c6c79d3f1163b7d7a1",
                       "foodName":"Arroz integral de grano medio, crudo ",
                       "quantity":50,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424bbc79d3f1163b7d088",
                       "foodName":"Guisantes hervidos, con sal",
                       "quantity":50,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424c9c79d3f1163b7deb5",
                       "foodName":"Zanahoria",
                       "quantity":100,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424a7c79d3f1163b7be1c",
                       "foodName":"Huevo entero crudo (fresco)",
                       "quantity":1,
                       "unit":"medium"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424a7c79d3f1163b7c01b",
                       "foodName":"Aceite de oliva",
                       "quantity":1,
                       "unit":"tablespoon"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424c9c79d3f1163b7deb4",
                       "foodName":"Tomate italiano",
                       "quantity":1,
                       "unit":"Unidad mediana"
                    }
                 ]
              }
           ],
           "_id":"5d2b39fcacbba721d650eb02",
           "mealName":"Almuerzo",
           "mealTime":"1:30PM",
           "mealComment":"Mezclar todo a modo de ensalada"
        },
        {
           "recipes":[
              {
                 "foodOptions":[
                    {
                       "food":"5c9424b6c79d3f1163b7cdc5",
                       "foodName":"Té verde pasado, regular",
                       "quantity":1,
                       "unit":"cup"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424c9c79d3f1163b7de43",
                       "foodName":"Pan integral",
                       "quantity":50,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424c8c79d3f1163b7dd2c",
                       "foodName":"Queso suizo bajo en grasa",
                       "quantity":30,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424cac79d3f1163b7e02d",
                       "foodName":"Jamón del país",
                       "quantity":2,
                       "unit":"Rebanada"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424adc79d3f1163b7c560",
                       "foodName":"Jugo de naranja",
                       "quantity":150,
                       "unit":"gram"
                    }
                 ]
              }
           ],
           "_id":"5d2b3b4aacbba721d650eb03",
           "mealName":"Media tarde",
           "mealTime":"5:00PM"
        },
        {
           "recipes":[
              {
                 "foodOptions":[
                    {
                       "food":"5c9424cac79d3f1163b7e1ab",
                       "foodName":"Ensalada de verduras",
                       "quantity":200,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424b1c79d3f1163b7c8e1",
                       "foodName":"Espinaca, cruda",
                       "quantity":100,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424c9c79d3f1163b7de7b",
                       "foodName":"Cebolla blanca",
                       "quantity":100,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424adc79d3f1163b7c52c",
                       "foodName":"Kiwi verde",
                       "quantity":1,
                       "unit":"fruit (2\" dia)"
                    }
                 ]
              }
           ],
           "_id":"5d2b3d5eacbba721d650eb04",
           "mealName":"Cena",
           "mealTime":"7:30PM",
           "mealComment":"Espinaca y cebollas salteadas"
        }
     ],
     "dailyCalories":2000,
     "dailyCarbs":285,
     "dailyFat":47.78,
     "dailyProtein":107.5
  },
  {
     "dayName":"Miércoles",
     "meals":[
        {
           "recipes":[
              {
                 "foodOptions":[
                    {
                       "food":"5c9424cac79d3f1163b7e076",
                       "foodName":"Leche fresca de vaca/ descremada",
                       "quantity":200,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424a7c79d3f1163b7c01b",
                       "foodName":"Aceite de oliva",
                       "quantity":1,
                       "unit":"tablespoon"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424c0c79d3f1163b7d4ac",
                       "foodName":"Pan trigo integral, preparado a partir de la receta, tostado",
                       "quantity":100,
                       "unit":"gram"
                    }
                 ]
              }
           ],
           "_id":"5d2b3236acbba721d650eb00",
           "mealName":"Desayuno",
           "mealTime":"7:30AM"
        },
        {
           "recipes":[
              {
                 "foodOptions":[
                    {
                       "food":"5c9424c1c79d3f1163b7d5d4",
                       "foodName":"Masa tostada de frutas, congelado, (incluye manzana, arándano, cereza, fresa)",
                       "quantity":100,
                       "unit":"gram"
                    }
                 ]
              }
           ],
           "_id":"5d2b3811acbba721d650eb01",
           "mealName":"Media mañana",
           "mealTime":"11:00AM"
        },
        {
           "recipes":[
              {
                 "foodOptions":[
                    {
                       "food":"5c9424bbc79d3f1163b7cfd3",
                       "foodName":"Lentejas, crudas",
                       "quantity":50,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424c9c79d3f1163b7dd78",
                       "foodName":"Pimiento",
                       "quantity":1,
                       "unit":"Unidad pequeña"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424b1c79d3f1163b7c85e",
                       "foodName":"Cebolla, cruda",
                       "quantity":1,
                       "unit":"cup, chopped"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424cac79d3f1163b7e04d",
                       "foodName":"Pollo/ pechuga frita de",
                       "quantity":100,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424adc79d3f1163b7c4d3",
                       "foodName":"Plátano",
                       "quantity":1,
                       "unit":"medium (7\" to 7-7/8\" long)"
                    }
                 ]
              }
           ],
           "_id":"5d2b39fcacbba721d650eb02",
           "mealName":"Almuerzo",
           "mealTime":"1:30PM"
        },
        {
           "recipes":[
              {
                 "foodOptions":[
                    {
                       "food":"5c9424cac79d3f1163b7e076",
                       "foodName":"Leche fresca de vaca/ descremada",
                       "quantity":200,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424acc79d3f1163b7c412",
                       "foodName":"Cereal de granola",
                       "quantity":50,
                       "unit":"gram"
                    }
                 ]
              }
           ],
           "_id":"5d2b3b4aacbba721d650eb03",
           "mealName":"Media tarde",
           "mealTime":"5:00PM"
        },
        {
           "recipes":[
              {
                 "foodOptions":[
                    {
                       "food":"5c9424cac79d3f1163b7dfda",
                       "foodName":"Pescado merluza/ fresco",
                       "quantity":2,
                       "unit":"Filete de parte superior"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424cac79d3f1163b7e1ab",
                       "foodName":"Ensalada de verduras",
                       "quantity":200,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424c9c79d3f1163b7de97",
                       "foodName":"Lechuga larga",
                       "quantity":200,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424c9c79d3f1163b7deb4",
                       "foodName":"Tomate",
                       "quantity":1,
                       "unit":"Unidad mediana"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424b1c79d3f1163b7c7e2",
                       "foodName":"Zanahorias, hervidas y escurridas sin sal",
                       "quantity":0.5,
                       "unit":"cup slices"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424bbc79d3f1163b7cf63",
                       "foodName":"Atún listado, cocinado en seco",
                       "quantity":150,
                       "unit":"gram"
                    }
                 ]
              }
           ],
           "_id":"5d2b3d5eacbba721d650eb04",
           "mealName":"Cena",
           "mealTime":"7:30PM",
           "mealComment":"Mezclar todo en una gran ensalada"
        }
     ],
     "dailyCalories":2000,
     "dailyCarbs":285,
     "dailyFat":47.78,
     "dailyProtein":107.5
  },
  {
     "dayName":"Jueves",
     "meals":[
        {
           "recipes":[
              {
                 "foodOptions":[
                    {
                       "food":"5c9424cac79d3f1163b7e076",
                       "foodName":"Leche fresca de vaca/ descremada",
                       "quantity":200,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424c8c79d3f1163b7dd46",
                       "foodName":"Pan integral supermercados",
                       "quantity":50,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424c6c79d3f1163b7d77a",
                       "foodName":"Mermelada, endulzadas con jugo de frutas",
                       "quantity":1,
                       "unit":"tablespoon"
                    }
                 ]
              }
           ],
           "_id":"5d2b3236acbba721d650eb00",
           "mealName":"Desayuno",
           "mealTime":"7:30AM"
        },
        {
           "recipes":[
              {
                 "foodOptions":[
                    {
                       "food":"5c9424adc79d3f1163b7c4d3",
                       "foodName":"Plátano",
                       "quantity":1,
                       "unit":"medium (7\" to 7-7/8\" long)"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424a7c79d3f1163b7be16",
                       "foodName":"Yogur descremado",
                       "quantity":200,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424c6c79d3f1163b7d79f",
                       "foodName":"Avena ",
                       "quantity":50,
                       "unit":"gram"
                    }
                 ]
              }
           ],
           "_id":"5d2b3811acbba721d650eb01",
           "mealName":"Media mañana",
           "mealTime":"11:00AM",
           "mealComment":"Plátano en rebanadas"
        },
        {
           "recipes":[
              {
                 "foodOptions":[
                    {
                       "food":"5c9424c6c79d3f1163b7d7ee",
                       "foodName":"Fideos con salsa roja",
                       "quantity":80,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424adc79d3f1163b7c54b",
                       "foodName":"Naranja",
                       "quantity":1,
                       "unit":"small (2-3/8\" dia)"
                    }
                 ]
              }
           ],
           "_id":"5d2b39fcacbba721d650eb02",
           "mealName":"Almuerzo",
           "mealTime":"1:30PM"
        },
        {
           "recipes":[
              {
                 "foodOptions":[
                    {
                       "food":"5c9424b6c79d3f1163b7cdc5",
                       "foodName":"Té verde pasado, regular",
                       "quantity":1,
                       "unit":"cup"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424c9c79d3f1163b7de43",
                       "foodName":"Pan integral",
                       "quantity":50,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424c8c79d3f1163b7dd2c",
                       "foodName":"Queso suizo bajo en grasa",
                       "quantity":2,
                       "unit":"slice (1 oz)"
                    }
                 ]
              }
           ],
           "_id":"5d2b3b4aacbba721d650eb03",
           "mealName":"Media tarde",
           "mealTime":"5:00PM"
        },
        {
           "recipes":[
              {
                 "foodOptions":[
                    {
                       "food":"5c9424b1c79d3f1163b7c77c",
                       "foodName":"Brochetas de cerdo con cebolla, calabacín y tomates",
                       "quantity":150,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424adc79d3f1163b7c4af",
                       "foodName":"Manzana con piel",
                       "quantity":1,
                       "unit":"medium (3\" dia)"
                    }
                 ]
              }
           ],
           "_id":"5d2b3d5eacbba721d650eb04",
           "mealName":"Cena",
           "mealTime":"7:30PM"
        }
     ],
     "dailyCalories":2000,
     "dailyCarbs":285,
     "dailyFat":47.78,
     "dailyProtein":107.5
  },
  {
     "dayName":"Viernes",
     "meals":[
        {
           "recipes":[
              {
                 "foodOptions":[
                    {
                       "food":"5c9424cac79d3f1163b7e076",
                       "foodName":"Leche fresca de vaca/ descremada",
                       "quantity":200,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424c6c79d3f1163b7d79f",
                       "foodName":"Avena ",
                       "quantity":50,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424a7c79d3f1163b7c01b",
                       "foodName":"Aceite de oliva",
                       "quantity":1,
                       "unit":"tablespoon"
                    }
                 ]
              }
           ],
           "_id":"5d2b3236acbba721d650eb00",
           "mealName":"Desayuno",
           "mealTime":"7:30AM"
        },
        {
           "recipes":[
              {
                 "foodOptions":[
                    {
                       "food":"5c9424a7c79d3f1163b7be16",
                       "foodName":"Yogur descremado",
                       "quantity":200,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424acc79d3f1163b7c412",
                       "foodName":"Cereal de granola",
                       "quantity":50,
                       "unit":"gram"
                    }
                 ]
              }
           ],
           "_id":"5d2b3811acbba721d650eb01",
           "mealName":"Media mañana",
           "mealTime":"11:00AM"
        },
        {
           "recipes":[
              {
                 "foodOptions":[
                    {
                       "food":"5c9424c6c79d3f1163b7d7a1",
                       "foodName":"Arroz integral de grano medio, crudo ",
                       "quantity":50,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424bbc79d3f1163b7d088",
                       "foodName":"Guisantes hervidos, con sal",
                       "quantity":50,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424c9c79d3f1163b7deb5",
                       "foodName":"Zanahoria",
                       "quantity":100,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424a7c79d3f1163b7be1c",
                       "foodName":"Huevo entero crudo (fresco)",
                       "quantity":1,
                       "unit":"medium"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424a7c79d3f1163b7c01b",
                       "foodName":"Aceite de oliva",
                       "quantity":1,
                       "unit":"tablespoon"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424c9c79d3f1163b7deb4",
                       "foodName":"Tomate italiano",
                       "quantity":1,
                       "unit":"Unidad mediana"
                    }
                 ]
              }
           ],
           "_id":"5d2b39fcacbba721d650eb02",
           "mealName":"Almuerzo",
           "mealTime":"1:30PM",
           "mealComment":"Mezclar todo a modo de ensalada"
        },
        {
           "recipes":[
              {
                 "foodOptions":[
                    {
                       "food":"5c9424b6c79d3f1163b7cdc5",
                       "foodName":"Té verde pasado, regular",
                       "quantity":1,
                       "unit":"cup"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424c9c79d3f1163b7de43",
                       "foodName":"Pan integral",
                       "quantity":50,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424c8c79d3f1163b7dd2c",
                       "foodName":"Queso suizo bajo en grasa",
                       "quantity":30,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424cac79d3f1163b7e02d",
                       "foodName":"Jamón del país",
                       "quantity":2,
                       "unit":"Rebanada"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424adc79d3f1163b7c560",
                       "foodName":"Jugo de naranja",
                       "quantity":150,
                       "unit":"gram"
                    }
                 ]
              }
           ],
           "_id":"5d2b3b4aacbba721d650eb03",
           "mealName":"Media tarde",
           "mealTime":"5:00PM"
        },
        {
           "recipes":[
              {
                 "foodOptions":[
                    {
                       "food":"5c9424cac79d3f1163b7e1ab",
                       "foodName":"Ensalada de verduras",
                       "quantity":200,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424b1c79d3f1163b7c8e1",
                       "foodName":"Espinaca, cruda",
                       "quantity":100,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424c9c79d3f1163b7de7b",
                       "foodName":"Cebolla blanca",
                       "quantity":100,
                       "unit":"gram"
                    }
                 ]
              },
              {
                 "foodOptions":[
                    {
                       "food":"5c9424adc79d3f1163b7c52c",
                       "foodName":"Kiwi verde",
                       "quantity":1,
                       "unit":"fruit (2\" dia)"
                    }
                 ]
              }
           ],
           "_id":"5d2b3d5eacbba721d650eb04",
           "mealName":"Cena",
           "mealTime":"7:30PM",
           "mealComment":"Espinaca y cebollas salteadas"
        }
     ],
     "dailyCalories":2000,
     "dailyCarbs":285,
     "dailyFat":47.78,
     "dailyProtein":107.5
  },
  {
     "dayName":"Sábado",
     "meals":[

     ],
     "dailyCalories":2000,
     "dailyCarbs":285,
     "dailyFat":47.78,
     "dailyProtein":107.5
  },
  {
     "dayName":"Domingo",
     "meals":[

     ],
     "dailyCalories":2000,
     "dailyCarbs":285,
     "dailyFat":47.78,
     "dailyProtein":107.5
  }
]