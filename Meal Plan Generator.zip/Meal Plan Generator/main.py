import json
import re
import weeklyPlan
from time import time


def generateMealPlan(objective, dailyCalories, dailyProtein, dailyCarbs, dailyFat, unitType, mealNames, allergies,
                     dislikes, dailyCaloriesDistribution, gender, dietType="no restrictions", patientId=None,
                     age=None, weight=None, height=None, physicalActivityLevel=None, numMealsPerDay=3):
    # ---- Checking for errors in arguments

    if numMealsPerDay != len(mealNames):
        print("Error: numMealsPerDay not equal to the number of meals in mealNames.")
        return

    if objective not in ["Lose fat", "Gain muscle", "Become healthier"]:
        print("Error: invalid objective parameter. Valid values are: Lose fat, Gain muscle, Become healthier.")
        return

    if height is not None and (height < 140 or height > 210):
        print("Error: invalid height parameter. Valid values range between 140cms and 210cms.")
        return

    if len(dailyCaloriesDistribution) != numMealsPerDay or sum(dailyCaloriesDistribution) != 100:
        print("Error: invalid dailyCaloriesDistribution parameter. Valid values consist of a list with length"
              "numMealsPerDay and values adding up to 100.")
        return

    # ---- Reading in the dataset

    f = open('foodSet.json', encoding="utf-8")
    data = json.load(f)

    # ---- Filtering the dataset from allergies and dislikes

    for i in range(max(len(allergies), len(dislikes))):
        for food in list(data):
            # is the allergie / disliked food in the actual food name?

            food_name = re.sub('[^A-Za-z0-9 ]+', '', food["foodName"].lower()).split()
            if (i < len(allergies) and allergies[i].lower().strip() in food_name) or \
                    (i < len(dislikes) and dislikes[i].lower().strip() in food_name):
                data.remove(food)
                continue

            # is the allergie / disliked food in the ingredients of the food?

            for ingredient in food["ingredients"]:
                food_name = re.sub('[^A-Za-z0-9 ]+', '', ingredient["foodName"].lower()).split()
                if (i < len(allergies) and allergies[i].lower().strip() in food_name) or \
                        (i < len(dislikes) and dislikes[i].lower().strip() in food_name):
                    data.remove(food)
                    break

    """print("foods:", len(data))
    print("maxServingsPerMeal:", len([1 for elem in data if "maxServingsPerMeal" in elem]))
    print("protein_g:", len([1 for elem in data if "protein_g" in elem]))
    print("carbs_g:", len([1 for elem in data if "carbs_g" in elem]))
    print("fat_g:", len([1 for elem in data if "fat_g" in elem]))
    print("weights:", len([1 for elem in data if "weights" in elem]))
    print("Gm_Wgt0:", len([1 for elem in data if "Gm_Wgt0" in elem["weights"]]))
    print("Gm_Wgt0 not None:", len([1 for elem in data if "Gm_Wgt0" in elem["weights"] and elem["weights"]["Gm_Wgt0"] is not None]))
    exit(0)"""

    # Fixing micronutrients missing in the data

    with open("maleMicro.json", encoding="utf-8") as file:
        male_micro = json.load(file)

    for food in data:
        for micro in male_micro[0][1:]:
            if micro not in food:
                food[micro] = 0

    # Reading in micronutrients

    micros = []

    if gender == "M":
        with open("maleMicro.json", encoding="utf-8") as file:
            micros = json.load(file)
    else:
        with open("femaleMicro.json", encoding="utf-8") as file:
            micros = json.load(file)

    ages = [elem[0] for elem in micros[1:]]
    if age >= ages[-1]:
        micros = (micros[0][1:], micros[-1][1:])
    else:
        for i in range(1, len(ages)):
            if ages[i - 1] <= age < ages[i]:
                micros = (micros[0][1:], micros[i][1:])
                micros = dict(zip(micros[0], micros[1]))
                break

    return weeklyPlan.generate_week_plan(data, objective, dailyCalories, dailyProtein, dailyCarbs, dailyFat, unitType,
                                         mealNames, dailyCaloriesDistribution, dietType, micros)


"""if __name__ == "__main__":
    t = time()
    plan = generateMealPlan(objective="Gain muscle", dailyCalories=2000, dailyProtein=75, dailyCarbs=275,
                            dailyFat=66,
                            unitType="", mealNames=["Desayuno", "Almuerzo", "Cena"], allergies=[], dislikes=[],
                            dailyCaloriesDistribution=[20, 32.5, 47.5], gender="M", age=26, numMealsPerDay=3)

    print(plan)

    print(time() - t)"""
