// © 2022 Superfit - All rights reserved
// This file contains the guidelines for the creation of SE, Superfit's Meal Plan Generator. It's an algorithm that returns a personalized meal plan for a real human with real body goals.

// Provided files (recommended to read for the first time in the order they are presented):
  // Rules & guidelines:
    // mealPlanGeneratorRules.js [this file]: every single requirement for the creation of Superfit Engine (SE)
    // NutrientGuidelines.js: file that has some important nutritional parameters and rules

  // Models:
    // mealPlan.js: schema of the meal plan object
    // food.js: schema of the food object

  // Datasets:
    // foodSet.js: dataset of every single food to be used in the generator. It includes simple foods and recipes. Every property needed will be included there
    // ingredients.js: dataset of every ingredient of the recipes used in the generator. Mainly used to check allergies and dislikes.
    // customMeasurements.js: dataset of measurements that foods can be added with, with their respective gram weights. For example, cup. Check property weights in food objects

  // Helper functions:
    // FoodFunctions.js: helper functions that enable multiple things, such as converting grams into custom measurements, getting macros per meal, per day, etc. You can use these functions or implement your own
    // searchQuery.js: helper functions related to regex
    // RegExDiacritics.js: helper functions related to regex
    // LikedFoods.js: helper functions related to regex

  // Extras:
    // sampleMealPlan.js: An example of how a meal plan has to look when finished. Provided so you could better understand the structure of the properties. 


// Deliverables (put in a zip file called SuperfitEngine_V1):
  // 1. Meal Plan Generator files: any number of files that relate to each other and together form SE. The more modular the better. Code must be rigorously commented.
  // 2. Simulation files: any number of files that will be used to test the generator in an automated way (calling a function that generates a patient with certain traits and then generates a mealplan for this patient). Additionally, show the execution time for this version (for N generated meal plans, the avg time is X milliseconds). The more modular the better. Code must be rigorously commented.
  // 3. Readme. File with a .txt format that lays out the approach used to tackle the problem and goes into detail about the process of the algorithm, in plain english. It also shows the algorithm's shortcomings and limitations, as well as areas of improvement to be assessed on future versions. 



// --------------------------RULES----------------------------------
// 1. General principles
  // 1.1 Inputs will always follow the same data structures, and their specific values will vary for each user.
  // 1.2 The algorithm returns a mealPlan, which is a JSON object that follows the structure represented by the schema mealPlanSchema - file mealPlan.js, line 11. Dummy data will be provided for some properties, more on that later.
  // 1.3 A meal plan will always be comprised by 7 consecutive days. The day of the week does not matter (could be from monday through friday, wednesday through tuesday, etc.).
  // 1.4 The function that generates the meal plan will be called generateMealPlan.
  // 1.5 The algorithm must be built in such way that including new features (ex: adding a budget restriction) is feasible without a complete remake. 
  // 1.6 The algorithm must be built in such way that adding new foods in the dataset does not have a massive impact on performance. Think long term around 100k food objects overall. [due to the amount of food object for this version, around 1k, performance will certainly not be an issue at run time. However, it would be great if the algorithm can be built in such way that future versions' performance do not suffer from a larger dataset.]
  // 1.7 A user is refered to as a patient
  // 1.8 There must exist randomness in the algorithm. This means that if the same user generates two meal plans without changing any of his parameters in between, they must be different (with a super high probability).

  
// 2. About the data
// Detailed explanation of every property in every model file. Here general stuff:
  // 2.1 foodType: 0 means a food is a "simple food" (egg, milk, banana, almond, ...)
  // 2.2 foodType: 4 means a food is a recipe (has ingredients, which are other foods, and has instructions, which is an array of strings)
  // 2.3 In the foods JSON file, nutrients are shown per 100 grams of food. For example, if we have "calcium_mg: 89" this means there are 89 milligrams of calcium per 100 grams of that food.  
  // 2.4 foods can be added with the following measurements. The user will indicate the way he prefers. (parameter called unitType)
    // a) gram
    // b) customMeasurement (refers to the property "unit" in the food model). About this: when checking the food dataSet, you will find out that many foods have multiple measurements (in the object weights, represented by properties AmountX, Msre_DescX, Gm_WgtX). The only ones that will be used are the first ones (Amount0, Msre_Desc0, Gm_Wgt0)



// 3. Required inputs
// The following lines show the parameters that must be included in every single call of the generateMealPlan. 
// If a parameter is optional, it will have brackets, for example [dummyParameter]
// If a parameter is mandatory, it will have no brackets, for example dummyParameter
  
  /**
    * @param {string} [patientId] id of the user that requests a meal plan. Also used as a mongoose ObjectId
    * @param {string} gender patient's biological sex. Can either be "M" (for Male) or "F" (for Female)
    * @param {number} [age] patient's age, in years
    * @param {number} [weight] patient's weight, in kilograms
    * @param {number} [height] patient's height, in centimeters (1.82 is not correct as an argument, 182 is)
    * @param {string} [physicalActivityLevel] patient's physical activity level (not sure if we will need this, included just in case)
    * @param {string} objective patient's objective. Can be one of the following: Lose fat, Gain muscle, Become healthier
    * @param {number} dailyCalories target calories in a day (check 4. below for more info)
    * @param {number} dailyProtein target protein grams in a day (check 4. below for more info)
    * @param {number} dailyCarbs target carbs grams in a day (check 4. below for more info)
    * @param {number} dailyFat target fat grams in a day (check 4. below for more info)
    * @param {string} [dietType] patient's diet type. For example vegetarian, vegan, carnivore, etc. (not sure if we will need this, included just in case). Default value would be "no restrictions"
    * @param {string} unitType can be either "gram" or "customMeasurement". Every added foo should be added with that type of unit.
    * @param {number} [numMealsPerDay] number of meals per day. If no value is passed, we should assume 3 meals in a day: ['Desayuno', 'Almuerzo', 'Cena'] - see file NutrientGuidelines.js
    * @param {Object[]} mealNames array of strings with the names of the meals that must be included in a day (ex. Desayuno, Almuerzo, ...) NOTE: The length of the array represents the number of meals per day
    * @param {Object[]} allergies array of strings with the names of foods that must not be included in the meal plan due to allergies - regex function must be applied - use of searchQuery.js
    * @param {Object[]} dislikes array of strings with the names of foods that must not be included in the meal plan due to dislikes - regex function must be applied - use of searchQuery.js
    * @param {Object[]} dailyCaloriesDistribution array of numbers that represent the percentage of total daily calories to be included in each meal. Sum of elements must equal 100. Length of the array must be the same as mealNames. (ex. If mealNames = ['Desayuno', 'Almuerzo', 'Cena'], dailyCaloriesDistribution could be [40, 30, 20], [20, 35, 45], etc.)
    * 
    * @returns {Object} meal plan object, with the mealPlanSchema - file mealPlan.js
  */
  // function generateMealPlan(params){}



// 4. Quantitative restrictions
// The algorithm will not care about the source and validity of the inputs. It will assume them as true and useful.
  // 4.1 About general restrictions, check NutrientGuidelines.js (ctrl + F "dailyFoodGroupRecommendations")
  // 4.2 Inputs ranges (please see point 6. below - Useful info):
    // dailyCalories: a number, no decimals. Usually between 1000 and 4000. 
    // Macronutrients:
      // Protein: a number, max 1 decimal. Usually between 20%-45% of calories
      // Carbs: a number, max 1 decimal. Usually between 20%-35% of calories
      // Fat: a number, max 1 decimal. Usually between 45%-65% of calories
  // 4.3 The amount of calories per day must be around the dailyCalories, withing a range of 20%.
  // 4.4 Micronutrients: for this initial version of the algorithm, they have the same guidelines for everyone (to remain healthy on general conditions)
  // 4.5 About caloric density: check NutrientGuidelines.js
  // 4.6 About dailyFoodGroupRecommendations: check NutrientGuidelines (ctrl + F "dailyFoodGroupRecommendations"). If possible, approach the most at these group recommendations, on a weekly basis. Recommendations are stated for a single day, but averages work fine. (if vegetables has a 2.5 cup per day target, it's fine if one day its 2 and the next day 3)


// 5. Qualitative restrictions
// Most of these rules are about filtering or incentivizing foods
  // 5.1 Allergies (given input, check inputs section) - array of strings that contain foods that the user is allergic to. Foods included in this array must not be included in the mealplan, weather it is as a simple food (foodType 0) or included in a recipe's ingredients
  // 5.2 Dislikes (given input, check inputs section) - array of strings that contain foods that the user does not like. 
  // 5.3 Diet Type (given input, check inputs section) - patient's diet type. For example vegetarian, vegan, carnivore, etc.
  // 5.4 Meal and food specifics: check NutrientGuidelines.js



// 6. Useful info (just fyi, might help)
  // 6.1 A gram of protein contains 4 calories
  // 6.2 A gram of carbs contains 4 calories
  // 6.3 A gram of fat contains 9 calories
  // 6.4 The word "calories" is synonym of "kcal" or "kcals"
  // 6.5 Please check the food model (file food.js) in order to view in which unit every nutrient is used. Ex: "protein_g" means the value associated with that property is in grams.
  // 6.6 A user can also enter his own macros distribution and have the meal plan generated for him. However, there is also the possibility (which is the majority of cases) in which the user will rely on us for his nutrient recommendations.
  // 6.7 "Porción" means "Serving", it's the only unit used for recipes.


// 7. Sample nutritional inputs:
// You can use the following values to create a valid meal plan and test it, as these are acceptable and would fit a meal plan to build muscle:
  // dailyCalories: 2500
  // dailyProtein: 120 (480kcal come from protein)
  // dailyCarbs: 350 (1400 kcal come from carbs)
  // dailyFat: 69 (620 kcal come from fat)
  // dailyCaloriesDistribution: [40, 40, 20] (40% of the calories in the Breakfast, 40% in Lunch, 20% in Dinner)
