// Function that finds a food object within a foods array and returns it. This is only a fancy finder function. 
const getPopulatedFoodHelper = function getPopulatedFood(foods, foodId){
  if(!foods) return undefined
  for(let i = 0; i < foods.length; i++){
    if(foods[i] && foods[i]._id.toString() == foodId.toString()){
      return foods[i];
    }
  }
  return undefined;
}

// Used to convert grams into customMeasurement or viceversa
const getFoodFactor = function getFoodFactor(record, foundPopulatedFood, customMeasurements = []){
  let factor = 100;
  if(record.unit === 'gram'){
    factor = 100;
  } else if(record.unit === 'oz'){
    factor = 3.5274;
  } else {
    let weights = foundPopulatedFood && foundPopulatedFood.weights ? foundPopulatedFood.weights : record.food && record.food.weights ? record.food.weights : [];
    let foundWeight = false;
    for (var weightProperty in weights) {
      if(weights.hasOwnProperty(weightProperty) && record.unit === weights[weightProperty]){
        const gramWeight = `Gm_Wgt${weightProperty.slice(9)}`;
        const amount = `Amount${weightProperty.slice(9)}`;
        //usedAmount = Gm_Wgt/Amount;
        const usedAmount = !isNaN(weights[gramWeight]) && !isNaN(weights[amount]) && weights[amount] > 0 ? weights[gramWeight] / weights[amount] : null
        factor = 100 / usedAmount;
        foundWeight = true;
        break;
      }
    }
    if(!foundWeight){
      for (let j = 0; j < customMeasurements.length; j++) {
        const foodId = foundPopulatedFood ? foundPopulatedFood._id : record.food._id
        if(customMeasurements[j].food === foodId && customMeasurements[j].unit === record.unit){
          factor = 100 / customMeasurements[j].gramWeight;
          break;
        }
      }
    }
  }
  return factor;
}

// Function that returns calories in kilocalories or kilojoules (always use calories. kilocalories and calories are the same thing)
const getCaloriesValue = function getCaloriesValue(calories, energySystem, decimals){
  if(!calories) return 0;
  const multiplier = decimals === 0 ? 1 : 100;
  const divider = decimals === 0 ? 1 : 100;
  return energySystem === 'Kilojoule' ? Math.round(calories * 4.184 * multiplier) / divider : Math.round(calories * multiplier) / divider;
}

// Function that returns the amount of calories in a meal
const getMealCaloriesHelper = function getMealCalories(mealObj, populatedFoods, customMeasurements, fromBlankMealPlan){
  if(fromBlankMealPlan)return;
  console.log('mealObj: ', mealObj);
  // console.log('populatedFoods: ', populatedFoods);
  var totalCalories = 0;
  for(let i = 0; i < mealObj.recipes.length; i++){
    if(mealObj.recipes[i].foodOptions && mealObj.recipes[i].foodOptions.length > 0){
      // console.log('recipes[i].foodOptions: ', mealObj.recipes[i].foodOptions); //entra
      const { calories_kcal } = getAverageFoodOptionsHelper(mealObj.recipes[i].foodOptions, populatedFoods, customMeasurements);
      // console.log('calories_kcal: ', calories_kcal); //entra ok
      totalCalories += calories_kcal;
    }
  }
  console.log('totalCalories: ', totalCalories);
  return getCaloriesValue(totalCalories, 'kcal', 0);
}

// Function that returns the average amount of nutrients for a food option.
// Note: This function is useful for other types of meal plans, where the foodOptions array has a lenght greater than 1. It is not the case here, as the foodOptions array has a length of 1 always.
const getAverageFoodOptionsHelper = (foodOptions, populatedFoods, customMeasurements = [], desiredNutrients = ['calories_kcal']) => {
  let nutrients = {};
  for(let j = 0; j < desiredNutrients.length; j++){
    nutrients[desiredNutrients[j]] = 0;
  }
  for(let i = 0; i < foodOptions.length; i++){
    const foundPopulatedFood = getPopulatedFoodHelper(populatedFoods, foodOptions[i].food);
    // console.log('foundPopulatedFood: ', foundPopulatedFood);
    var factor = 100;
    if(foodOptions[i].unit === 'gram'){
      factor = 100;
    } else if(foodOptions[i].unit === 'oz'){
      factor = 3.5274;
    } else {
      let weights = foundPopulatedFood && foundPopulatedFood.weights ? foundPopulatedFood.weights : foodOptions[i].weights;
      let foundWeight = false;
      for (var weightProperty in weights) {
        if(weights.hasOwnProperty(weightProperty) && foodOptions[i].unit === weights[weightProperty]){
          const gramWeight = `Gm_Wgt${weightProperty.slice(9)}`;
          const amount = `Amount${weightProperty.slice(9)}`;
          //usedAmount = Gm_Wgt/Amount;
          const usedAmount = !isNaN(weights[gramWeight]) && !isNaN(weights[amount]) && weights[amount] > 0 ? weights[gramWeight] / weights[amount] : null
          factor = 100 / usedAmount;
          foundWeight = true;
          break;
        }
      }
      if(!foundWeight){
        for (let j = 0; j < customMeasurements.length; j++) {
          if(customMeasurements[j].food === foodOptions[i].food && customMeasurements[j].unit === foodOptions[i].unit){
            factor = 100 / customMeasurements[j].gramWeight;
            break;
          }
        }
      }
    } 
    for(var nutrient in nutrients){
      if(nutrients.hasOwnProperty(nutrient)) {
        if(factor === Infinity){
          // No hacer nada;
        } else if(foundPopulatedFood && foundPopulatedFood[nutrient] !== undefined){
          nutrients[nutrient] += !isNaN(foundPopulatedFood[nutrient] * foodOptions[i].quantity / factor) ? foundPopulatedFood[nutrient] * foodOptions[i].quantity / factor : 0;
        } else {
          //caso se una comida agregada (foodOptions.food no esta populado)
          nutrients[nutrient] += !isNaN(foodOptions[i][nutrient] * foodOptions[i].quantity / factor) ? foodOptions[i][nutrient] * foodOptions[i].quantity / factor : 0;
        }
      }
    }
  }
  for(let j = 0; j < desiredNutrients.length; j++){
    nutrients[desiredNutrients[j]] = nutrients[desiredNutrients[j]] / foodOptions.length;
  }
  return nutrients;
}

// Function that returns calories, protein, carbs and fat for a day
const getDayTotalNutrientsHelper = (currentDay, populatedFoods, energySystem, customMeasurements) => {
  var totalCalories = 0;
  var totalProt = 0;
  var totalCarbs = 0;
  var totalFat = 0;
  if(currentDay !== undefined && currentDay.meals !== undefined){
    for(let mealIdx = 0; mealIdx < currentDay.meals.length; mealIdx++){
      for(let recipeIdx = 0; recipeIdx < currentDay.meals[mealIdx].recipes.length; recipeIdx++){
        if(currentDay.meals[mealIdx].recipes[recipeIdx].foodOptions.length > 0){
          const { calories_kcal, protein_g, fat_g, carbs_g } = getAverageFoodOptionsHelper(currentDay.meals[mealIdx].recipes[recipeIdx].foodOptions, populatedFoods, customMeasurements, ['calories_kcal', 'protein_g', 'fat_g', 'carbs_g']);
          totalCalories += calories_kcal;
          totalProt += protein_g;
          totalFat += fat_g;
          totalCarbs += carbs_g;
        }
      }
    }
  }
  return [
    getCaloriesValue(totalCalories, energySystem),
    Math.round(totalProt * 100) / 100, 
    Math.round(totalCarbs * 100) / 100, 
    Math.round(totalFat * 100) / 100
  ];
}

// function that returns a list of unique ids of foods
const getUniqueUsedFoods = foodsArr => {
  return foodsArr.filter((v, i, a) => a.indexOf(v) === i);
}

// Function that returns object with the quantity of current micronutrients of a day of a meal plan
const getDayMicroSummaryHelper = (currentDay,populatedFoods, customMeasurements) => {
  let totalZinc = 0, 
      totalCalcium = 0, 
      // totalAlphaCarotene = 0, 
      // totalBetaCarotene = 0, 
      totalCholine = 0, 
      totalCopper = 0, 
      // totalBetaCrypto = 0, 
      totalFluoride = 0, 
      // totalVitaminB9 = 0, 
      totalIron = 0, 
      // totalLutein = 0, 
      // totalLycopene = 0, 
      totalMagnesium = 0, 
      totalManganese = 0, 
      totalNiacin = 0, 
      totalVitaminB5 = 0, 
      totalPhosphorus = 0, 
      totalPotassium = 0, 
      // totalRetinol = 0, 
      totalRiboflavin = 0, 
      totalSelenium = 0, 
      totalSodium = 0, 
      // totalTheobromine = 0, 
      totalVitaminA = 0, 
      totalVitaminB12 = 0, 
      totalVitaminB6 = 0, 
      totalVitaminC = 0, 
      totalVitaminD = 0, 
      // totalVitaminD2 = 0, 
      // totalVitaminD3 = 0, 
      totalVitaminE = 0, 
      totalThiamin = 0,
      totalIodine = 0;
 
  if(currentDay.meals !== undefined){
    for(let mealIdx = 0; mealIdx < currentDay.meals.length; mealIdx++){
      for(let recipeIdx = 0; recipeIdx < currentDay.meals[mealIdx].recipes.length; recipeIdx++){
        if(currentDay.meals[mealIdx].recipes[recipeIdx].foodOptions.length > 0){
          const { 
            calcium_mg, choline_mg,	copper_mg, fluoride_mcg,	iron_mg,
            magnesium_mg, manganese_mg,	niacin_mg, vitaminB5_mg, phosphorus_mg,	potassium_mg,	riboflavin_mg, selenium_mcg, sodium_mg,
            thiamin_mg, vitaminA_mcg,	vitaminB12_ug,	vitaminB6_mg,	vitaminC_mg,	vitaminD_mcg,	vitaminE_mg, zinc_mg, iodine_mcg
          } = getAverageFoodOptionsHelper(currentDay.meals[mealIdx].recipes[recipeIdx].foodOptions, populatedFoods, customMeasurements, microNutrientsArray);
          totalZinc += zinc_mg;
          totalCalcium += calcium_mg;
          totalCholine += choline_mg
          totalCopper += copper_mg
          totalFluoride += fluoride_mcg
          totalIron += iron_mg
          totalMagnesium +=magnesium_mg
          totalManganese +=manganese_mg
          totalNiacin += niacin_mg;
          totalVitaminB5 += vitaminB5_mg
          totalPhosphorus += phosphorus_mg;
          totalPotassium += potassium_mg
          totalRiboflavin += riboflavin_mg
          totalSelenium += selenium_mcg
          totalSodium +=sodium_mg
          totalVitaminA += vitaminA_mcg
          totalVitaminB12 += vitaminB12_ug
          totalVitaminB6 += vitaminB6_mg
          totalVitaminC += vitaminC_mg;
          totalVitaminD += vitaminD_mcg
          totalVitaminE += vitaminE_mg
          totalThiamin += thiamin_mg;
          totalIodine += iodine_mcg;
        }
      }
    }
    return {
      zinc_mg: Math.round(totalZinc  * 100)/100,
      calcium_mg: Math.round(totalCalcium * 100)/100,
      choline_mg: Math.round(totalCholine * 100)/100,
      copper_mg: Math.round(totalCopper * 100)/100,
      fluoride_mcg: Math.round(totalFluoride * 100)/100,
      iron_mg: Math.round(totalIron * 100)/100,
      magnesium_mg: Math.round(totalMagnesium * 100)/100,
      manganese_mg: Math.round(totalManganese * 100)/100,
      niacin_mg: Math.round(totalNiacin * 100)/100,
      vitaminB5_mg: Math.round(totalVitaminB5 * 100)/100,
      phosphorus_mg: Math.round(totalPhosphorus * 100)/100,
      potassium_mg: Math.round(totalPotassium * 100)/100,
      riboflavin_mg: Math.round(totalRiboflavin * 100)/100,
      selenium_mcg: Math.round(totalSelenium * 100)/100,
      sodium_mg: Math.round(totalSodium  * 100)/100,
      vitaminA_mcg: Math.round(totalVitaminA * 100)/100,
      vitaminB12_ug: Math.round(totalVitaminB12 * 100)/100,
      vitaminB6_mg: Math.round(totalVitaminB6 * 100)/100,
      vitaminC_mg: Math.round(totalVitaminC * 100)/100,
      vitaminD_mcg: Math.round(totalVitaminD * 100)/100,
      vitaminE_mg: Math.round(totalVitaminE * 100)/100,
      thiamin_mg: Math.round(totalThiamin * 100)/100,
      iodine_mcg: Math.round(totalIodine * 100)/100
    };
  }
} 

// Function that returns the amount of a nutrient in a certain food set. Usually invoked to get nutrients in a meal or a day
const getCurrentNutrientAmount = (foodsArr = [], foodsArrPopulated, nutrient = 'protein_g') => {
  // console.log('---getCurrentNutrientAmount---');
  let currentAmount = 0;
  const emptyCustomMeasurements = [];
  for(let i = 0; i < foodsArr.length; i++){
    const { foodName, quantity, unit } = foodsArr[i];
    // console.log('getAvg: ', getAverageFoodOptionsHelper([foodsArr[i]], foodsArrPopulated, emptyCustomMeasurements, [nutrient])); //entra NaN
    // currentAmount += getAverageFoodOptionsHelper([foodsArr[i]], foodsArrPopulated, emptyCustomMeasurements, [nutrient])[nutrient][0] //Mando 1er argumento como array por estructura de esa funcion. Mando el ultimo argumento como array por la estructura de esa funcion
    const foundPopulatedFood = foodsArrPopulated.find(f => f._id === foodsArr[i].food);
    // console.log('foundPopulatedFood: ', foundPopulatedFood);
    const factor = getFoodFactor(foodsArr[i], foundPopulatedFood);
    if(factor === Infinity){
      // No hacer nada;
    } else if(foundPopulatedFood && foundPopulatedFood[nutrient] !== undefined){
      currentAmount += !isNaN(foundPopulatedFood[nutrient] * quantity / factor) ? foundPopulatedFood[nutrient] * quantity / factor : 0;
      // console.log(`currentAmount de ${nutrient} en el meal: ${currentAmount}`);
    } else {
      // Caso ese food no tiene el nutriente en cuestion
      // console.log(`${foodName} no tiene el nutriente ${nutrient}`);
    }    
  }

  return currentAmount; // ok
}


exports.getAverageFoodOptionsHelper = getAverageFoodOptionsHelper;
exports.getCurrentNutrientAmount = getCurrentNutrientAmount;
exports.getMealCaloriesHelper = getMealCaloriesHelper;
exports.getFoodMacrosHelper = getFoodMacrosHelper;
exports.getDayMicroSummaryHelper = getDayMicroSummaryHelper;
exports.getDayTotalNutrientsHelper = getDayTotalNutrientsHelper;
exports.getUniqueUsedFoods = getUniqueUsedFoods;
