from flask import Flask, render_template, redirect, request, flash, send_from_directory
from preprocess import preprocess, process_video, video_draw
from util import evaluate
from PIL import Image
import glob
import os
import numpy as np
import cv2
import torch
import torchvision.transforms as transforms
from werkzeug.utils import secure_filename


app = Flask(__name__)

UPLOAD_FOLDER = './upload'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route("/get_data")
def getdata():
    return "Your data"

@app.route('/static/<path:filename>')
def custom_static(filename):
    response = send_from_directory(app.static_folder, filename)
    response.cache_control.max_age = 0
    return response

@app.route('/generate', methods=['GET', 'POST'])
def generate():
    if request.method == 'POST':
        if 'celebrity_image' not in request.files:
            return 'there is no celebrity_image in form!'
        
        file = request.files['celebrity_image']
        is_mp4 = file.filename.lower().endswith('.mp4')
        if (is_mp4):
            video_path = './static/' + file.filename
            file.save(video_path)
            frames = process_video(video_path)
            #frames_drawn = video_draw(video_path)
            print(len(frames))
            max_confidence = 0
            predicted_person = ""
            confidence_list = []
            for f in frames:
                person, confidence = evaluate(f)
                print(confidence)
                print(person)
                confidence_list.append(confidence)
                if confidence > max_confidence:
                    max_confidence = confidence
                    predicted_person = person
            avg_max_confidence = sum(sorted(confidence_list, reverse=True)[:5]) / 5 if confidence_list else 0
            if max_confidence >= 0.93 and avg_max_confidence > 0.90:
                print("here")
                return render_template('result.html', confidence=max_confidence, prediction=predicted_person, video_path=video_path)
            else:
                return render_template('result.html', confidence="INSUFFICIENT", prediction="NO MATCH", video_path=video_path)
        else:
            celebrity_image = Image.open(request.files['celebrity_image'])
            print(request.files['celebrity_image'])
            open_cv_image = np.array(celebrity_image)
            image_path = './static/celeb_original.jpg'
            celebrity_image.save(image_path)
            open_cv_image = open_cv_image[:, :, ::-1].copy()
            cropped_image = preprocess(open_cv_image)
            predicted_person, max_confidence = evaluate(cropped_image)
        # predicted_person, confidence = evaluate(celebrity_image)
        return render_template('result_image.html', confidence=max_confidence, prediction=predicted_person)
    else:
        return "done"
   #return redirect('/loaded')

@app.route('/')
def index():
    files = glob.glob('static/*')
    print(files)
    for f in files:
        os.remove(f)

    return render_template('index.html')
if __name__ == "__main__":
    app.run()