The following instructions detail frontend usage.

Ensure all necessary modules are installed (torch, numpy, PIL, cv2, torchvision)
-----------------------------------
SEE requirements.txt for packages and versions
-----------------------------------


STARTUP
--------------------------------------
To start the server on localhost, run the following

>> py main.py

You should see the following
>>  Running on http://127.0.0.1:5000

Navigate to localhost:5000. Click "Upload" to select either an image (.JPG) or video (.mp4)
Note that the folders ./Test_Photos and ./Test_Videos contain sample videos and images.

Click "Submit" and await results. (Shaq, Steve, Ryan, or CONTROL)
Note that a video may take ~6-10 seconds to process.

Click "Back" to return to the homepage and submit a new image/video.