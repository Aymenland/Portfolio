from PIL import Image
import os
from tqdm import tqdm


def resize_grayscale_images(input_folder, output_folder, width, height):
    for filename in tqdm(os.listdir(input_folder)):
        with Image.open(os.path.join(input_folder, filename)) as img:
            resized_img = img.resize((width, height))
            grayscale_img = resized_img.convert('L')
            grayscale_img.save(os.path.join(output_folder, filename))


# Example usage:
input_folder = "Data/Shaquille O'Neal cropped"
output_folder = "Data/Shaquille O'Neal cropped resized grayscaled"

resize_grayscale_images(input_folder, output_folder, 200, 200)

