import cv2
from tqdm import tqdm


def detect_face(image_path):
    face_cascade = cv2.CascadeClassifier(
        cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

    image = cv2.imread(image_path)
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    faces = face_cascade.detectMultiScale(gray_image, scaleFactor=1.1,
                                          minNeighbors=5, minSize=(30, 30))

    if len(faces) == 0:
        return None

    face_coordinates = []
    for (x, y, w, h) in faces:
        face_coordinates.append(
            (x, y, x + w, y + h))  # Format: (x1, y1, x2, y2)

    return face_coordinates[0]


'''image_file = 'out6.png'
image_path = "Data/Shaquille O'Neal/"
detected_faces = detect_face(image_path + image_file)
print(f"Detected face coordinates: {detected_faces}")'''


def crop_save_face(image_path, face_coordinates, output_path, margin):
    image = cv2.imread(image_path)
    x1, y1, x2, y2 = face_coordinates

    # Calculate the width and height of the bounding box
    width = x2 - x1
    height = y2 - y1

    # Determine the size of the square to contain the bounding box
    size = max(width, height)

    center_x = (x1 + x2) // 2
    center_y = (y1 + y2) // 2

    # Calculate the coordinates for the square region
    square_x1 = max(0, int(center_x - size / 2) - margin)
    square_y1 = max(0, int(center_y - size / 2) - margin)
    square_x2 = min(image.shape[1], int(center_x + size / 2) + margin)
    square_y2 = min(image.shape[0], int(center_y + size / 2) + margin)

    # Crop the square region from the original image
    cropped_face = image[square_y1:square_y2, square_x1:square_x2]
    cv2.imwrite(output_path, cropped_face)


'''output_path = 'Data/Ryan Reynolds cropped/' + image_file
crop_save_face(image_path + image_file, detected_faces, output_path, 50)'''

image_path = "Data/Steve Harvey/"
face_coords = tuple()
for i in tqdm(range(1, 6118)):
    image_file = 'out' + str(i) + '.png'
    detected_face = detect_face(image_path + image_file)
    face_coords = detected_face if detected_face else face_coords

    output_file = "Data/Steve Harvey cropped/" + image_file
    crop_save_face(image_path + image_file, face_coords, output_file, 50)
