import os
from random import random, randint, uniform
from PIL import Image, ImageEnhance
from tqdm import tqdm


def calculate_average_intensity(image):
    total_intensity = 0
    for y in range(image.height):
        for x in range(image.width):
            intensity = image.getpixel((x, y))
            total_intensity += intensity
    average_intensity = int(total_intensity / (image.width * image.height))
    return average_intensity


def augment_images(input_folder, output_folder, n):
    files = os.listdir(input_folder)

    for file in tqdm(files):
        image_path = os.path.join(input_folder, file)
        original_image = Image.open(image_path)

        for i in range(n):
            # Horizontal flip with 50% probability
            flipped_image = original_image
            if random() > 0.5:
                flipped_image = original_image.transpose(
                    Image.FLIP_LEFT_RIGHT)

            # Random changes in brightness and contrast
            enhancer = ImageEnhance.Brightness(flipped_image)
            enhanced_image = enhancer.enhance(uniform(0.8, 1.2))
            enhancer = ImageEnhance.Contrast(enhanced_image)
            enhanced_image = enhancer.enhance(uniform(0.8, 1.2))

            # Random rotation between -15 and 15 degrees
            rotation_angle = randint(-15, 15)
            average_intensity = calculate_average_intensity(original_image)
            rotated_image = enhanced_image.rotate(rotation_angle,
                                                  resample=Image.BICUBIC,
                                                  expand=False,
                                                  fillcolor=average_intensity)

            # Save the augmented image
            output_file = os.path.splitext(file)[0] + f"_augmented{i+1}.png"
            output_path = os.path.join(output_folder, output_file)
            rotated_image.save(output_path)


input_folder = "Data/Steve Harvey cropped resized grayscaled"
output_folder = "Data/Steve Harvey augmented"
augment_images(input_folder, output_folder, 9)
