import cv2
from PIL import Image


def preprocess(cv_image):
    face_cascade = cv2.CascadeClassifier(
        cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

    gray_image = cv2.cvtColor(cv_image, cv2.COLOR_BGR2GRAY)

    # Detect face

    faces = face_cascade.detectMultiScale(gray_image, scaleFactor=1.1,
                                          minNeighbors=5, minSize=(30, 30))

    face_coordinates = None
    if len(faces):
        face_coordinates = [(x, y, x + w, y + h) for x, y, w, h in faces]

    # Crop detected face

    if face_coordinates:
        x1, y1, x2, y2 = face_coordinates[0]
        margin = 50

        width = x2 - x1
        height = y2 - y1

        size = max(width, height)

        center_x = (x1 + x2) // 2
        center_y = (y1 + y2) // 2

        square_x1 = max(0, int(center_x - size / 2) - margin)
        square_y1 = max(0, int(center_y - size / 2) - margin)
        square_x2 = min(gray_image.shape[1], int(center_x + size / 2) + margin)
        square_y2 = min(gray_image.shape[0], int(center_y + size / 2) + margin)

        cropped_face = gray_image[square_y1:square_y2, square_x1:square_x2]
    else:
        cropped_face = gray_image

    # Resizing & Grayscale

    width, height = 200, 200

    pil_image = Image.fromarray(cropped_face)
    resized_img = pil_image.resize((width, height))
    grayscale_img = resized_img.convert('L')

    return grayscale_img


def process_video(video_path, num_frames=20):
    video_capture = cv2.VideoCapture(video_path)

    total_frames = int(video_capture.get(cv2.CAP_PROP_FRAME_COUNT))

    # Calculate the frame indices for equidistant frames
    frame_indices = [int(i * total_frames / num_frames)
                     for i in range(num_frames)]

    # Select and preprocess the frames
    processed_frames = []
    for frame_index in frame_indices:
        video_capture.set(cv2.CAP_PROP_POS_FRAMES, frame_index)

        ret, frame = video_capture.read()

        if not ret:
            break  # Break if there is an issue reading the frame

        image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        processed_frame = preprocess(image)
        processed_frames.append(processed_frame)

    video_capture.release()

    return processed_frames

