import requests
import json

r = requests.get('https://www.rottentomatoes.com/celebrity/ryan_reynolds')
content = r.content
print(content)
parsed = json.loads(content)
print(json.dumps(parsed, indent=4))