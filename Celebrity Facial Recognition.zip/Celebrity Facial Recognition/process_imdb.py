import cv2
from PIL import Image
import numpy as np
import os
import random




def preprocess(cv_image):
    face_cascade = cv2.CascadeClassifier(
        cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

    gray_image = cv2.cvtColor(cv_image, cv2.COLOR_BGR2GRAY)

    # Detect face

    faces = face_cascade.detectMultiScale(gray_image, scaleFactor=1.1,
                                          minNeighbors=5, minSize=(30, 30))

    face_coordinates = None
    if len(faces):
        face_coordinates = [(x, y, x + w, y + h) for x, y, w, h in faces]

    # Crop detected face

    if face_coordinates:
        x1, y1, x2, y2 = face_coordinates[0]
        margin = 50

        width = x2 - x1
        height = y2 - y1

        size = max(width, height)

        center_x = (x1 + x2) // 2
        center_y = (y1 + y2) // 2

        square_x1 = max(0, int(center_x - size / 2) - margin)
        square_y1 = max(0, int(center_y - size / 2) - margin)
        square_x2 = min(gray_image.shape[1], int(center_x + size / 2) + margin)
        square_y2 = min(gray_image.shape[0], int(center_y + size / 2) + margin)

        cropped_face = gray_image[square_y1:square_y2, square_x1:square_x2]
    else:
        cropped_face = gray_image

    # Resizing & Grayscale

    width, height = 200, 200

    pil_image = Image.fromarray(cropped_face)
    resized_img = pil_image.resize((width, height))
    grayscale_img = resized_img.convert('L')

    return grayscale_img



root_directory = 'D:\\CELEB_Recognition_IMDB\\imdb_crop\\imdb_crop'
processed_directory = 'G:\\My Drive\\CIS_581_FINAL\\Celebs\\control'


root_directory = 'D:\\Celeb_Frontend\\IMDB_3Classes\\Steve'
processed_directory = 'G:\\My Drive\\CIS_581_FINAL\\Celebs\\steve'


#subdir
#Iterate over each subdirectory and its files
for subdir, dirs, files in os.walk(root_directory):
    for file in files:
        # Full path to the current file
        file_path = os.path.join(subdir, file)
        
        # Load the image using OpenCV
        try:
            cv_img = cv2.imread(file_path)
            
            # Call the preprocess function
            processed_img = preprocess(cv_img)
            filename_without_extension, _ = os.path.splitext(file)

            # Save the processed result to the new directory with the original filename
            processed_file_path = os.path.join(processed_directory, f"{filename_without_extension}.png")
            processed_img.save(processed_file_path)

            print(f"Processed and saved: {processed_file_path}")

        except Exception as e:
            print(f"Error processing {file_path}: {e}")

# num_images_to_select = 100

# # Iterate over each subdirectory and its files
# for subdir, dirs, files in os.walk(root_directory):
#     # Shuffle the list of files in the subdirectory
#     random.shuffle(files)
    
#     # Take the first 'num_images_to_select' files
#     selected_files = files[:num_images_to_select]
    
#     for file in selected_files:
#         # Full path to the current file
#         file_path = os.path.join(subdir, file)
        
#         # Load the image using OpenCV
#         try:
#             cv_img = cv2.imread(file_path)
            
#             # Call the preprocess function
#             processed_img = preprocess(cv_img)
#             filename_without_extension, _ = os.path.splitext(file)

#             # Save the processed result to the new directory with the original filename
#             processed_file_path = os.path.join(processed_directory, f"{filename_without_extension}.png")
#             processed_img.save(processed_file_path)

#             print(f"Processed and saved: {processed_file_path}")

#         except Exception as e:
#             print(f"Error processing {file_path}: {e}")