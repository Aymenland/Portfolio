import torch
import torch.nn as nn
import torch.optim as optim
import torchvision.models as models
import torchvision.transforms as transforms
from torchvision.datasets import ImageFolder
from torch.utils.data import DataLoader
from face_recognition import FaceRecognitionModel, ImprovedFaceRecognitionModel
from PIL import Image


num_classes = 3
diff_model = FaceRecognitionModel(num_classes)

num_classes_control = 4
control_model = ImprovedFaceRecognitionModel(num_classes_control)

celeb_image_raw = None

def evaluate(celebrity_image):
    model_path = 'trained_model_gpu_2.pth'
    diff_model.load_state_dict(torch.load(model_path, map_location=torch.device('cpu')))
    diff_model.eval()
    model_path = 'trained_model_gpu_C4_2.pth'
    control_model.load_state_dict(torch.load(model_path, map_location=torch.device('cpu')))
    control_model.eval()
    pre_celeb_image, original_image = preprocess_test_image(celebrity_image)
    test_image, predicted_person, confidence = predict_test_image(pre_celeb_image)

    tensor_to_pil = transforms.ToPILImage()
    # Remove the batch dimension if present
    if test_image.ndimension() == 4:
        test_image = test_image.squeeze(0)
    test_image = tensor_to_pil(test_image)
    original_image.save('./static/celeb_image.jpg')
    #original_image.save('./static/celeb_original.jpg')
    return predicted_person, confidence

def preprocess_test_image(test_image):


    original_image = test_image
    # Define data transformations
    test_transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
    ])

    # Open the image and apply transformations
    #test_image = Image.open(test_image_path)

    # Convert to RGB if it's not already in that format
    if test_image.mode != 'RGB':
        test_image = test_image.convert('RGB')

    # Apply transformations
    test_image = test_transform(test_image)

    # Normalize the image
    mean = torch.tensor([0.485, 0.456, 0.406])
    std = torch.tensor([0.229, 0.224, 0.225])
    test_image = transforms.functional.normalize(test_image, mean, std)

    # Add a batch dimension as the model expects batches
    test_image = test_image.unsqueeze(0)

    return test_image, original_image

def predict_test_image(test_image):
    #display(Image(filename=test_image_path))
    
    with torch.no_grad():
       outputs = diff_model(test_image)

    _, predicted_class = torch.max(outputs, 1)
    #  print("Class labels:", train_dataset.classes)
    confidence = torch.nn.functional.softmax(outputs, dim=1)[0][predicted_class].item()
    # Map the predicted class to the corresponding person (A, B, C)
    persons = ['ryan', 'shaq', 'steve']
    predicted_person = persons[predicted_class.item()]

    if (confidence < 0.85):
        outputs = control_model(test_image)
        _, predicted_class = torch.max(outputs, 1)
        confidence = torch.nn.functional.softmax(outputs, dim=1)[0][predicted_class].item()
        persons = ['control', 'ryan', 'shaq', 'steve']
        predicted_person = persons[predicted_class.item()]
        if predicted_person != 'control':
            if confidence < 0.70:
                predicted_person = 'control'
                return test_image, predicted_person, confidence

    # if (confidence < 0.92):
    #     predicted_person = "NO MATCH"
    #print(f"The model predicts that the image belongs to {predicted_person}.")

    return test_image, predicted_person, confidence